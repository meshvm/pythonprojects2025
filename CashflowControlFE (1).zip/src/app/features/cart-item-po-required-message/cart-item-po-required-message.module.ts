import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CartItemPoRequiredMessageComponent } from "./cart-item-po-required-message.component";

@NgModule({
    imports: [SharedModule],
    declarations: [CartItemPoRequiredMessageComponent],
    exports: [CartItemPoRequiredMessageComponent],
})
export class CartItemPoRequiredMessageModule {}
