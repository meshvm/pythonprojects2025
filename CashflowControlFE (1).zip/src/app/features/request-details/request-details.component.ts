import { Component, Input, OnInit } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { FileUploadApiService } from "../../core/api-services/file-upload/file-upload-api.service";
import { PackagingTypeItem } from "../../core/api-services/microservices/models/packaging-types/packaging-type-item.model";
import { ServiceTypeItem } from "../../core/api-services/microservices/models/service-types/service-type-item.model";
import { RequestTypeName } from "../../core/models/request-type-name.enum";
import { RequestInterface } from "../../core/models/request.model";
import { LoaderService } from "../../core/services/loader.service";
import { ExtractFileNamePipe } from "../../shared/pipes/extract-file-name-from-path.pipe";
import { RequestDetailsService } from "./services/request-details.service";

@Component({
    selector: "cc-request-details",
    templateUrl: "request-details.component.html",
    styleUrls: ["request-details.component.scss"],
    providers: [RequestDetailsService],
})
export class RequestDetailsComponent implements OnInit {
    @Input()
    public request: RequestInterface | undefined;

    public readonly requestTypes: typeof RequestTypeName;

    public packagingType: string | undefined;
    public serviceType: string | undefined;

    private packagingTypeOptions: PackagingTypeItem[];
    private serviceTypeOptions: ServiceTypeItem[];

    constructor(
        private requestDetailsService: RequestDetailsService,
        private loaderService: LoaderService,
        private fileUploadApiService: FileUploadApiService,
        private extractFileNamePipe: ExtractFileNamePipe
    ) {
        this.requestTypes = RequestTypeName;
    }

    public async ngOnInit(): Promise<void> {
        await this.loadOptions();

        this.initPackagingType();
        this.initServiceType();
    }

    public get singleaddress(): any {
        return this.request?.deliverTo?.addresses[0];
    }

    public async downloadPurchaseOrder(): Promise<void> {
        const blob = await firstValueFrom(
            this.fileUploadApiService.downloadFile(
                this.request?.purchaseOrderFileName as string
            )
        );

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = this.extractFileNamePipe.transform(
            this.request?.purchaseOrderFileName
        );

        document.body.appendChild(a);
        a.click();

        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    private initPackagingType(): void {
        this.packagingType = this.packagingTypeOptions.find(
            (option) =>
                option.packagingTypeId ===
                this.request?.correspondenceOptions.packagingTypeId
        )?.packagingTypeName;
    }

    private initServiceType(): void {
        this.serviceType = this.serviceTypeOptions.find(
            (option) =>
                option.carrierServiceId ===
                this.request?.correspondenceOptions.carrierServiceId
        )?.carrierServiceName;
    }

    private async loadOptions(): Promise<void> {
        this.loaderService.setLoading(true);

        this.packagingTypeOptions =
            await this.requestDetailsService.getPackagingTypeOptions();
        this.serviceTypeOptions =
            await this.requestDetailsService.getServiceTypeOptions();

        this.loaderService.setLoading(false);
    }
}
