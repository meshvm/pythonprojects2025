import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CustomerRequestStatusModule } from "../customer-request-status/customer-request-status.module";
import { RequestDetailsComponent } from "./request-details.component";

@NgModule({
    imports: [SharedModule, CustomerRequestStatusModule],
    declarations: [RequestDetailsComponent],
    exports: [RequestDetailsComponent],
})
export class RequestDetailsModule {}
