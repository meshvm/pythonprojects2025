import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ConfigurationItemComponent } from "./configuration-item.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ConfigurationItemComponent],
    exports: [ConfigurationItemComponent],
})
export class ConfigurationItemModule {}
