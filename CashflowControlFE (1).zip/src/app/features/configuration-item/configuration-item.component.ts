import { Component, EventEmitter, Input, Output } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { DisableServiceConfirmDialogComponent } from "../disable-service-confirm-dialog/disable-service-confirm-dialog.component";

@Component({
    selector: "cc-configuration-item",
    templateUrl: "./configuration-item.component.html",
    styleUrls: ["./configuration-item.component.scss"],
})
export class ConfigurationItemComponent {
    @Input()
    public title: string;
    @Input()
    public projectCount: number;
    @Input()
    public imageUrl: string;
    @Input()
    public enabled: boolean;
    @Input()
    public pageUrl: string;

    @Output()
    public enableDisable = new EventEmitter<any>();

    constructor(private dialog: MatDialog) {}

    public onEnabledToggle(event: Event): void {
        if (this.enabled) {
            event.preventDefault();
            const dialogRef = this.dialog.open(
                DisableServiceConfirmDialogComponent,
                {
                    data: {
                        title: "Disable " + this.title + "?",
                        message:
                            "Are you sure you want to disable " +
                            this.title +
                            "? The customer users will lose access to this service effective immediately.",
                    },
                }
            );

            dialogRef.afterClosed().subscribe((result: any) => {
                if (result) {
                    this.enabled = false;
                    this.enableDisable.emit(false);
                } else {
                    this.enabled = true;
                }
            });
        } else {
            this.enabled = true;
            this.enableDisable.emit(true);
        }
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
