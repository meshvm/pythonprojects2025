import { UserService } from "src/app/core/services/users.service";
import { ReportsApiService } from "src/app/core/api-services/reports/reports-api.service";
import {
    Component,
    Input,
    ViewEncapsulation,
    OnChanges,
    SimpleChanges,
} from "@angular/core";
import { DatePipe } from "@angular/common";
import { NgTableColumn } from "../../../shared/models/vendor/ng-table-column.model";
import { ReportsBatchesPanelHelper } from "./helpers/reports-batches-panel-helper";
import { PaginationState } from "../../../shared/components/paginator/models/pagination-state.model";
import { Router } from "@angular/router";

@Component({
    selector: "cc-reports-batches-panel",
    templateUrl: "./reports-batches-panel.component.html",
    styleUrls: ["./reports-batches-panel.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [DatePipe],
})
export class ReportsBatchesPanelComponent implements OnChanges {
    @Input()
    public reports: any[];
    @Input()
    public date: string | undefined;
    @Input()
    public batch: string | undefined;
    @Input()
    public availableBatches: boolean = false;

    public availableColumns: NgTableColumn[];
    public shownColumns: NgTableColumn[];
    public filteredReports: any[];
    public reportsArr: any[];

    public itemsPerPage: number;
    public itemsPerPageOptions: number[];
    public paginationState: PaginationState;
    public tableLabel: string | undefined;

    constructor(
        private datePipe: DatePipe,
        private reportsApiService: ReportsApiService,
        private router: Router,
        private userService: UserService
    ) {
        this.availableColumns = ReportsBatchesPanelHelper.getAvailableColumns();
        this.shownColumns = ReportsBatchesPanelHelper.getDefaultColumns();
        this.itemsPerPage = 5;
        this.itemsPerPageOptions = [5, 10, 20, 50];
        this.paginationState = {
            skip: 0,
            limit: this.itemsPerPage,
        };
        this.tableLabel = "All";
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["reports"]) {
            this.reportsArr = this.filteredReports = this.reports;
        }

        if (changes["date"] || changes["batch"]) {
            const formattedDate = this.date
                ? this.datePipe.transform(this.date, "EEEE, LLLL d, yyyy")
                : "";
            const batchLabel = this.batch ? ` - ${this.batch}` : "";
            this.tableLabel = `${formattedDate}${batchLabel}`;
        }
    }

    getReportDetails(reportId: string) {
        this.router.navigate([
            `/IBP_User/customer/${
                this.userService.currentCompanyIdValue
            }/reports/${encodeURIComponent(reportId)}`,
        ]);
    }
}
