import { NgTableColumn } from "../../../../shared/models/vendor/ng-table-column.model";

export class ReportsBatchesPanelHelper {
    private static availableColumns: NgTableColumn[] = [
        {
            field: "fileName",
            header: "File Name",
        },
        {
            field: "date",
            header: "Date",
        },
        {
            field: "filesize",
            header: "File Size",
        },
        {
            field: "lastDownload",
            header: "Last Download",
        },
    ];

    private static defaultColumns: NgTableColumn[] = [
        {
            field: "fileName",
            header: "File Name",
        },
        {
            field: "date",
            header: "Date",
        },
        {
            field: "filesize",
            header: "File Size",
        },
        {
            field: "lastDownload",
            header: "Last Download",
        },
    ];

    public static getAvailableColumns(): NgTableColumn[] {
        return [...this.availableColumns];
    }

    public static getDefaultColumns(): NgTableColumn[] {
        return [...this.defaultColumns];
    }
}
