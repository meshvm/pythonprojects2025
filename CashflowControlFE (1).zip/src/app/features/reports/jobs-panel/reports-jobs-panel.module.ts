import { NgModule } from "@angular/core";
import { SharedModule } from "../../../shared/shared.module";
import { ReportsJobsPanelComponent } from "./reports-jobs-panel.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ReportsJobsPanelComponent],
    exports: [ReportsJobsPanelComponent],
})
export class ReportsJobsPanelModule {}
