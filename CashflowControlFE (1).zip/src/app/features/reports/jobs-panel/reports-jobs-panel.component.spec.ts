import { ComponentFixture, TestBed } from "@angular/core/testing";
import { SimpleChange } from "@angular/core";

import { ReportsJobsPanelComponent } from "./reports-jobs-panel.component";
import { ReportsBatchesPanelHelper } from "./helpers/reports-jobs-panel-helper";

describe("ReportsJobsPanelComponent", () => {
    let component: ReportsJobsPanelComponent;
    let fixture: ComponentFixture<ReportsJobsPanelComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ReportsJobsPanelComponent],
        });
        fixture = TestBed.createComponent(ReportsJobsPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    describe("ngOnChanges", () => {
        it("should components batchOptions upon batches changes", () => {
            component.batches = ["Batch 1", "Batch 2"];
            component.ngOnChanges({
                batches: new SimpleChange(null, component.batches, false),
            });

            expect(component.batchOptions).toEqual(
                ReportsBatchesPanelHelper.composeBatchOptions(component.batches)
            );
        });
    });

    it("should emit batchChange event on batch selection change", () => {
        spyOn(component.batchChange, "emit");
        component.onBatchChange();
        expect(component.batchChange.emit).toHaveBeenCalledWith(
            component.selectedJob?.code
        );
    });

    it("should set selectedJob to undefined upon reset", () => {
        component.reset();
        expect(component.selectedJob).toBe(undefined);
    });
});
