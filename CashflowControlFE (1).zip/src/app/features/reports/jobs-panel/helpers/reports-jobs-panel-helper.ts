import { ReportsJobsItem } from "../models/reports-jobs-item.module";

export class ReportsBatchesPanelHelper {
    public static composeBatchOptions(batches: string[]): ReportsJobsItem[] {
        return batches?.map((batch) => ({
            name: batch,
            code: batch,
        }));
    }
}
