import {
    Component,
    ViewEncapsulation,
    Input,
    Output,
    OnChanges,
    SimpleChanges,
    EventEmitter,
    ViewChild,
} from "@angular/core";
import { ReportsJobsItem } from "./models/reports-jobs-item.module";
import { ReportsBatchesPanelHelper } from "./helpers/reports-jobs-panel-helper";
import { Listbox } from "primeng/listbox";

@Component({
    selector: "cc-reports-jobs-panel",
    templateUrl: "./reports-jobs-panel.component.html",
    styleUrls: ["./reports-jobs-panel.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class ReportsJobsPanelComponent implements OnChanges {
    @Input()
    public batches: string[];
    @Output()
    public batchChange: EventEmitter<string>;

    public batchOptions: ReportsJobsItem[];
    public selectedJob!: ReportsJobsItem | undefined;

    @ViewChild("listbox") listbox: Listbox;

    constructor() {
        this.batchChange = new EventEmitter<string>();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["batches"]) {
            this.batchOptions = ReportsBatchesPanelHelper.composeBatchOptions(
                this.batches
            );
        }
    }

    public onBatchChange(): void {
        this.batchChange.emit(this.selectedJob?.code);
    }

    public reset(): void {
        this.selectedJob = undefined;
        if (this.listbox) {
            this.listbox.resetFilter();
        }
    }
}
