import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ReportsSearchPanelComponent } from "./reports-search-panel.component";

describe("ReportsSearchPanelComponent", () => {
    let component: ReportsSearchPanelComponent;
    let fixture: ComponentFixture<ReportsSearchPanelComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ReportsSearchPanelComponent],
        });
        fixture = TestBed.createComponent(ReportsSearchPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit dateChange event on date selection change", () => {
        spyOn(component.dateChange, "emit");
        component.onDateChange();
        expect(component.dateChange.emit).toHaveBeenCalledWith(component.date);
    });

    it("should set date to undefined upon reset", () => {
        component.reset();
        expect(component.date).toBe(undefined);
    });
});
