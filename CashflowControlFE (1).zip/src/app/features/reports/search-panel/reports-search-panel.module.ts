import { NgModule } from "@angular/core";
import { SharedModule } from "../../../shared/shared.module";
import { ReportsSearchPanelComponent } from "./reports-search-panel.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ReportsSearchPanelComponent],
    exports: [ReportsSearchPanelComponent],
})
export class ReportsSearchPanelModule {}
