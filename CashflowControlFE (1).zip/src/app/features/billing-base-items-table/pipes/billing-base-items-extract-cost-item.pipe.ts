import { Injectable, Pipe, PipeTransform } from "@angular/core";
import { BillingItemCost } from "../../../core/api-services/billing/models/billing-item-cost.model";
import { BillingItem } from "../../../core/api-services/billing/models/billing-item.model";
import { BillingBaseItemsTableMode } from "../models/billing-base-items-table-mode.enum";

@Injectable()
@Pipe({
    name: "extractCostItem",
})
export class BillingBaseItemsExtractCostItemPipe implements PipeTransform {
    public transform(
        billingItem: BillingItem,
        mode: BillingBaseItemsTableMode
    ): Partial<BillingItemCost> {
        const simplexItem = billingItem.billingItemCost?.find(
            (item) => !item.isDuplexPrinting
        );
        const duplexItem = billingItem.billingItemCost?.find(
            (item) => item.isDuplexPrinting
        );

        return (
            ((mode === BillingBaseItemsTableMode.Simplex
                ? simplexItem
                : duplexItem) as BillingItemCost) || {}
        );
    }
}
