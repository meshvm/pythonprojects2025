import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { BillingBaseItemsTableComponent } from "./billing-base-items-table.component";
import { BillingBaseItemsExtractCostItemPipe } from "./pipes/billing-base-items-extract-cost-item.pipe";

@NgModule({
    imports: [SharedModule],
    declarations: [
        BillingBaseItemsTableComponent,
        BillingBaseItemsExtractCostItemPipe,
    ],
    exports: [BillingBaseItemsTableComponent],
})
export class BillingBaseItemsTableModule {}
