export class BillingBaseItemsTableHelper {
    public static readonly tableColumns: string[] = [
        "items",
        "overageThreshold",
        "batchThreshold",
        "singleBasePrice",
        "singleOveragePrice",
        "batchBasePrice",
        "batchOveragePrice",
        "actions",
    ];
}
