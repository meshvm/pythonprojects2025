import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ApprovalConfigurationComponent } from "./approval-configuration.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ApprovalConfigurationComponent],
    exports: [ApprovalConfigurationComponent],
})
export class ApprovalConfigurationModule {}
