import { LabeledValue } from "../../../core/models/labeled-value.model";

export class ProjectEditorHelper {
    public static servicePointOptions: LabeledValue[] = [
        {
            label: "Hartford - S2F",
            value: 1,
        },
        {
            label: "Hartford – PVC",
            value: 2,
        },
        {
            label: "Houston - S2F",
            value: 3,
        },
        {
            label: "Houston – PVC",
            value: 4,
        },
        {
            label: "Atlanta - S2F",
            value: 5,
        },
        {
            label: "Atlanta – PVC",
            value: 6,
        },
        {
            label: "Parma – PVC",
            value: 7,
        },
        {
            label: "Parma - S2F",
            value: 8,
        },
        {
            label: "Rancho Cordova – PVC",
            value: 9,
        },
        {
            label: "Rancho Cordova - S2F",
            value: 10,
        },
    ];
}
