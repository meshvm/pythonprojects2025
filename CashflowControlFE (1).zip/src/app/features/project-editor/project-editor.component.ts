import {
    ChangeDetectorRef,
    Component,
    Input,
    OnChanges,
    OnDestroy,
    OnInit,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { firstValueFrom, Subject, takeUntil } from "rxjs";
import { ProjectApiService } from "../../core/api-services/project/project-api.service";
import { FormOptionsHelper } from "../../core/helpers/forms/form-options-helper";
import { LabeledValue } from "../../core/models/labeled-value.model";
import { Project } from "../../core/models/project.model";
import { LoaderService } from "../../core/services/loader.service";
import { NotificationService } from "../../core/services/notification.service";
import { GetTestDataService } from "src/app/get-test-data.service";
import { ProjectEditorInterface } from "./models/project-editor-interface.model";
import { ProjectEditorService } from "./services/project-editor.service";

@Component({
    selector: "cc-project-editor",
    templateUrl: "./project-editor.component.html",
    styleUrls: ["./project-editor.component.scss"],
    providers: [ProjectEditorService],
    encapsulation: ViewEncapsulation.None,
})
export class ProjectEditorComponent
    implements OnChanges, OnDestroy, ProjectEditorInterface
{
    @Input()
    public companyId: string;
    @Input()
    public project: Project;
    @Input()
    public ProjectID: number;

    public form: FormGroup;
    public contractTypeOptions: LabeledValue[];
    public periodOptions: LabeledValue[];
    public periodOptionsAlt: LabeledValue[];
    public servicePointOptions: LabeledValue[];
    public yesNoOptions: LabeledValue[];
    public formSubmitted = false;

    public fieldsToToggle = [
        "deliverySLAUnits",
        "deliverySLAOption",
        "imageQualitySLAPercentage",
        "indexingAccuracySLAPercentage",
        "batchMinimumUnits",
        "batchMaximumUnits",
    ];

    private destroy$ = new Subject<void>();

    constructor(
        private projectEditorService: ProjectEditorService,
        private getTestDataService: GetTestDataService,
        private loadingService: LoaderService,
        private projectApiService: ProjectApiService,
        private showMessageService: NotificationService,
        private changeDetectorRef: ChangeDetectorRef
    ) {
        this.initForm();
        this.loadOptions();
    }
    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["project"]) {
            this.initForm();
        }
    }

    public async save(): Promise<number | undefined> {
        this.form.markAllAsTouched();
        this.changeDetectorRef.detectChanges();

        let responseModel: Partial<Project> = {};

        if (this.form.invalid) {
            this.formSubmitted = true;
            throw new Error(
                "Please fill all required fields before saving this project."
            );
        }

        const saveModel = this.projectEditorService.mapToModel(
            this.form,
            this.project,
            this.companyId
        );
        this.loadingService.setLoading(true);

        if (this.project.ProjectID) {
            await this.updateProject(saveModel as Project);
        } else {
            responseModel = await this.createProject(saveModel as Project);
        }

        this.showMessageService.showSuccessMsg(
            `Project successfully ${
                this.project.ProjectID ? "updated" : "created"
            }`
        );

        this.loadingService.setLoading(false);
        return responseModel?.ProjectID;
    }

    public async delete(): Promise<number | undefined> {
        if (this.project.ProjectID) {
            this.project.isActive = false;
            const deleteModel = this.projectEditorService.mapToModelDelete(
                this.project,
                this.companyId
            );
            await firstValueFrom(
                this.projectApiService.editProject(
                    this.project.ProjectID,
                    deleteModel as Project
                )
            );
            this.showMessageService.showSuccessMsg(
                "Project successfully deleted"
            );
            return this.project.ProjectID;
        }
        return undefined;
    }

    private createProject(saveModel: Project): Promise<Project> {
        return firstValueFrom(this.projectApiService.createProject(saveModel));
    }

    private async updateProject(saveModel: Project): Promise<void> {
        await firstValueFrom(
            this.projectApiService.editProject(
                this.project.ProjectID,
                saveModel
            )
        );
    }

    private initForm(): void {
        if (!this.project) {
            return;
        }
        this.form = this.projectEditorService.buildForm(this.project || {});
        this.subscribeToFormChanges();
        this.toggleFormFields();
    }

    private async loadOptions(): Promise<void> {
        const data: any = await firstValueFrom(this.getTestDataService.main());

        this.contractTypeOptions = data.csProjectConfig.contractTypeOptions;
        this.periodOptions = data.csProjectConfig.periodOptions;
        this.periodOptionsAlt = data.csProjectConfig.periodOptions2;
        this.yesNoOptions = FormOptionsHelper.getYesNoOptions();
        this.projectApiService
            .getCompanyShopServicePoints()
            .pipe(takeUntil(this.destroy$))
            .subscribe((list) => {
                this.servicePointOptions = list.result.map(
                    (servicePoint: {
                        CompanyShopName: any;
                        CompanyShopID: any;
                    }) => ({
                        label: servicePoint.CompanyShopName,
                        value: servicePoint.CompanyShopID,
                    })
                );
            });
    }

    private toggleFormFields(): void {
        this.fieldsToToggle.forEach((field) => {
            const formControl = this.form.get(field);
            if (
                formControl !== null &&
                (formControl.value === null || formControl.value === 0)
            ) {
                formControl.disable();
            }
        });
    }

    private subscribeToFormChanges(): void {
        if (this.form === null) {
            return;
        }

        this.form
            .get("isActiveDeliverySLA")
            ?.valueChanges.pipe(takeUntil(this.destroy$))
            .subscribe((isActive) => {
                const deliverySLAUnits = this.form.get("deliverySLAUnits");
                const deliverySLAOption = this.form.get("deliverySLAOption");
                if (isActive) {
                    deliverySLAUnits?.enable();
                    deliverySLAOption?.enable();
                } else {
                    deliverySLAUnits?.disable();
                    deliverySLAOption?.disable();
                }
            });

        this.form
            .get("isActiveImageQualitySLA")
            ?.valueChanges.pipe(takeUntil(this.destroy$))
            .subscribe((isActive) => {
                const control = this.form.get("imageQualitySLAPercentage");
                if (isActive) {
                    control?.enable();
                } else {
                    control?.disable();
                }
            });

        this.form
            .get("isActiveIndexingAccuracySLA")
            ?.valueChanges.pipe(takeUntil(this.destroy$))
            .subscribe((isActive) => {
                const control = this.form.get("indexingAccuracySLAPercentage");
                if (isActive) {
                    control?.enable();
                } else {
                    control?.disable();
                }
            });

        this.form
            .get("isActiveBatchMinimumMaximum")
            ?.valueChanges.pipe(takeUntil(this.destroy$))
            .subscribe((isActive) => {
                const minControl = this.form.get("batchMinimumUnits");
                const maxControl = this.form.get("batchMaximumUnits");
                if (isActive) {
                    minControl?.enable();
                    maxControl?.enable();
                } else {
                    minControl?.disable();
                    maxControl?.disable();
                }
            });
    }
}
