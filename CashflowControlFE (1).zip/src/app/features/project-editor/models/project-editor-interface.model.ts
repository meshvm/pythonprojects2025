export interface ProjectEditorInterface {
    save: (shouldDelete?: boolean) => Promise<number | undefined>;
    delete: (shouldDelete?: boolean) => Promise<number | undefined>;
}
