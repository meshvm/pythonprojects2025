import { Project } from "src/app/core/models/project.model";
import { AuthService } from "./../../../core/oidc/auth-oidc.service";
import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DateTimeHelper } from "../../../core/helpers/date-time-helper";
import { ReactiveFormsValidationHelper } from "../../../core/helpers/reactive-forms-validation-helper";
import { ProjectEditorFormValue } from "../models/project-editor-form-value.model";
import * as moment from "moment";

@Injectable()
export class ProjectEditorService {
    constructor(
        private formBuilder: FormBuilder,
        private authService: AuthService
    ) {}

    public buildForm(project: Partial<Project> = {}): FormGroup {
        return this.formBuilder.group(
            {
                projectNumber: [project.ProjectNumber, Validators.required],
                ProjectName: [project.ProjectName, Validators.required],
                contractTypeName: [
                    project.contractTypeName,
                    Validators.required,
                ],
                contractStartDate: [
                    project.contractStartDate
                        ? project.contractStartDate
                        : null,
                    [Validators.required],
                ],
                contractEndDate: [
                    project.contractEndDate ? project.contractEndDate : null,
                    Validators.required,
                ],
                sowAssignedDate: [
                    project.dateSOWAssigned ? project.dateSOWAssigned : null,
                    [Validators.required],
                ],
                contractTerm: [
                    project.contractTerm,
                    [
                        Validators.required,
                        Validators.min(1),
                        ReactiveFormsValidationHelper.numberLengthValidator(9),
                    ],
                ],
                contractTermOption: [
                    project.contractTermOption,
                    Validators.required,
                ],
                estimatedMonthlyVolume: [
                    project.estimatedMonthlyVolume,
                    [
                        Validators.required,
                        Validators.min(1),
                        ReactiveFormsValidationHelper.numberLengthValidator(9),
                    ],
                ],
                estimatedContractVolume: [
                    project.estimatedContractVolume,
                    [
                        Validators.required,
                        Validators.min(1),
                        ReactiveFormsValidationHelper.numberLengthValidator(9),
                    ],
                ],
                customerPriorCust: [
                    project.customerPriorCust,
                    [
                        Validators.required,
                        Validators.min(0.0001),
                        ReactiveFormsValidationHelper.decimalLengthValidator(
                            12,
                            4
                        ),
                    ],
                ],
                minimumBilling: [
                    project.minimumBillingAmount,
                    [
                        Validators.required,
                        Validators.min(0.0001),
                        ReactiveFormsValidationHelper.decimalLengthValidator(
                            12,
                            4
                        ),
                    ],
                ],
                doNotExceed: [
                    project.doNotExceedAmount,
                    [
                        Validators.required,
                        Validators.min(0.0001),
                        ReactiveFormsValidationHelper.decimalLengthValidator(
                            12,
                            4
                        ),
                    ],
                ],
                subscriptionVolume: [
                    project.subscriptionVolume,
                    [
                        Validators.required,
                        Validators.min(1),
                        ReactiveFormsValidationHelper.numberLengthValidator(9),
                    ],
                ],
                subscriptionVolumeOption: [
                    project.subscriptionVolumeOption,
                    [Validators.required],
                ],
                subscriptionCost: [
                    project.subscriptionCost,
                    [
                        Validators.required,
                        Validators.min(0.0001),
                        ReactiveFormsValidationHelper.decimalLengthValidator(
                            12,
                            4
                        ),
                    ],
                ],
                digitalRetentionSchedule: [
                    project.digitalRetentionSchedule,
                    [
                        Validators.required,
                        Validators.min(1),
                        ReactiveFormsValidationHelper.numberLengthValidator(9),
                    ],
                ],
                digitalRetentionScheduleOption: [
                    project.digitalRetentionScheduleOption,
                    [Validators.required],
                ],
                projectManagerName: [
                    project.projectManager,
                    Validators.required,
                ],
                CompanyShopID: [project.companyShopID, Validators.required],
                projectedGP30PercentOrHigher: [
                    // eslint-disable-next-line no-nested-ternary
                    !!project.projectedGP30PercentOrHigher,
                ],
                rperformance: [project.rperformance],
                isActiveDeliverySLA: [project.isActiveDeliverySLA],
                deliverySLAUnits: [project.deliverySLAUnits],
                deliverySLAOption: [project.deliverySLAOption],
                isActiveImageQualitySLA: [project.isActiveImageQualitySLA],
                imageQualitySLAPercentage: [
                    project.imageQualitySLAPercentage,
                    Validators.required,
                ],
                isActiveIndexingAccuracySLA: [
                    project.isActiveIndexingAccuracySLA,
                ],
                indexingAccuracySLAPercentage: [
                    project.indexingAccuracySLAPercentage,
                ],
                isActiveBatchMinimumMaximum: [
                    project.isActiveBatchMinimumMaximum,
                ],
                batchMinimumUnits: [project.batchMinimumUnits],
                batchMaximumUnits: [project.batchMaximumUnits],
                isActiveSystemAvailability: [
                    project.isActiveSystemAvailability,
                ],
                externalClientID: [
                    project.externalClientID,
                    Validators.required,
                ],
            },
            {
                validators: [
                    ReactiveFormsValidationHelper.getDateEarlierThanFieldValidatorFn(
                        "contractStartDate",
                        "contractEndDate"
                    ),
                ],
            }
        );
    }

    public mapToModel(
        form: FormGroup,
        project: Project,
        companyId: string
    ): Partial<Project> {
        const formValue: ProjectEditorFormValue = form.value;

        const editedProject: Partial<Project> = {
            companyId: parseInt(companyId, 10),
            projectNumber: formValue.projectNumber.toString(),
            projectName: formValue.ProjectName,
            contractTypeName: formValue.contractTypeName,
            contractStartDateTimeUTC: this.formatDateTime(
                formValue.contractStartDate as Date
            ),
            contractEndDateTimeUTC: this.formatDateTime(
                formValue.contractEndDate as Date
            ),
            sowAssignedDate: this.formatDate(formValue.sowAssignedDate as Date),
            contractTermUnits: parseInt(formValue.contractTerm, 10),
            contractTermOption: formValue.contractTermOption,
            estimatedMonthlyVolumeUnits: parseInt(
                formValue.estimatedMonthlyVolume,
                10
            ),
            estimatedContractVolumeUnits: parseInt(
                formValue.estimatedContractVolume,
                10
            ),
            customerPriorCost: parseFloat(formValue.customerPriorCust),
            minimumBillingAmount: parseFloat(formValue.minimumBilling),
            doNotExceedAmount: parseFloat(formValue.doNotExceed),

            subscriptionCost: parseFloat(formValue.subscriptionCost),
            subscriptionVolumeUnits: parseInt(formValue.subscriptionVolume, 10),
            subscriptionVolumeOptionName: formValue.subscriptionVolumeOption,
            digitalRetentionScheduleUnits: parseInt(
                formValue.digitalRetentionSchedule,
                10
            ),
            digitalRetentionTermOption:
                formValue.digitalRetentionScheduleOption,
            projectManagerName: formValue.projectManagerName,
            companyShopID: formValue.CompanyShopID,
            projectedGP30PercentOrHigher: formValue.projectedGP30PercentOrHigher
                ? 1
                : 0,
            isActiveDeliverySLA: formValue.isActiveDeliverySLA,
            deliverySLAUnits: formValue.deliverySLAUnits,
            deliverySLATermOption: formValue.deliverySLAOption,
            isActiveImageQualitySLA: formValue.isActiveImageQualitySLA,
            imageQualitySLAPercentage: formValue.imageQualitySLAPercentage,
            isActiveIndexingAccuracySLA: formValue.isActiveIndexingAccuracySLA,
            indexingAccuracySLAPercentage:
                formValue.indexingAccuracySLAPercentage,
            isActiveBatchMinimumMaximum: formValue.isActiveBatchMinimumMaximum,
            batchMinimumUnits: formValue.batchMinimumUnits,
            batchMaximumUnits: formValue.batchMaximumUnits,
            isActiveSystemAvailability: formValue.isActiveSystemAvailability,
            colorCodeName: project.colorCodeId || "Black",
            externalClientID: formValue.externalClientID,
        };
        if (project.ProjectID) {
            editedProject.isActive = true;
        }

        for (const key in editedProject) {
            if (
                editedProject.hasOwnProperty(key) &&
                editedProject[key] === ""
            ) {
                editedProject[key] = null;
            }
        }

        return editedProject;
    }

    public mapToModelDelete(
        project: Project,
        companyId: string
    ): Partial<Project> {
        const deleteProject: Partial<Project> = {
            companyId: parseInt(companyId, 10),
            projectNumber: project.ProjectNumber,
            projectName: project.ProjectName,
            contractTypeName: project.contractTypeName,
            contractStartDateTimeUTC: this.formatDateTime(
                project.contractStartDate as Date
            ),
            contractEndDateTimeUTC: this.formatDateTime(
                project.contractEndDate as Date
            ),
            sowAssignedDate: this.formatDate(project.dateSOWAssigned as Date),
            contractTermUnits: project.contractTerm,
            contractTermOption: project.contractTermOption,
            estimatedMonthlyVolumeUnits: project.estimatedMonthlyVolume,
            estimatedContractVolumeUnits: project.estimatedContractVolume,
            customerPriorCost: project.customerPriorCust,
            minimumBillingAmount: project.minimumBillingAmount,
            doNotExceedAmount: project.doNotExceedAmount,

            subscriptionCost: project.subscriptionCost,
            subscriptionVolumeUnits: project.subscriptionVolume,
            subscriptionVolumeOptionName: project.subscriptionVolumeOption,
            digitalRetentionScheduleUnits: project.digitalRetentionSchedule,
            digitalRetentionTermOption: project.digitalRetentionScheduleOption,
            projectManagerName: project.projectManager,
            companyShopID: project.companyShopID,
            projectedGP30PercentOrHigher: project.projectedGP30PercentOrHigher
                ? 1
                : 0,
            isActiveDeliverySLA: project.isActiveDeliverySLA,
            deliverySLAUnits: project.deliverySLAUnits,
            deliverySLATermOption: project.deliverySLAOption,
            isActiveImageQualitySLA: project.isActiveImageQualitySLA,
            imageQualitySLAPercentage: project.imageQualitySLAPercentage,
            isActiveIndexingAccuracySLA: project.isActiveIndexingAccuracySLA,
            indexingAccuracySLAPercentage:
                project.indexingAccuracySLAPercentage,
            isActiveBatchMinimumMaximum: project.isActiveBatchMinimumMaximum,
            batchMinimumUnits: project.batchMinimumUnits,
            batchMaximumUnits: project.batchMaximumUnits,
            isActiveSystemAvailability: project.isActiveSystemAvailability,
            colorCodeName: project.colorCodeId || "Black",
            externalClientID: project.externalClientID,
        };
        return deleteProject;
    }

    private formatDateTime(dateTime: Date): string {
        return DateTimeHelper.formatDateTimeToString(dateTime);
    }
    private formatDate(dateTime: Date): string {
        return DateTimeHelper.formatDateToString(dateTime);
    }
}
