import { Component, Inject, Input, OnInit } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { MatSnackBar } from "@angular/material/snack-bar";
import { getLPAttr } from "src/app/core/utils/leapwork";

@Component({
    selector: "cc-approval-configuration-dialog",
    templateUrl: "approval-configuration-dialog.component.html",
    styleUrls: ["./approval-configuration-dialog.component.scss"],
})
export class ApprovalConfigurationDialogComponent implements OnInit {
    @Input()
    public title: string;

    public optionsApprovalTypes: any[];
    public memberOptions: any[];
    public disableInput: boolean;
    public approvalRule: any;
    public readyToSave: boolean;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        @Inject(MatDialogRef)
        public dialogRef: MatDialogRef<ApprovalConfigurationDialogComponent>,
        @Inject(MatSnackBar) private snackbar: MatSnackBar
    ) {
        this.optionsApprovalTypes = [];
        this.memberOptions = [];
        this.disableInput = false;
        this.readyToSave = true;
        this.title = "";
    }

    public ngOnInit(): void {
        this.title = this.data?.title || "";
        this.optionsApprovalTypes = this.data.optionsApprovalTypes;
        this.memberOptions = this.data.memberOptions;
        this.disableInput = this.data?.disableInput;
        this.approvalRule = this.data?.approvalRule || {};

        if (!this.approvalRule.approvalType) {
            this.approvalRule.approvalType =
                this.optionsApprovalTypes[0]?.value;
        }
    }

    public onSave(): void {
        this.readyToSave = false;

        if (
            (this.approvalRule.approvalType !== "Automatic" &&
                (!this.approvalRule.approvers ||
                    this.approvalRule.approvers.length === 0)) ||
            !this.approvalRule.paymentRangeMin ||
            !this.approvalRule.paymentRangeMax
        ) {
            this.snackbar.open("Please fill in all required fields", "", {
                panelClass: "error-snackbar",
                verticalPosition: "top",
                duration: 3000,
            });
            return;
        }

        this.dialogRef.close(this.approvalRule);
    }

    public onClose(): void {
        this.dialogRef.close();
    }

    public moveItemUp(index: number): void {
        if (index > 0) {
            const temp = this.approvalRule.approvers[index - 1];
            this.approvalRule.approvers[index - 1] =
                this.approvalRule.approvers[index];
            this.approvalRule.approvers[index] = temp;
        }
    }

    public moveItemDown(index: number): void {
        if (index < this.approvalRule.approvers.length - 1) {
            const temp = this.approvalRule.approvers[index + 1];
            this.approvalRule.approvers[index + 1] =
                this.approvalRule.approvers[index];
            this.approvalRule.approvers[index] = temp;
        }
    }

    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
