import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ApprovalConfigurationDialogComponent } from "./approval-configuration-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ApprovalConfigurationDialogComponent],
    exports: [ApprovalConfigurationDialogComponent],
})
export class ApprovalConfigurationDialogModule {}
