// import { TestBed, ComponentFixture } from "@angular/core/testing";
// import { ApprovalConfigurationDialogComponent } from "./approval-configuration-dialog.component";
// import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
// import { MatSnackBar, MatSnackBarModule } from "@angular/material/snack-bar";
// import { BillingTableService } from "../billing-table/services/billing-table.service";
// import { of } from "rxjs";

// // Mock BillingTableService
// class MockBillingTableService {
//     // Mock any methods used by ApprovalConfigurationDialogComponent
//     getSomeData() {
//         return of([]);
//     }
// }

// describe("ApprovalConfigurationDialogComponent", () => {
//     let component: ApprovalConfigurationDialogComponent;
//     let fixture: ComponentFixture<ApprovalConfigurationDialogComponent>;

//     beforeEach(async () => {
//         await TestBed.configureTestingModule({
//             declarations: [ApprovalConfigurationDialogComponent],
//             imports: [MatSnackBarModule],
//             providers: [
//                 { provide: MAT_DIALOG_DATA, useValue: { optionsApprovalTypes: [], getLPAttrValue: "testValue" } },
//                 { provide: MatDialogRef, useValue: {} },
//                 { provide: MatSnackBar, useValue: {} },
//                 { provide: BillingTableService, useClass: MockBillingTableService }
//             ]
//         }).compileComponents();
//     });

//     beforeEach(() => {
//         fixture = TestBed.createComponent(ApprovalConfigurationDialogComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();
//     });

//     it("should create", () => {
//         expect(component).toBeTruthy();
//     });
// });
