import { Injectable } from "@angular/core";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { RecordDetailNote } from "../models/record-detail-note.model";
import { RecordDetailNotesHistoryComponent } from "../record-detail-notes-history.component";

@Injectable()
export class RecordDetailNotesHistoryModalService {
    constructor(private modalService: ModalService) {}

    public openNotesHistoryModal(notes: RecordDetailNote[]): void {
        this.modalService.openModal<RecordDetailNotesHistoryComponent>(
            RecordDetailNotesHistoryComponent,
            "History",
            {
                width: "500px",
                height: "520px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            },
            {
                notes: notes,
            } as Partial<RecordDetailNotesHistoryComponent>
        );
    }
}
