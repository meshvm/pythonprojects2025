import { TestBed } from "@angular/core/testing";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { RecordDetailNotesHistoryComponent } from "../record-detail-notes-history.component";
import { RecordDetailNotesHistoryModalService } from "./record-detail-notes-history-modal.service";
import { RecordDetailNote } from "../models/record-detail-note.model";

describe("RecordDetailNotesHistoryModalService", () => {
    let service: RecordDetailNotesHistoryModalService;
    let modalServiceMock: jasmine.SpyObj<ModalService>;

    beforeEach(() => {
        modalServiceMock = jasmine.createSpyObj("ModalService", ["openModal"]);

        TestBed.configureTestingModule({
            providers: [
                RecordDetailNotesHistoryModalService,
                { provide: ModalService, useValue: modalServiceMock },
            ],
        });

        service = TestBed.inject(RecordDetailNotesHistoryModalService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should open a support request modal with specific configuration", () => {
        const notes: RecordDetailNote[] = [
            {
                authorFirstName: "",
                authorSecondName: "",
                note: "",
                date: "",
                isCurrentUserNote: false,
            },
        ];
        service.openNotesHistoryModal(notes);
        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            RecordDetailNotesHistoryComponent,
            "History",
            jasmine.objectContaining({
                width: "500px",
                height: "520px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });
});
