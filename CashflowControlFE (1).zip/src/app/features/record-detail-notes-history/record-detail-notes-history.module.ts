import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RecordDetailNotesHistoryComponent } from "./record-detail-notes-history.component";

@NgModule({
    imports: [SharedModule],
    declarations: [RecordDetailNotesHistoryComponent],
    exports: [RecordDetailNotesHistoryComponent],
})
export class RecordDetailNotesHistoryModule {}
