import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { OperationManagerDialogComponent } from "./operation-manager-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [OperationManagerDialogComponent],
    exports: [OperationManagerDialogComponent],
})
export class OperationManagerDialogModule {}
