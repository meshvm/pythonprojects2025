import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { LabeledValue } from "../../core/models/labeled-value.model";
import { OperationManagerDialogHelper } from "./helpers/operation-manager-dialog-helper";

@Component({
    selector: "cc-operation-manager-dialog",
    templateUrl: "operation-manager-dialog.component.html",
    styleUrls: ["./operation-manager-dialog.component.scss"],
})
export class OperationManagerDialogComponent {
    public readonly timezoneOptions: LabeledValue[];

    public title: string;
    public operationData: any;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        public dialogRef: MatDialogRef<OperationManagerDialogComponent>
    ) {
        this.timezoneOptions =
            OperationManagerDialogHelper.defaultTimezoneOptions;
        // this.title = data?.title || "";

        // this.operationData.weeklySchedule = JSON.parse(
        //     JSON.stringify(data?.weeklySchedule || [])
        // );
        // this.operationData.observedHolidays = JSON.parse(
        //     JSON.stringify(data?.observedHolidays || [])
        // );
        // this.operationData.customHolidays = JSON.parse(
        //     JSON.stringify(data?.customHolidays || [])
        // );
        this.title = data.title;
        this.operationData = {
            weeklySchedule: data.weeklySchedule || [],
            observedHolidays: data.observedHolidays || [],
            customHolidays: data.customHolidays || [],
        };
    }

    public onClose(): void {
        this.dialogRef.close();
    }

    public onAddNewCustomHoliday(): void {
        this.operationData.customHolidays.push({});
    }

    public onRemoveCustomHoliday(indexToRemove: number): void {
        this.operationData.customHolidays.splice(indexToRemove, 1);
    }

    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
