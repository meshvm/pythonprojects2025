import { TestBed, ComponentFixture } from "@angular/core/testing";
import {
    MatDialogModule,
    MatDialogRef,
    MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { OperationManagerDialogComponent } from "./operation-manager-dialog.component";
import { of } from "rxjs";

describe("OperationManagerDialogComponent", () => {
    let component: OperationManagerDialogComponent;
    let fixture: ComponentFixture<OperationManagerDialogComponent>;
    let dialogRefSpy: jasmine.SpyObj<
        MatDialogRef<OperationManagerDialogComponent>
    >;

    beforeEach(() => {
        dialogRefSpy = jasmine.createSpyObj("MatDialogRef", ["close"]);

        TestBed.configureTestingModule({
            declarations: [OperationManagerDialogComponent],
            imports: [MatDialogModule],
            providers: [
                {
                    provide: MAT_DIALOG_DATA,
                    useValue: {
                        title: "Test Title",
                        weeklySchedule: [{ day: "Monday", time: "9:00 AM" }],
                        observedHolidays: ["2023-01-01"],
                        customHolidays: ["2023-12-25"],
                    },
                },
                { provide: MatDialogRef, useValue: dialogRefSpy },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(OperationManagerDialogComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should initialize operationData correctly", () => {
        expect(component.title).toBe("Test Title");
        expect(component.operationData.weeklySchedule).toEqual([
            { day: "Monday", time: "9:00 AM" },
        ]);
        expect(component.operationData.observedHolidays).toEqual([
            "2023-01-01",
        ]);
        expect(component.operationData.customHolidays).toEqual(["2023-12-25"]);
    });

    it("should close the dialog on onClose", () => {
        component.onClose();
        expect(dialogRefSpy.close).toHaveBeenCalled();
    });

    it("should add a new custom holiday on onAddNewCustomHoliday", () => {
        component.onAddNewCustomHoliday();
        expect(component.operationData.customHolidays.length).toBe(2);
    });

    it("should remove a custom holiday on onRemoveCustomHoliday", () => {
        component.onRemoveCustomHoliday(0);
        expect(component.operationData.customHolidays.length).toBe(0);
    });

    it("should return the correct display index on getDisplayIndex", () => {
        expect(component.getDisplayIndex(0)).toBe(1);
        expect(component.getDisplayIndex(1)).toBe(2);
    });
});
