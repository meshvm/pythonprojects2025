import { LabeledValue } from "../../../core/models/labeled-value.model";

export class OperationManagerDialogHelper {
    public static readonly defaultTimezoneOptions: LabeledValue[] = [
        { label: "Eastern", value: "est" },
    ];
}
