import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { SingleaddressValidatorComponent } from "./single-address-validator.component";

@NgModule({
    imports: [SharedModule],
    declarations: [SingleaddressValidatorComponent],
    exports: [SingleaddressValidatorComponent],
})
export class SingleaddressValidatorModule {}
