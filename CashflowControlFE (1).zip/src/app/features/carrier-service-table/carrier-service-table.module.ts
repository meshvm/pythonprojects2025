import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CarrierServiceTableComponent } from "./carrier-service-table.component";

@NgModule({
    imports: [SharedModule],
    declarations: [CarrierServiceTableComponent],
    exports: [CarrierServiceTableComponent],
})
export class CarrierServiceTableModule {}
