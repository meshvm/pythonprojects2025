import { ComponentFixture, TestBed } from "@angular/core/testing";

import { CarrierServiceTableComponent } from "./carrier-service-table.component";

describe("CarrierServiceTableComponent", () => {
    let component: CarrierServiceTableComponent;
    let fixture: ComponentFixture<CarrierServiceTableComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [CarrierServiceTableComponent],
        });
        fixture = TestBed.createComponent(CarrierServiceTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
