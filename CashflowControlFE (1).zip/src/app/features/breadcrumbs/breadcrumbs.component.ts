import { Component, Input, OnChanges } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { BreadcrumbConfig } from "./models/breadcrumb-config.model";
import { BreadcrumbModel } from "./models/breadcrumb.model";
import { UserService } from "src/app/core/services/users.service";

@Component({
    selector: "cc-breadcrumbs",
    templateUrl: "./breadcrumbs.component.html",
    styleUrls: ["./breadcrumbs.component.scss"],
})
export class BreadcrumbsComponent implements OnChanges {
    @Input()
    public companyName?: string;

    public breadcrumbs: BreadcrumbModel[];

    constructor(
        private activatedRoute: ActivatedRoute,
        private userService: UserService
    ) {
        this.breadcrumbs = [];
        this.breadcrumbs = this.buildBreadCrumb(this.activatedRoute.root);
        this.userService.setCompanyId(
            this.activatedRoute.snapshot.params["CustomerID"]
        );
    }

    public ngOnChanges(): void {
        if (this.companyName) {
            this.breadcrumbs[1].label = this.companyName;
        }
    }

    /**
     * Recursively build breadcrumb according to activated route.
     * @param route
     * @param url
     * @param breadcrumbs
     */
    buildBreadCrumb(
        route: ActivatedRoute,
        url = "",
        breadcrumbs: BreadcrumbModel[] = []
    ): BreadcrumbModel[] {
        //If no routeConfig is avalailable we are on the root path
        let label: any =
            route.routeConfig && route.routeConfig.data
                ? route.routeConfig.data["breadcrumb"]?.label
                : "";

        let path = route.routeConfig && route.routeConfig.path;

        // If the route is dynamic route such as ':id', remove it
        const lastRoutePart = path?.split("/").pop() ?? "";
        const isDynamicRoute = lastRoutePart?.startsWith(":");
        if (isDynamicRoute && !!route.snapshot) {
            const paramName = lastRoutePart?.split(":")[1];
            path = path?.replace(
                lastRoutePart,
                route.snapshot.params[paramName]
            );

            switch (paramName) {
                case "CustomerID":
                    label = route.snapshot.params[paramName];
                    break;
                case "UserID":
                    label = "User Access";
                    break;
                case "ProjectID":
                    label = "Project Configuration";
                    break;
                default:
                    label = route.snapshot.params[paramName];
            }
        }

        const breadcrumb: Partial<BreadcrumbModel> = {
            label: label,
        };

        const basicUrl = path ? `${url}/${path}` : url;
        this.updateBreadcrumbWithUrlMetadata(breadcrumb, route, basicUrl);

        // Only adding route with non-empty label
        const newBreadcrumbs = breadcrumb.label
            ? [...breadcrumbs, breadcrumb]
            : [...breadcrumbs];
        if (route.firstChild) {
            //If we are not on our current path yet,
            //there will be more children to look after, to build our breadcumb
            return this.buildBreadCrumb(
                route.firstChild,
                basicUrl,
                newBreadcrumbs as BreadcrumbModel[]
            );
        }

        return newBreadcrumbs as BreadcrumbModel[];
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }

    private updateBreadcrumbWithUrlMetadata(
        breadcrumb: Partial<BreadcrumbModel>,
        route: ActivatedRoute,
        basicUrl: string
    ): void {
        let breadcrumbUrl = basicUrl;
        const breadcrumbConfig: BreadcrumbConfig =
            route.routeConfig?.data?.["breadcrumb"];

        if (breadcrumbConfig?.ibpUrl) {
            breadcrumb.isUrlAbsolute = !!breadcrumbConfig?.ibpUrl;
            breadcrumbUrl = breadcrumbConfig.ibpUrl;
        }

        if (breadcrumbConfig?.ibpUrlParams) {
            Object.entries(breadcrumbConfig.ibpUrlParams).forEach((value) => {
                breadcrumbUrl = `${breadcrumbConfig.ibpUrl}?${
                    value[0]
                }=${route.snapshot.paramMap.get(value[1])}`;
            });
        }

        breadcrumb.url = breadcrumbUrl;
    }
}
