import { Dictionary } from "../../../core/models/dictionary.model";

export class BreadcrumbConfig {
    label: string | null;
    ibpUrl?: string;
    ibpUrlParams?: Dictionary<string>;
}
