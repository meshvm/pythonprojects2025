import { ComponentFixture, TestBed } from "@angular/core/testing";
import { BreadcrumbsComponent } from "./breadcrumbs.component";
import { ActivatedRoute } from "@angular/router";
import { of } from "rxjs";

describe("BreadcrumbComponent", () => {
    let component: BreadcrumbsComponent;
    let fixture: ComponentFixture<BreadcrumbsComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [BreadcrumbsComponent],
            providers: [
                {
                    provide: ActivatedRoute,
                    useValue: {
                        root: {
                            routeConfig: {
                                data: {
                                    breadcrumb: {
                                        label: "Home",
                                    },
                                },
                                path: "home",
                            },
                            snapshot: {
                                params: { id: "test-id" },
                                data: {},
                            },
                            children: [],
                        },
                        snapshot: {
                            data: {},
                            paramMap: {
                                get: () => "test-id",
                            },
                            routeConfig: {
                                data: {
                                    breadcrumb: {
                                        label: "Home",
                                    },
                                },
                                path: "home",
                            },
                        },
                        params: of({ id: "test-id" }),
                    },
                },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(BreadcrumbsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
