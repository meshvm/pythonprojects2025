import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { SetupDataEditingDialogComponent } from "./setup-data-editing-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [SetupDataEditingDialogComponent],
    exports: [SetupDataEditingDialogComponent],
})
export class SetupDataEditingDialogModule {}
