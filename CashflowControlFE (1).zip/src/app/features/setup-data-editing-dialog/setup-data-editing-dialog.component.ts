import { Component, Inject, Input } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { getLPAttr } from "src/app/core/utils/leapwork";

@Component({
    selector: "cc-setup-data-editing-dialog",
    templateUrl: "setup-data-editing-dialog.component.html",
    styleUrls: ["./setup-data-editing-dialog.component.scss"],
})
export class SetupDataEditingDialogComponent {
    @Input()
    public title: string;
    @Input()
    public subtitle: string;
    @Input()
    public fieldsData: any[];

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        public dialogRef: MatDialogRef<SetupDataEditingDialogComponent>
    ) {
        this.title = data?.title || "";
        this.subtitle = data?.subtitle || "";
        this.fieldsData = JSON.parse(JSON.stringify(data?.fields || []));
    }

    public onClose(): void {
        this.dialogRef.close();
    }

    public onSelectAll(): void {
        this.fieldsData.forEach((field) => {
            field.enabled = true;
        });
    }

    public onDeselectAll(): void {
        this.fieldsData.forEach((field) => {
            field.enabled = false;
        });
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
