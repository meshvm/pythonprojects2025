import { requestTypeId } from "../../../core/api-services/email/models/support-request/support-request-type.enum";
import { LabeledValue } from "../../../core/models/labeled-value.model";

export class SendMessageDialogHelper {
    public static getRequestTypeOptions(): LabeledValue[] {
        return [
            {
                label: "Question",
                value: requestTypeId.Question,
            },
            {
                label: "Sales",
                value: requestTypeId.Sales,
            },
            {
                label: "Technical",
                value: requestTypeId.Technical,
            },
        ];
    }
}
