export interface SendMessageDialogConfig {
    requestCall: boolean;
}
