import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { RecordInfoItemHelper } from "./helpers/record-info-item-helper";

@Component({
    selector: "cc-record-info-item",
    templateUrl: "./record-info-item.component.html",
    styleUrls: ["./record-info-item.component.scss"],
})
export class RecordInfoItemComponent implements OnInit {
    @Input()
    public record: any = {};
    @Output()
    public closeInfo = new EventEmitter<any>();
    @Output()
    public saveInfo = new EventEmitter<any>();
    @Output()
    public removeInfo = new EventEmitter<any>();

    public recordInfo: any;
    public recordHeaderTitle: string;
    public readyToSave = true;

    public readonly fieldTypeOptions: any[];

    constructor() {
        this.fieldTypeOptions = RecordInfoItemHelper.defaultFieldTypeOptions;
    }

    public ngOnInit(): void {
        this.recordInfo = JSON.parse(JSON.stringify(this.record));
        this.recordInfo.fields = this.recordInfo?.fields || [];

        if (this.record?.id) {
            this.recordHeaderTitle = `Editing ${this.record?.name}`;
        } else {
            this.recordHeaderTitle = "New Record Type";
        }
    }

    public onCloseRecordInfo(): void {
        this.closeInfo.emit();
    }

    public onCancelRecordInfo(): void {
        this.recordInfo = JSON.parse(JSON.stringify(this.record));
    }

    public onRemoveRecordInfo(): void {
        this.removeInfo.emit(this.recordInfo);
    }

    public onSaveRecordInfo(): void {
        if (!this.recordInfo.name) {
            this.readyToSave = false;
            return;
        }

        this.saveInfo.emit({
            ...this.recordInfo,
            fields: this.recordInfo.fields
                .map(({ name, type, enabled }: any) => ({
                    name,
                    type,
                    enabled,
                }))
                .filter(({ name, type }: any) => !!name && !!type),
        });
    }

    public onAddNewField(): void {
        this.recordInfo.fields.push({
            editing: true,
        });
    }

    public onToggleStatus(index: number): void {
        this.recordInfo.fields[index].editing =
            !this.recordInfo.fields[index].editing;
    }

    public onRemoveField(index: number): void {
        this.recordInfo.fields.splice(index, 1);
    }

    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
