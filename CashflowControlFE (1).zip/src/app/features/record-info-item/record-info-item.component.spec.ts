import { ComponentFixture, TestBed } from "@angular/core/testing";

import { RecordInfoItemComponent } from "./record-info-item.component";

describe("RecordInfoItem", () => {
    let component: RecordInfoItemComponent;
    let fixture: ComponentFixture<RecordInfoItemComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [RecordInfoItemComponent],
        });
        fixture = TestBed.createComponent(RecordInfoItemComponent);
        component = fixture.componentInstance;
        component.record = { id: 1, name: "Test Record", fields: [] };
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
