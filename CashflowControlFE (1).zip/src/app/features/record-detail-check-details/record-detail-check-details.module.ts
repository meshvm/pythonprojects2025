import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RecordDetailCheckDetailsComponent } from "./record-detail-check-details.component";

@NgModule({
    imports: [SharedModule],
    declarations: [RecordDetailCheckDetailsComponent],
    exports: [RecordDetailCheckDetailsComponent],
})
export class RecordDetailCheckDetailsModule {}
