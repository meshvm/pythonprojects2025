import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CustomLoadingIndicatorComponent } from "./custom-loading-indicator.component";

@NgModule({
    imports: [SharedModule],
    declarations: [CustomLoadingIndicatorComponent],
    exports: [CustomLoadingIndicatorComponent],
})
export class CustomLoadingIndicatorModule {}
