import { ComponentFixture, TestBed } from "@angular/core/testing";

import { CustomLoadingIndicatorComponent } from "./custom-loading-indicator.component";

describe("CustomLoadingIndicatorComponent", () => {
    let component: CustomLoadingIndicatorComponent;
    let fixture: ComponentFixture<CustomLoadingIndicatorComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [CustomLoadingIndicatorComponent],
        });
        fixture = TestBed.createComponent(CustomLoadingIndicatorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
