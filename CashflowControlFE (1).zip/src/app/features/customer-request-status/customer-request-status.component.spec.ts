import { ComponentFixture, TestBed } from "@angular/core/testing";

import { CustomerRequestStatusComponent } from "./customer-request-status.component";
import { CustomerRequestStatusModule } from "./customer-request-status.module";

describe("CustomerRequestStatusComponent", () => {
    let component: CustomerRequestStatusComponent;
    let fixture: ComponentFixture<CustomerRequestStatusComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [CustomerRequestStatusModule],
            declarations: [CustomerRequestStatusComponent],
        });
        fixture = TestBed.createComponent(CustomerRequestStatusComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
