import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CustomerRequestStatusComponent } from "./customer-request-status.component";

@NgModule({
    imports: [SharedModule],
    declarations: [CustomerRequestStatusComponent],
    exports: [CustomerRequestStatusComponent],
})
export class CustomerRequestStatusModule {}
