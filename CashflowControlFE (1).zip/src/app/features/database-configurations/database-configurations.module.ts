import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ConfigurationItemModule } from "../configuration-item/configuration-item.module";
import { DatabaseConfigurationComponent } from "./database-configurations.component";

@NgModule({
    imports: [SharedModule, ConfigurationItemModule],
    declarations: [DatabaseConfigurationComponent],
    exports: [DatabaseConfigurationComponent],
})
export class DatabaseConfigurationsModule {}
