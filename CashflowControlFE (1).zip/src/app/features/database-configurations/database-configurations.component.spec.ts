import { ComponentFixture, TestBed } from "@angular/core/testing";
import { HttpClientModule } from "@angular/common/http";
import {
    OAuthService,
    UrlHelperService,
    OAuthLogger,
    DateTimeProvider,
} from "angular-oauth2-oidc";
import { ActivatedRoute } from "@angular/router";
import { of } from "rxjs";

import { DatabaseConfigurationComponent } from "./database-configurations.component";
import { GetTestDataService } from "src/app/get-test-data.service";
import { MicroservicesApiService } from "src/app/core/api-services/microservices/microservices-api.service";
import { LoaderService } from "src/app/core/services/loader.service";

describe("DatabaseConfigurationComponent", () => {
    let component: DatabaseConfigurationComponent;
    let fixture: ComponentFixture<DatabaseConfigurationComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DatabaseConfigurationComponent],
            imports: [HttpClientModule],
            providers: [
                GetTestDataService,
                MicroservicesApiService,
                LoaderService,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                DateTimeProvider,
                {
                    provide: ActivatedRoute,
                    useValue: {
                        snapshot: {
                            paramMap: {
                                get: () => "someValue",
                            },
                        },
                    },
                },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(DatabaseConfigurationComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
