import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { DeleteConfirmDialogComponent } from "./delete-confirm-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [DeleteConfirmDialogComponent],
    exports: [DeleteConfirmDialogComponent],
})
export class DeleteConfirmDialogModule {}
