import { Component, Inject, Input } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { getLPAttr } from "src/app/core/utils/leapwork";

@Component({
    selector: "cc-delete-confirm-dialog",
    templateUrl: "delete-confirm-dialog.component.html",
    styleUrls: ["./delete-confirm-dialog.component.scss"],
})
export class DeleteConfirmDialogComponent {
    @Input()
    public title: string;
    @Input()
    public message: string;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        public dialogRef: MatDialogRef<DeleteConfirmDialogComponent>
    ) {
        this.title = this.data?.title || "";
        this.message = this.data?.message || "";
    }

    public onDelete(): void {
        this.dialogRef.close(true);
    }

    public onClose(): void {
        this.dialogRef.close();
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
