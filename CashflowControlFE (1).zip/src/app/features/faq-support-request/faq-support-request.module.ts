import { NgModule } from "@angular/core";
import { DropdownModule } from "primeng/dropdown";
import { DialogService } from "primeng/dynamicdialog";
import { QaDirectivesModule } from "../../shared/directives/qa/qa-directives.module";
import { SharedModule } from "../../shared/shared.module";
import { FaqSupportRequestComponent } from "./faq-support-request.component";

@NgModule({
    imports: [SharedModule, DropdownModule, QaDirectivesModule],
    declarations: [FaqSupportRequestComponent],
    providers: [DialogService],
    exports: [FaqSupportRequestComponent],
})
export class FaqSupportRequestModule {}
