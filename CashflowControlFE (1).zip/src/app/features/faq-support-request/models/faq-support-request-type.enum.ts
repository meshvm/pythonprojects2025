export enum FaqSupportRequestType {
    TechnicalSupport = "TechnicalSupport",
    Question = "Question",
    SalesSupport = "SalesSupport",
}
