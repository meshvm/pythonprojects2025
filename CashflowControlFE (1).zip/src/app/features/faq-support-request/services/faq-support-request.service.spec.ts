import { TestBed } from "@angular/core/testing";
import { FormBuilder, FormGroup, ReactiveFormsModule } from "@angular/forms";
import { FaqSupportRequestService } from "./faq-support-request.service";

describe("FaqSupportRequestService", () => {
    let service: FaqSupportRequestService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule],
            providers: [FaqSupportRequestService, FormBuilder],
        });
        service = TestBed.inject(FaqSupportRequestService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should create a form with three controls", () => {
        const form = service.buildForm();
        expect(form instanceof FormGroup).toBe(true);
        expect(form.controls["requestTypeId"]).toBeDefined();
        expect(form.controls["requestDescription"]).toBeDefined();
        expect(form.controls["additionalDetails"]).toBeDefined();
    });

    it("should set required validators for requestTypeId and requestDescription", () => {
        const form = service.buildForm();
        const requestTypeControl = form.controls["requestTypeId"];
        const requestDescriptionControl = form.controls["requestDescription"];

        requestTypeControl.setValue(null);
        expect(requestTypeControl.valid).toBeFalse();

        requestDescriptionControl.setValue(null);
        expect(requestDescriptionControl.valid).toBeFalse();

        requestDescriptionControl.setValue("Valid description");
        expect(requestDescriptionControl.valid).toBeTrue();
    });

    it("should set maxLength validator for requestDescription and additionalDetails", () => {
        const form = service.buildForm();
        const requestDescriptionControl = form.controls["requestDescription"];
        const additionalDetailsControl = form.controls["additionalDetails"];

        requestDescriptionControl.setValue("a".repeat(81)); // 81 characters
        expect(requestDescriptionControl.valid).toBeFalse();

        additionalDetailsControl.setValue("a".repeat(251)); // 251 characters
        expect(additionalDetailsControl.valid).toBeFalse();
    });
});
