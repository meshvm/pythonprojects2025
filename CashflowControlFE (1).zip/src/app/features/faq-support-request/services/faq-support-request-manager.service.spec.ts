import { TestBed } from "@angular/core/testing";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { FaqSupportRequestComponent } from "../faq-support-request.component";
import { FaqSupportRequestManagerService } from "./faq-support-request-manager.service";
import { FormErrorMessageModule } from "src/app/shared/components/form-error-message/form-error-message.module";

describe("FaqSupportRequestManagerService", () => {
    let service: FaqSupportRequestManagerService;
    let modalServiceMock: jasmine.SpyObj<ModalService>;

    beforeEach(() => {
        modalServiceMock = jasmine.createSpyObj("ModalService", ["openModal"]);

        TestBed.configureTestingModule({
            imports: [FormErrorMessageModule],
            providers: [
                FaqSupportRequestManagerService,
                { provide: ModalService, useValue: modalServiceMock },
            ],
        });

        service = TestBed.inject(FaqSupportRequestManagerService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should open a support request modal with specific configuration", () => {
        service.openSupportRequestModal();
        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            FaqSupportRequestComponent,
            "Support Request",
            jasmine.objectContaining({
                width: "500px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });

    it("should open a request call modal with specific configuration", () => {
        service.openRequestCallModal();
        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            FaqSupportRequestComponent,
            "Ask for a Call Back",
            jasmine.objectContaining({
                width: "500px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });
});
