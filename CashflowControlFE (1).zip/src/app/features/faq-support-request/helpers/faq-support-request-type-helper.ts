import { NamedValue } from "../../../shared/models/base/named-value.model";
import { FaqSupportRequestType } from "../models/faq-support-request-type.enum";

export class FaqSupportRequestTypeHelper {
    private static requestTypeOptions: NamedValue<FaqSupportRequestType>[] = [
        {
            name: "Technical Support",
            value: FaqSupportRequestType.TechnicalSupport,
        },
        {
            name: "Question",
            value: FaqSupportRequestType.Question,
        },
        {
            name: "Sales Support",
            value: FaqSupportRequestType.SalesSupport,
        },
    ];

    public static getRequestTypeOptions(): NamedValue<FaqSupportRequestType>[] {
        return [...this.requestTypeOptions];
    }
}
