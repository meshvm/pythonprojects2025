import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ReactiveFormsModule, FormBuilder } from "@angular/forms";
import { DropdownModule } from "primeng/dropdown";
import { ToastrService } from "../../shared/components/toastr/services/toastr.service";
import { FaqSupportRequestComponent } from "./faq-support-request.component";
import { FaqSupportRequestService } from "./services/faq-support-request.service";

describe("FaqSupportRequestComponent", () => {
    let component: FaqSupportRequestComponent;
    let fixture: ComponentFixture<FaqSupportRequestComponent>;
    let faqSupportRequestServiceMock: jasmine.SpyObj<FaqSupportRequestService>;
    let toastrServiceMock: jasmine.SpyObj<ToastrService>;

    beforeEach(() => {
        faqSupportRequestServiceMock = jasmine.createSpyObj(
            "FaqSupportRequestService",
            ["buildForm"]
        );
        toastrServiceMock = jasmine.createSpyObj("ToastrService", [
            "showSuccessMessage",
        ]);

        TestBed.configureTestingModule({
            imports: [ReactiveFormsModule, DropdownModule],
            declarations: [FaqSupportRequestComponent],
            providers: [
                {
                    provide: FaqSupportRequestService,
                    useValue: faqSupportRequestServiceMock,
                },
                { provide: ToastrService, useValue: toastrServiceMock },
                FormBuilder,
            ],
        });

        fixture = TestBed.createComponent(FaqSupportRequestComponent);
        component = fixture.componentInstance;
        faqSupportRequestServiceMock.buildForm.and.returnValue(
            new FormBuilder().group({})
        );
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should not submit an invalid form", () => {
        spyOn(component.form, "markAllAsTouched");
        component.onSubmit();
        expect(component.formSubmitted).toBeTrue();
        expect(component.form.markAllAsTouched).toHaveBeenCalled();
        expect(toastrServiceMock.showSuccessMessage).not.toHaveBeenCalled();
    });
});
