import { UserService } from "src/app/core/services/users.service";
import {
    ChangeDetectorRef,
    Component,
    Inject,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { MenuItem } from "primeng/api";
// import { workQueueImages } from "../../core/constants/work-queue-constants";
import { TableBatchAction } from "../../shared/components/table-batch-actions-bar/models/table-batch-action.module";
import { TableBatchActionsApi } from "../../shared/components/table-batch-actions/models/table-batch-actions-api.model";
import { TableToolbarFilterConfig } from "../../shared/components/table-toolbar-filters/models/table-toolbar-filter-config.model";
import { TableViewMode } from "../../shared/components/table-view-toggle/models/table-view-mode.enum";
import { NgTableColumn } from "../../shared/models/vendor/ng-table-column.model";
import { WorkQueueStatus } from "../../shared/models/work-queues/work-queue-status.enum";
import { WorkQueueTableHelper } from "./helpers/work-queue-table-helper";
import { WorkQueueTableService } from "./services/work-queue-table.service";

@Component({
    selector: "cc-work-queue-table",
    templateUrl: "./work-queue-table.component.html",
    styleUrls: ["./work-queue-table.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [WorkQueueTableService],
})
export class WorkQueueTableComponent implements OnInit, OnChanges {
    @Input({ required: true })
    public workQueues: any[] = [];
    @Input()
    public excludeColumns: string[] = ["CheckPayorAddress"]; // Default columns to exclude todo: check for value on bacth actions
    @Input()
    public activepage: any[] = [];
    @Input()
    public exceptionpage: any[] = [];
    @Output()
    public changes: any[];

    public readonly viewModes: typeof TableViewMode;

    public availableColumns: NgTableColumn[];
    public archiveColumns: NgTableColumn[];
    public shownColumns: NgTableColumn[];
    public showArchiveColumnsOriginal: NgTableColumn[];
    public shownArchiveColumns: NgTableColumn[];
    public showColumnsOriginal: NgTableColumn[];
    public filterConfigs: TableToolbarFilterConfig[];
    public images: any[];
    public batchActions: TableBatchAction[];
    public rowActions: MenuItem[];
    public workQueueStatuses: typeof WorkQueueStatus;
    public filteredWorkQueues: any[];
    public paginatedWorkQueues: any[];
    public viewMode: TableViewMode;
    public companyId: number;

    private search: string;

    constructor(
        @Inject(ChangeDetectorRef) private changeDetectorRef: ChangeDetectorRef,
        private workQueueTableService: WorkQueueTableService,
        private userService: UserService
    ) {
        this.workQueueStatuses = WorkQueueStatus;
        this.companyId = userService.currentCompanyIdValue;

        this.availableColumns = WorkQueueTableHelper.getAvailableColumns();
        this.archiveColumns = WorkQueueTableHelper.getArchiveColumns();
        this.filterConfigs = WorkQueueTableHelper.getFilterConfigs();

        // this.images = workQueueImages;
        this.viewModes = TableViewMode;
        this.viewMode = TableViewMode.TableMode;

        this.userService.currentUserRole.subscribe(() => {
            this.initRowActions();
            this.initBatchActions();
        });
    }

    public ngOnInit(): void {
        this.showArchiveColumnsOriginal = this.shownArchiveColumns =
            WorkQueueTableHelper.getDefaultArchiveColumns(this.excludeColumns);

        this.showColumnsOriginal = this.shownColumns =
            WorkQueueTableHelper.getDefaultColumns(this.excludeColumns);
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["workQueues"]) {
            this.paginatedWorkQueues = this.filteredWorkQueues =
                this.workQueues;
        }
    }

    public onTableBatchActionsReady(api: TableBatchActionsApi): void {
        this.workQueueTableService.initTableBatchActionsApi(api);
    }

    public onPaginatedItemsChanged(items: any[]): void {
        this.paginatedWorkQueues = items;
        this.changeDetectorRef.detectChanges();
    }

    public onMenuOpen(id: string): void {
        this.workQueueTableService.updateSelectedItemId(id);
    }

    public onMenuClose(): void {
        this.workQueueTableService.updateSelectedItemId(null);
    }

    public onSearchChange(value: string): void {
        this.search = value;
        this.applyFilters();
    }

    public onFiltersChange(value: any): void {
        this.filteredWorkQueues =
            WorkQueueTableHelper.filterWorkQueueItemsWithFilters(
                this.workQueues,
                value
            );
    }

    public onViewModeChange(viewMode: TableViewMode): void {
        this.viewMode = viewMode;
    }

    private initBatchActions(): void {
        this.batchActions = this.workQueueTableService.getBatchActions();
    }

    private initRowActions(): void {
        this.rowActions = this.workQueueTableService.getRowActions();
    }

    private applyFilters(): void {
        this.filteredWorkQueues =
            WorkQueueTableHelper.filterWorkQueueItemsWithSearch(
                this.workQueues,
                this.search
            );
    }
}
