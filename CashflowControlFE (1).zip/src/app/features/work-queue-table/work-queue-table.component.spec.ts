import { ComponentFixture, TestBed } from "@angular/core/testing";
import { SimpleChange } from "@angular/core";
import { MessageService } from "primeng/api";
import { DialogService } from "primeng/dynamicdialog";

import { WorkQueueTableHelper } from "./helpers/work-queue-table-helper";
import { WorkQueueTableComponent } from "./work-queue-table.component";
import { TableViewMode } from "../../shared/components/table-view-toggle/models/table-view-mode.enum";

describe("WorkQueueTableComponent", () => {
    let component: WorkQueueTableComponent;
    let fixture: ComponentFixture<WorkQueueTableComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [WorkQueueTableComponent],
            providers: [DialogService, MessageService],
        });
        fixture = TestBed.createComponent(WorkQueueTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should update shownColumns upon ngOnInit", () => {
        component.excludeColumns = ["id", "workQueueItems"];
        component.ngOnInit();
        expect(component.shownColumns).toEqual(
            WorkQueueTableHelper.getDefaultColumns(component.excludeColumns)
        );
    });

    it("should update paginatedWorkQueues and filteredWorkQueues upon workQueues changes", () => {
        component.workQueues = [
            {
                id: 1,
                name: "Work Queue 1",
                description: "Work Queue 1 Description",
                status: "Active",
                workQueueType: "Work Queue Type 1",
                workQueueItems: [],
            },
            {
                id: 2,
                name: "Work Queue 2",
                description: "Work Queue 2 Description",
                status: "Active",
                workQueueType: "Work Queue Type 2",
                workQueueItems: [],
            },
        ];
        component.ngOnChanges({
            workQueues: new SimpleChange(null, component.workQueues, true),
        });
        expect(component.paginatedWorkQueues).toEqual(component.workQueues);
        expect(component.filteredWorkQueues).toEqual(component.workQueues);
    });

    it("should update paginatedWorkQueues upon onPaginatedItemsChanged", () => {
        component.workQueues = [
            {
                id: 1,
                name: "Work Queue 1",
                description: "Work Queue 1 Description",
                status: "Active",
                workQueueType: "Work Queue Type 1",
                workQueueItems: [],
            },
            {
                id: 2,
                name: "Work Queue 2",
                description: "Work Queue 2 Description",
                status: "Active",
                workQueueType: "Work Queue Type 2",
                workQueueItems: [],
            },
        ];
        component.onPaginatedItemsChanged(component.workQueues);
        expect(component.paginatedWorkQueues).toEqual(component.workQueues);
    });

    it("should update viewMode upon onViewModeChange", () => {
        component.onViewModeChange(TableViewMode.GridMode);
        expect(component.viewMode).toBe(TableViewMode.GridMode);
    });
});
