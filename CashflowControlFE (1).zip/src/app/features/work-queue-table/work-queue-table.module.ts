import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { WorkQueueTableGridElementModule } from "../work-queue-table-grid-element/work-queue-table-grid-element.module";
import { QuickviewModule } from "../work-queue/quickview/quickview.module";
import { WorkQueueTableComponent } from "./work-queue-table.component";

@NgModule({
    imports: [SharedModule, QuickviewModule, WorkQueueTableGridElementModule],
    declarations: [WorkQueueTableComponent],
    exports: [WorkQueueTableComponent],
})
export class WorkQueueTableModule {}
