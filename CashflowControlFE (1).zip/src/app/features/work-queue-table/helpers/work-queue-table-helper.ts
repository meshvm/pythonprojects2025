import { TableToolbarFilterConfig } from "../../../shared/components/table-toolbar-filters/models/table-toolbar-filter-config.model";
import { WorkQueue } from "../../../shared/models/work-queues/work-queue.model";
import { WorkQueueActionModalConfig } from "../../work-queue-action-modal/models/work-queue-action-modal-config.model";
import { NgTableColumn } from "../../../shared/models/vendor/ng-table-column.model";

export class WorkQueueTableHelper {
    private static currentFilters: any = {};
    private static currentSearch: string = "";

    public static defaultDepositAndPostActionConfiguration: Partial<WorkQueueActionModalConfig> =
        {
            title: "Deposit & Post",
            text: "Are you sure you want to deposit & post the selected check(s)?",
            submitButtonText: "Deposit & Post",
        };

    public static defaultOnHoldActionConfiguration: Partial<WorkQueueActionModalConfig> =
        {
            title: "On Hold",
            text: "Are you sure you want to set the selected checks to “on hold”?",
            submitButtonText: "Set On Hold",
        };

    public static defaultResubmitActionConfiguration: Partial<WorkQueueActionModalConfig> =
        {
            title: "Resubmit",
            text: "Are you sure you to resubmit the selected checks?",
            submitButtonText: "Resubmit",
        };

    public static defaultDeleteActionConfiguration: Partial<WorkQueueActionModalConfig> =
        {
            title: "Delete address",
            text: "Are you sure you want to delete this address? This action cannot be undone.",
            submitButtonText: "Delete",
        };

    private static availableColumns: NgTableColumn[] = [
        {
            field: "status",
            header: "Status",
            width: "168px",
        },
        {
            field: "exceptions",
            header: "Exception Type",
            width: "147px",
        },
        {
            field: "datereceived",
            header: "Date Received",
            width: "142px",
        },
        {
            field: "CheckPayorName",
            header: "Payer Name",
            width: "167px",
        },
        {
            field: "CheckPayorAddress",
            header: "Payer address",
            width: "197px",
        },
        {
            field: "CheckAmount",
            header: "Check Amount",
            width: "145px",
        },
        {
            field: "quickview",
            header: "",
            fixed: true,
            width: "100px",
        },
        {
            field: "details",
            header: "",
            fixed: true,
            width: "100px",
        },
        {
            field: "actions",
            header: "",
            fixed: true,
            width: "80px",
        },
    ];
    private static archiveColumns: NgTableColumn[] = [
        {
            field: "batch",
            header: "Batch ID",
            width: "168px",
        },
        {
            field: "documentid",
            header: "Document ID",
            width: "147px",
        },
        {
            field: "datereceived",
            header: "Date Received",
            width: "142px",
        },
        {
            field: "ScanDate",
            header: "Scan Date Time",
            width: "167px",
        },
        {
            field: "PayorName",
            header: "Payer Name",
            width: "167px",
        },
        {
            field: "PayorAddress",
            header: "Payer address",
            width: "197px",
        },
        {
            field: "CheckAmount",
            header: "Check Amount",
            width: "145px",
        },
        {
            field: "quickview",
            header: "",
            fixed: true,
            width: "100px",
        },
        {
            field: "details",
            header: "",
            fixed: true,
            width: "100px",
        },
        {
            field: "actions",
            header: "",
            fixed: true,
            width: "80px",
        },
    ];
    private static filterConfigs: TableToolbarFilterConfig[] = [
        {
            name: "Status",
            title: "Status",
            dataLp: "dropdown_status",
            options: [
                {
                    name: "All",
                    value: "",
                },
                {
                    name: "New",
                    value: "New",
                },
                {
                    name: "Deposited",
                    value: "Deposited",
                },
                {
                    name: "Rejected",
                    value: "Rejected",
                },
                {
                    name: "On Hold",
                    value: "On Hold",
                },
                {
                    name: "Pending Approval",
                    value: "Pending Approval",
                },
            ],
        },
        {
            name: "Exception Type",
            options: [
                {
                    name: "All Types",
                    value: "",
                },
                {
                    name: "1 - Signature verification",
                    value: "1",
                },
                {
                    name: "2 - Amount discrepancies",
                    value: "2",
                },
                {
                    name: "3 - Non-standard check formats",
                    value: "3",
                },
                {
                    name: "4 - Unreadable MICR line",
                    value: "4",
                },
                {
                    name: "5 - Check date out of range",
                    value: "5",
                },
                {
                    name: "6 - Miscellaneous or invalid",
                    value: "6",
                },
                {
                    name: "7 - Unknown account",
                    value: "7",
                },
                {
                    name: "8 - High Donor",
                    value: "8",
                },
                {
                    name: "9 - Invalid account",
                    value: "9",
                },
            ],
            dataLp: "dropdown_exceptiontype",
            title: "Exception Type",
        },
    ];

    public static getAvailableColumns(): NgTableColumn[] {
        return [...this.availableColumns];
    }
    public static getArchiveColumns(): NgTableColumn[] {
        return [...this.archiveColumns];
    }

    public static getDefaultColumns(
        excludeColumns: string[] = []
    ): NgTableColumn[] {
        return [...this.availableColumns].filter(
            (col) => !excludeColumns.includes(col.field)
        );
    }

    public static getDefaultArchiveColumns(
        excludeColumns: string[] = []
    ): NgTableColumn[] {
        return [...this.archiveColumns].filter(
            (col) => !excludeColumns.includes(col.field)
        );
    }

    public static getFilterConfigs(): TableToolbarFilterConfig[] {
        return [...this.filterConfigs];
    }

    public static filterWorkQueueItemsWithFilters(
        items: WorkQueue[],
        filters: any
    ): WorkQueue[] {
        this.currentFilters = filters;
        return this.applyCombinedFilters(items);
    }

    public static filterWorkQueueItemsWithSearch(
        items: WorkQueue[],
        search: string
    ): WorkQueue[] {
        this.currentSearch = search;
        return this.applyCombinedFilters(items);
    }

    private static applyCombinedFilters(items: WorkQueue[]): WorkQueue[] {
        const excludedKeys = new Set(["demKey", "id", "PageKey", "images"]);
        let filteredItems = items;

        // Apply filterWorkQueueItemsWithFilters
        const filterCode = parseInt(this.currentFilters["Exception Type"], 10);
        if (filteredItems) {
            filteredItems = filteredItems.filter((item) => {
                const statusMatches = this.currentFilters["Status"]
                    ? item.status === this.currentFilters["Status"]
                    : true;
                const exceptionsMatches = filterCode
                    ? item.exceptions.some(
                          (exception) => exception["code"] === filterCode
                      )
                    : true;
                return statusMatches && exceptionsMatches;
            });
        }

        // Apply filterWorkQueueItemsWithSearch
        if (this.currentSearch) {
            filteredItems = filteredItems.filter((item) =>
                Object.entries(item).find(
                    ([key, value]) =>
                        typeof value === "string" &&
                        !excludedKeys.has(key) &&
                        value
                            .toLowerCase()
                            .includes(this.currentSearch.toLowerCase())
                )
            );
        }

        return filteredItems;
    }
}
