import { TestBed } from "@angular/core/testing";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { ToastrService } from "../../../shared/components/toastr/services/toastr.service";
import { WorkQueueTableService } from "./work-queue-table.service";

describe("WorkQueueTableService", () => {
    let service: WorkQueueTableService;
    let modalServiceMock: jasmine.SpyObj<ModalService>;
    let toastrServiceMock: jasmine.SpyObj<ToastrService>;

    beforeEach(() => {
        modalServiceMock = jasmine.createSpyObj("ModalService", ["openModal"]);
        toastrServiceMock = jasmine.createSpyObj("ToastrService", [
            "showSuccessMessage",
        ]);

        TestBed.configureTestingModule({
            providers: [
                WorkQueueTableService,
                { provide: ModalService, useValue: modalServiceMock },
                { provide: ToastrService, useValue: toastrServiceMock },
            ],
        });

        service = TestBed.inject(WorkQueueTableService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });
});
