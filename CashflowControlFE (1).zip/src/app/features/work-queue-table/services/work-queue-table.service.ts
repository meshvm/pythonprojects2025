import { Injectable, OnDestroy } from "@angular/core";
import { MenuItem } from "primeng/api";
import { WorkQueueActionModalConfig } from "../../work-queue-action-modal/models/work-queue-action-modal-config.model";
import { WorkQueueReturnCheckActionModalConfig } from "../../work-queue-action-modal/models/work-queue-return-check-action-modal-config.model";
import { WorkQueueReturnCheckaddressModalConfig } from "../../work-queue-action-modal/models/work-queue-return-check-address-modal-config.model";
import { WorkQueueReturnCheckValidateaddressModalConfig } from "../../work-queue-action-modal/models/work-queue-return-check-validate-address-modal-config.model";
import { WorkQueueActionModalManagerService } from "../../work-queue-action-modal/services/work-queue-action-modal-manager.service";
import { TableBatchAction } from "../../../shared/components/table-batch-actions-bar/models/table-batch-action.module";
import { TableBatchActionsApi } from "../../../shared/components/table-batch-actions/models/table-batch-actions-api.model";
import { ToastrService } from "../../../shared/components/toastr/services/toastr.service";
import { WorkQueueTableHelper } from "../helpers/work-queue-table-helper";
import { ReturnCheckaddressItem } from "../../../features/work-queue/return-check-modal/models/return-check-address-item.model";
import { WorkQueueActionModalButtonType } from "../../work-queue-action-modal/models/work-queue-action-modal-button-type.enum";
import { UserService } from "src/app/core/services/users.service";
import { UserRole } from "src/app/shared/models/users/user-roles.enum";
import { forkJoin, Observable, Subscription, from } from "rxjs";
import { map } from "rxjs/operators";
import { WorkQueueService } from "src/app/core/api-services/work-queue/work-queue.service";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import { LoaderService } from "src/app/core/services/loader.service";

@Injectable()
export class WorkQueueTableService implements OnDestroy {
    public currentUserRole: UserRole;
    private tableBatchActionsApi: TableBatchActionsApi;
    private selectedItemId: string | null;
    private selectedItemSet: Set<string> = new Set<string>();
    private userRoleSubscription: Subscription;
    public BatchID: string;
    public ReleaseDate: string;
    public CompanyID: number;
    public Transacion: number;

    constructor(
        private workQueueActionModalManagerService: WorkQueueActionModalManagerService,
        private toastrService: ToastrService,
        private userService: UserService,
        private workQueueService: WorkQueueService,
        private loaderService: LoaderService
    ) {
        this.userRoleSubscription = this.userService.currentUserRole.subscribe(
            (role) => {
                this.currentUserRole = role;
            }
        );
    }

    ngOnDestroy() {
        if (this.userRoleSubscription) {
            this.userRoleSubscription.unsubscribe();
        }
    }

    public initTableBatchActionsApi(api: TableBatchActionsApi): void {
        this.tableBatchActionsApi = api;
    }

    public updateSelectedItemId(id: string | null): void {
        if (id) {
            this.selectedItemId = id;
        }
    }

    public updateSelectedItemsSet(items: Set<string>): void {
        this.selectedItemSet = items;
    }

    public getRowActions(): MenuItem[] {
        return [
            // {
            //     label: "Deposit & Post",
            //     command: () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            //                 checksSelectedCount: 1,
            //                 submitCallback: this.onDepositAndPost.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            // {
            //     label: "Return Check",
            //     command: () => {
            //         this.workQueueActionModalManagerService.openReturnCheckModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            //                 checksSelectedCount: 1,
            //                 submitCallback:
            //                     this.onReturnToThisaddress.bind(this),
            //                 deleteCallback: this.onDeleteaddress.bind(this),
            //                 enterNewaddressCallback:
            //                     this.onEnterNewaddress.bind(this),
            //                 editaddressCallback: this.onEditaddress.bind(this),
            //             } as WorkQueueReturnCheckActionModalConfig
            //         );
            //     },
            // },
            // {
            //     label: "On Hold",
            //     command: () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultOnHoldActionConfiguration,
            //                 checksSelectedCount: 1,
            //                 submitCallback: this.onPutOnHold.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            // {
            //     label: "Resubmit",
            //     command: () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultResubmitActionConfiguration,
            //                 checksSelectedCount: 1,
            //                 submitCallback: this.onResubmit.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            {
                label: "Export",
                command: async () => {
                    this.workQueueActionModalManagerService.openExportModal({
                        ...WorkQueueTableHelper.defaultResubmitActionConfiguration,
                        checksSelectedCount: 1,
                        submitCallback: this.onExport.bind(this),
                    } as WorkQueueActionModalConfig);
                },
                disabled:
                    this.currentUserRole !== UserRole.manager &&
                    this.currentUserRole !== UserRole.executive,
                styleClass:
                    this.currentUserRole !== UserRole.manager &&
                    this.currentUserRole !== UserRole.executive
                        ? "disabled"
                        : "",
            },
        ];
    }

    public getBatchActions(): TableBatchAction[] {
        return [
            // {
            //     iconPath: "assets/icons/custom/send.svg",
            //     name: "Deposit & Post",
            //     callback: async () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            //                 checksSelectedCount:
            //                     await this.tableBatchActionsApi.getBatchSelectionItemsCount$(),
            //                 submitCallback: this.onDepositAndPost.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            // {
            //     iconPath: "assets/icons/custom/reply.svg",
            //     name: "Return Check",
            //     callback: async () => {
            //         this.workQueueActionModalManagerService.openReturnCheckModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            //                 checksSelectedCount:
            //                     await this.tableBatchActionsApi.getBatchSelectionItemsCount$(),
            //                 submitCallback:
            //                     this.onReturnToThisaddress.bind(this),
            //                 deleteCallback: this.onDeleteaddress.bind(this),
            //                 enterNewaddressCallback:
            //                     this.onEnterNewaddress.bind(this),
            //                 editaddressCallback: this.onEditaddress.bind(this),
            //             } as WorkQueueReturnCheckActionModalConfig
            //         );
            //     },
            // },
            // {
            //     iconPath: "assets/icons/custom/pause.svg",
            //     name: "Place On Hold",
            //     callback: async () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultOnHoldActionConfiguration,
            //                 checksSelectedCount:
            //                     await this.tableBatchActionsApi.getBatchSelectionItemsCount$(),
            //                 submitCallback: this.onPutOnHold.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            // {
            //     iconPath: "assets/icons/custom/refresh.svg",
            //     name: "Resubmit",
            //     callback: async () => {
            //         this.workQueueActionModalManagerService.openSupportRequestModal(
            //             {
            //                 ...WorkQueueTableHelper.defaultResubmitActionConfiguration,
            //                 checksSelectedCount:
            //                     await this.tableBatchActionsApi.getBatchSelectionItemsCount$(),
            //                 submitCallback: this.onResubmit.bind(this),
            //             } as WorkQueueActionModalConfig
            //         );
            //     },
            // },
            {
                iconPath: "assets/icons/custom/download.svg",
                name: "Export",
                callback: async () => {
                    this.workQueueActionModalManagerService.openExportModal({
                        ...WorkQueueTableHelper.defaultResubmitActionConfiguration,
                        checksSelectedCount:
                            await this.tableBatchActionsApi.getBatchSelectionItemsCount$(),
                        submitCallback: this.onExport.bind(this),
                    } as WorkQueueActionModalConfig);
                },
                disabled:
                    this.currentUserRole !== UserRole.manager &&
                    this.currentUserRole !== UserRole.executive,
                styleClass:
                    this.currentUserRole !== UserRole.manager &&
                    this.currentUserRole !== UserRole.executive
                        ? "disabled"
                        : "",
            },
        ];
    }

    private onDepositAndPost(itemsCount: number = 1): void {
        this.toastrService.showSuccessMessage(
            `${itemsCount} check(s) submitted for Deposit & Post`
        );
    }

    private onPutOnHold(itemsCount: number = 1): void {
        this.toastrService.showSuccessMessage(
            `${itemsCount} check(s) submitted to Put On Hold`
        );
    }

    private onResubmit(itemsCount: number = 1): void {
        this.toastrService.showSuccessMessage(
            `${itemsCount} check(s) sent for Resubmit`
        );
    }

    private onDelete(address: ReturnCheckaddressItem): void {
        this.toastrService.showSuccessMessage(
            "address has been successfully deleted"
        );
    }

    private onReturnToThisaddress(address: ReturnCheckaddressItem): void {}

    private onDeleteaddress(
        address: ReturnCheckaddressItem,
        itemsCount: number
    ): void {
        this.workQueueActionModalManagerService.openSupportRequestModal({
            ...WorkQueueTableHelper.defaultDeleteActionConfiguration,
            buttonType: WorkQueueActionModalButtonType.Delete,
            deleteCallback: this.onDelete.bind(this),
            closeCallback: this.onCloseCallback.bind(this),
            checksSelectedCount: itemsCount,
            address,
        } as WorkQueueActionModalConfig);
    }

    private onEnterNewaddress(itemsCount: number = 1): void {
        this.workQueueActionModalManagerService.openReturnCheckaddressModal({
            ...WorkQueueTableHelper.defaultDeleteActionConfiguration,
            submitCallback: this.onValidateaddress.bind(this),
            closeCallback: this.onCloseCallback.bind(this),
            checksSelectedCount: itemsCount,
            isValidated: false,
        } as WorkQueueReturnCheckaddressModalConfig);
    }

    private onEditaddress(
        address: ReturnCheckaddressItem,
        itemsCount: number = 1
    ): void {
        this.workQueueActionModalManagerService.openReturnCheckaddressModal({
            ...WorkQueueTableHelper.defaultDeleteActionConfiguration,
            submitCallback: this.onValidateaddress.bind(this),
            closeCallback: this.onCloseCallback.bind(this),
            isValidated: false,
            isEditing: true,
            address,
            checksSelectedCount: itemsCount,
        } as WorkQueueReturnCheckaddressModalConfig);
    }

    private onCloseCallback(itemsCount: number = 1): void {
        this.workQueueActionModalManagerService.openReturnCheckModal({
            ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            checksSelectedCount: itemsCount,
            submitCallback: this.onReturnToThisaddress.bind(this),
            deleteCallback: this.onDeleteaddress.bind(this),
            enterNewaddressCallback: this.onEnterNewaddress.bind(this),
            editaddressCallback: this.onEditaddress.bind(this),
        } as WorkQueueReturnCheckActionModalConfig);
    }

    private onValidateaddress(
        itemsCount: number = 1,
        address: ReturnCheckaddressItem
    ): void {
        this.workQueueActionModalManagerService.openValidateaddressModal({
            ...WorkQueueTableHelper.defaultDepositAndPostActionConfiguration,
            checksSelectedCount: itemsCount,
            submitCallback: this.onFindaddress.bind(this),
            closeCallback: this.onCloseValidateaddressCallback.bind(this),
            address,
        } as WorkQueueReturnCheckValidateaddressModalConfig);
    }

    private onCloseValidateaddressCallback(
        itemsCount: number = 1,
        address: ReturnCheckaddressItem
    ): void {
        this.workQueueActionModalManagerService.openReturnCheckaddressModal({
            ...WorkQueueTableHelper.defaultDeleteActionConfiguration,
            submitCallback: this.onValidateaddress.bind(this),
            closeCallback: this.onCloseCallback.bind(this),
            address,
            checksSelectedCount: itemsCount,
        } as WorkQueueReturnCheckaddressModalConfig);
    }

    private onFindaddress(
        itemsCount: number = 1,
        address: ReturnCheckaddressItem
    ): void {
        this.workQueueActionModalManagerService.openReturnCheckaddressModal({
            ...WorkQueueTableHelper.defaultDeleteActionConfiguration,
            submitCallback: this.onValidateaddress.bind(this),
            closeCallback: this.onCloseCallback.bind(this),
            saveCallback: this.onSaveCallback.bind(this),
            isValidated: true,
            address,
            checksSelectedCount: itemsCount,
        } as WorkQueueReturnCheckaddressModalConfig);
    }

    private onSaveCallback(): void {
        this.toastrService.showSuccessMessage(
            "address has been successfully added"
        );
    }

    private onExport(itemsCount: number = 1, fileName: string): void {
        const allImages: any[] = [];
        const workQueueObservables: Observable<any>[] = [];

        let workQueue: any;
        if (this.selectedItemSet.size > 0) {
            this.selectedItemSet.forEach((demKey) => {
                let data = JSON.stringify(demKey);
                console.log("data", data);
                if (data.includes("ReleaseDate")) {
                    const parsedObject = JSON.parse(data);
                    this.BatchID = parsedObject.BatchID;
                    this.ReleaseDate = parsedObject.ReleaseDate;
                    this.CompanyID = parsedObject.CompanyID;
                    this.Transacion = parsedObject.Transaction;

                    const observable = from(
                        this.workQueueService.getArchiveImages(
                            this.BatchID,
                            this.ReleaseDate,
                            this.CompanyID,
                            this.Transacion
                        )
                    ).pipe(
                        map((response: any) => {
                            if (
                                response.result.Images &&
                                response.result.Images.length > 0
                            ) {
                                // workQueue.images = response.result.Images;
                                response.result.Images.forEach((image: any) => {
                                    allImages.push(image);
                                });
                            }
                        })
                    );
                    // workQueueObservables.push(...observable);
                    this.loaderService.setLoading(false);
                } else {
                    workQueue = this.workQueueService.searchByDemKey(demKey);
                    console.log("workQueue --- ", workQueue.AllPageKeys);
                    if (workQueue) {
                        if (
                            !workQueue.images ||
                            workQueue.images.length === 0
                        ) {
                            this.loaderService.setLoading(true);
                            const observables = workQueue.AllPageKeys.map(
                                (key: number) =>
                                    this.workQueueService
                                        .getBatchImages(workQueue.demKey, key)
                                        .pipe(
                                            map((response: any) => {
                                                if (
                                                    response.result.Images &&
                                                    response.result.Images
                                                        .length > 0
                                                ) {
                                                    workQueue.images =
                                                        response.result.Images;
                                                    this.workQueueService.updateWorkQueueMap(
                                                        workQueue.demKey,
                                                        workQueue
                                                    );
                                                    response.result.Images.forEach(
                                                        (image: any) => {
                                                            if (
                                                                image.Depth ===
                                                                "BITONAL"
                                                            ) {
                                                                allImages.push(
                                                                    image
                                                                );
                                                            }
                                                        }
                                                    );
                                                }
                                            })
                                        )
                            );
                            workQueueObservables.push(...observables);
                        } else {
                            allImages.push(...workQueue.images);
                        }
                    }
                }
            });

            if (workQueueObservables.length > 0) {
                forkJoin(workQueueObservables).subscribe(() => {
                    this.downloadImages(allImages, fileName, itemsCount);
                });
            } else {
                this.downloadImages(allImages, fileName, itemsCount);
            }
        } else if (this.selectedItemId) {
            workQueue = this.workQueueService.searchByDemKey(
                this.selectedItemId
            );
            if (workQueue) {
                if (!workQueue.images || workQueue.images.length === 0) {
                    this.loaderService.setLoading(true);
                    const observables = workQueue.AllPageKeys.map(
                        (key: number) =>
                            this.workQueueService.getBatchImages(
                                workQueue.demKey,
                                key
                            )
                    );

                    forkJoin(observables).subscribe((responses: any) => {
                        responses.forEach((response: any) => {
                            if (
                                response.result.Images &&
                                response.result.Images.length > 0
                            ) {
                                response.result.Images.forEach((image: any) => {
                                    if (image.Depth === "BITONAL") {
                                        allImages.push(image);
                                    }
                                });
                            }
                        });

                        if (allImages.length > 0) {
                            workQueue.images = allImages;
                            this.workQueueService.updateWorkQueueMap(
                                workQueue.demKey,
                                workQueue
                            );
                            this.downloadImages(
                                allImages,
                                fileName,
                                itemsCount
                            );
                        }
                    });
                } else {
                    this.downloadImages(workQueue.images, fileName, itemsCount);
                }
            }
        }
    }

    private downloadImages(
        images: any[],
        fileName: string,
        itemsCount: number
    ): void {
        const zip = new JSZip();
        const imgFolder = zip.folder(fileName);
        console.log("Images  ---  ", images);
        if (imgFolder) {
            images.forEach((image, index) => {
                const imgData = image.ImageData;
                imgFolder.file(
                    `${image.ImageName || `${fileName}_${index}`}.png`,
                    imgData,
                    { base64: true }
                );
            });
        }

        this.toastrService.showSuccessMessage(
            `${itemsCount} ${
                itemsCount > 1 ? "records are" : "record is"
            } exported`
        );

        zip.generateAsync({ type: "blob" }).then((content) => {
            this.loaderService.setLoading(false);
            saveAs(content, `${fileName}.zip`);
        });
    }
}
