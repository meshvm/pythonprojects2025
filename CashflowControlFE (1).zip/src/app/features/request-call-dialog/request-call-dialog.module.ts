import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RequestCallDialogComponent } from "./request-call-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [RequestCallDialogComponent],
    exports: [RequestCallDialogComponent],
})
export class RequestCallDialogModule {}
