import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { LabeledValue } from "../../core/models/labeled-value.model";

@Component({
    selector: "cc-request-call-dialog",
    templateUrl: "./request-call-dialog.component.html",
    styleUrls: ["./request-call-dialog.component.scss"],
})
export class RequestCallDialogComponent {
    public requestTypeId: string;
    public requestDescription: string;
    public phoneNumber: string;
    public additionalDetails: string;
    public typeOptions: LabeledValue[];

    constructor(
        public dialogRef: MatDialogRef<RequestCallDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {
        this.requestTypeId = "";
        this.requestDescription = "";
        this.phoneNumber = "";
        this.additionalDetails = "";

        this.typeOptions = [];
    }

    public closeDialog(): void {
        this.dialogRef.close();
    }
}
