import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { BillingOptionsTableComponent } from "./billing-options-table.component";

@NgModule({
    imports: [SharedModule],
    declarations: [BillingOptionsTableComponent],
    exports: [BillingOptionsTableComponent],
})
export class BillingOptionsTableModule {}
