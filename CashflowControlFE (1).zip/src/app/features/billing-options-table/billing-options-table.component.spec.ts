import { ComponentFixture, TestBed } from "@angular/core/testing";

import { BillingOptionsTableComponent } from "./billing-options-table.component";

describe("BillingOptionsTableComponent", () => {
    let component: BillingOptionsTableComponent;
    let fixture: ComponentFixture<BillingOptionsTableComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [BillingOptionsTableComponent],
        });
        fixture = TestBed.createComponent(BillingOptionsTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
