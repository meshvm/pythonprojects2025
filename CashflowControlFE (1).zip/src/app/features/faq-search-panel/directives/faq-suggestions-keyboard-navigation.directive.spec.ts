import { Component, DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import {
    AngularSvgIconModule,
    SvgIconRegistryService,
    SvgLoader,
} from "angular-svg-icon";
import { Dropdown, DropdownModule } from "primeng/dropdown";
import { ToastModule } from "primeng/toast";
import { of } from "rxjs";
import { UnitTestsHelper } from "../../../shared/helpers/unit-tests/unit-tests-helper";
import { FaqSuggestionsKeyboardNavigationDirective } from "./faq-suggestions-keyboard-navigation.directive";

@Component({
    template: `<div
        [ccFaqSearchSuggestionsKeyboardNavigation]="options"
        #dropdown
    ></div>`,
})
class TestHostComponent {
    options = [
        { name: "Option1", value: "Value1" },
        { name: "Option2", value: "Value2" },
    ];
}

describe("FaqSuggestionsKeyboardNavigationDirective", () => {
    let fixture: ComponentFixture<TestHostComponent>;
    let directiveEl: DebugElement;
    let directiveInstance: FaqSuggestionsKeyboardNavigationDirective;

    const mockSvgLoader = UnitTestsHelper.createMockSvgLoader();
    const mockDropdown = {
        onShow: of("mock-on-show"),
        hide: () => {},
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [DropdownModule, ToastModule, AngularSvgIconModule],
            declarations: [
                TestHostComponent,
                FaqSuggestionsKeyboardNavigationDirective,
            ],
            providers: [
                SvgIconRegistryService,
                { provide: SvgLoader, useValue: mockSvgLoader },
                { provide: Dropdown, useValue: mockDropdown },
            ],
        });
        fixture = TestBed.createComponent(TestHostComponent);
        directiveEl = fixture.debugElement.query(
            By.directive(FaqSuggestionsKeyboardNavigationDirective)
        );
        directiveInstance = directiveEl.injector.get(
            FaqSuggestionsKeyboardNavigationDirective
        );
        fixture.detectChanges();
    });

    it("should create an instance", () => {
        expect(directiveInstance).toBeTruthy();
    });
});
