import {
    DestroyRef,
    Directive,
    ElementRef,
    EventEmitter,
    HostListener,
    inject,
    Input,
    OnChanges,
    Output,
    SimpleChanges,
} from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { Dropdown } from "primeng/dropdown";
import { NamedValue } from "../../../shared/models/base/named-value.model";

@Directive({
    selector: "[ccFaqSearchSuggestionsKeyboardNavigation]",
})
export class FaqSuggestionsKeyboardNavigationDirective implements OnChanges {
    private static selectedClass =
        "cc-faq-search-panel__suggestion-option--focused";
    private static nodeSelector = ".p-dropdown-item";

    @Input()
    public dropdownOptions: NamedValue[];
    @Input()
    public searchInput: HTMLInputElement;

    @Output()
    public itemSelected: EventEmitter<NamedValue>;

    public focusedNode: number;

    private destroyRef: DestroyRef;

    @HostListener("window:keydown.arrowdown", ["$event"])
    public onArrowDown(event: KeyboardEvent): void {
        if (this.optionNodes.length - 1 === this.focusedNode) {
            return;
        }

        this.focusedNode += 1;
        this.setFocusedClass();

        event.preventDefault();
        event.stopPropagation();
    }

    @HostListener("window:keydown.arrowup", ["$event"])
    public onArrowUp(event: KeyboardEvent): void {
        if (this.focusedNode === -1) {
            return;
        }

        this.focusedNode -= 1;
        this.setFocusedClass();

        event.preventDefault();
        event.stopPropagation();
    }

    @HostListener("window:keydown.enter", ["$event"])
    public onEnterPressed(): void {
        const item = this.dropdownOptions[this.focusedNode];

        if (!item) {
            return;
        }

        this.itemSelected.emit(item);
        this.hostComponent.hide();
    }

    constructor(
        private hostElement: ElementRef<HTMLElement>,
        private hostComponent: Dropdown
    ) {
        this.itemSelected = new EventEmitter<NamedValue>();
        this.destroyRef = inject(DestroyRef);
        this.subscribeToPopupOpen();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["dropdownOptions"] && this.dropdownOptions?.length) {
            setTimeout(() => this.resetFocusedElement());
        }
    }

    private get optionNodes(): HTMLElement[] {
        return Array.from(
            this.hostElement.nativeElement.querySelectorAll(
                FaqSuggestionsKeyboardNavigationDirective.nodeSelector
            )
        );
    }

    private subscribeToPopupOpen(): void {
        this.hostComponent.onShow
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.resetFocusedElement());
    }

    private resetFocusedElement(): void {
        this.focusedNode = -1;

        this.setFocusedClass();
    }

    private setFocusedClass(): void {
        this.optionNodes.forEach((node) =>
            node.classList.remove(
                FaqSuggestionsKeyboardNavigationDirective.selectedClass
            )
        );

        const focusedNode = this.optionNodes[this.focusedNode];

        focusedNode?.classList.add(
            FaqSuggestionsKeyboardNavigationDirective.selectedClass
        );

        focusedNode?.scrollIntoView({
            behavior: "smooth",
            block: "nearest",
            inline: "start",
        });
    }
}
