import {
    Component,
    DestroyRef,
    EventEmitter,
    inject,
    OnInit,
    Output,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { ActivatedRoute, Router } from "@angular/router";
import { Dropdown } from "primeng/dropdown";
import { debounceTime, Subject } from "rxjs";
import { NamedValue } from "../../shared/models/base/named-value.model";
import { FaqSearchPanelHelper } from "./helpers/faq-search-panel-helper";

@Component({
    selector: "cc-faq-search-panel",
    templateUrl: "./faq-search-panel.component.html",
    styleUrls: ["./faq-search-panel.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class FaqSearchPanelComponent implements OnInit {
    private static searchUrlParamName: string = "search";

    @ViewChild(Dropdown)
    public dropdownComponent: Dropdown;

    @Output()
    public searchChange: EventEmitter<string>;

    public searchText: string;
    public searchSuggestionOptions: NamedValue[];

    private searchTextChangeSubject: Subject<void>;
    private destroyRef: DestroyRef;

    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router
    ) {
        this.searchChange = new EventEmitter<string>();
        this.searchTextChangeSubject = new Subject<void>();
        this.destroyRef = inject(DestroyRef);

        this.searchSuggestionOptions =
            FaqSearchPanelHelper.searchSuggestionItems;

        this.subscribeToSearchTextChangeSubject();
    }

    public async ngOnInit(): Promise<void> {
        await this.subscribeToSearchParamFromUrl();
    }

    public onSearchSubmit(): void {
        this.searchChange.emit(this.searchText);

        this.router.navigate([], {
            relativeTo: this.activatedRoute,
            queryParams: { search: this.searchText },
            queryParamsHandling: "merge",
            skipLocationChange: false,
        });
    }

    public selectedSearchSuggestionChange(value: NamedValue): void {
        this.searchText = value?.value || "";
        this.onSearchSubmit();
    }

    public onInputFocus(): void {
        this.filterSuggestionOptions();
    }

    public onInputBlur(): void {
        setTimeout(() => this.closeDropdown());
    }

    public onSearchTextChange(): void {
        this.searchTextChangeSubject.next();
    }

    private filterSuggestionOptions(): void {
        const searchString = this.searchText?.toLowerCase() || "";
        this.searchSuggestionOptions =
            FaqSearchPanelHelper.searchSuggestionItems.filter(
                (option) =>
                    option.name.toLowerCase().includes(searchString) ||
                    option.value.toLowerCase().includes(searchString)
            );

        if (!this.searchSuggestionOptions?.length) {
            this.closeDropdown();
        }

        if (this.searchSuggestionOptions.length) {
            this.openDropdown();
        }
    }

    private openDropdown(): void {
        this.dropdownComponent.show();
    }

    private closeDropdown(): void {
        this.dropdownComponent.hide();
        this.dropdownComponent.selectedOption(null);
    }

    private async subscribeToSearchParamFromUrl(): Promise<void> {
        this.activatedRoute.queryParams.subscribe((params) => {
            this.searchText =
                params[FaqSearchPanelComponent.searchUrlParamName];
            this.searchChange.emit(this.searchText);
        });
    }

    private subscribeToSearchTextChangeSubject(): void {
        this.searchTextChangeSubject
            .pipe(takeUntilDestroyed(this.destroyRef), debounceTime(100))
            .subscribe(() => this.filterSuggestionOptions());
    }
}
