import { CommonModule } from "@angular/common";
import {
    ComponentFixture,
    TestBed,
    fakeAsync,
    tick,
} from "@angular/core/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { ActivatedRoute, Router } from "@angular/router";
import {
    AngularSvgIconModule,
    SvgIconRegistryService,
    SvgLoader,
} from "angular-svg-icon";
import { DropdownModule } from "primeng/dropdown";
import { UnitTestsHelper } from "../../shared/helpers/unit-tests/unit-tests-helper";
import { FaqSearchPanelComponent } from "./faq-search-panel.component";
import { FaqSearchPanelModule } from "./faq-search-panel.module";

describe("FaqSearchPanelComponent", () => {
    let component: FaqSearchPanelComponent;
    let fixture: ComponentFixture<FaqSearchPanelComponent>;

    const [queryParams, activatedRouteMock] =
        UnitTestsHelper.createActivatedRouteMock();
    const routerMock = UnitTestsHelper.createRouterMock();
    const mockSvgLoader = UnitTestsHelper.createMockSvgLoader();

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule,
                AngularSvgIconModule,
                DropdownModule,
                CommonModule,
                BrowserModule,
                FaqSearchPanelModule,
            ],
            declarations: [FaqSearchPanelComponent],
            providers: [
                { provide: ActivatedRoute, useValue: activatedRouteMock },
                { provide: Router, useValue: routerMock },
                SvgIconRegistryService,
                { provide: SvgLoader, useValue: mockSvgLoader },
            ],
        });
        fixture = TestBed.createComponent(FaqSearchPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should subscribe to search parameter from URL on init", fakeAsync(() => {
        queryParams.next({ search: "testQuery" });
        tick();
        expect(component.searchText).toBe("testQuery");
    }));

    it("should emit searchChange event on search text change", () => {
        spyOn(component.searchChange, "emit");
        component.onSearchSubmit();
        expect(component.searchChange.emit).toHaveBeenCalledWith(
            component.searchText
        );
    });

    it("should navigate to new route on search submit", () => {
        component.searchText = "newSearch";
        component.onSearchSubmit();
        expect(routerMock.navigate).toHaveBeenCalled();
    });
});
