import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { WorkQueueNavigationExtractCounterPipe } from "./pipes/work-queue-navigation-extract-counter.pipe";
import { WorkQueueNavigationBarComponent } from "./work-queue-navigation-bar.component";

@NgModule({
    imports: [SharedModule],
    declarations: [
        WorkQueueNavigationBarComponent,
        WorkQueueNavigationExtractCounterPipe,
    ],
    exports: [WorkQueueNavigationBarComponent],
})
export class WorkQueueNavigationBarModule {}
