import { Component, Input, ViewEncapsulation } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { MenuItem } from "primeng/api";
// import { WorkQueuePageCounters } from "./models/work-queue-page-counters.model";
import { WorkQueuePageName } from "./models/work-queue-page-name.enum";
import { WorkQueueService } from "src/app/core/api-services/work-queue/work-queue.service";
import { UserService } from "src/app/core/services/users.service";

@Component({
    selector: "cc-work-queue-navigation-bar",
    templateUrl: "./work-queue-navigation-bar.component.html",
    styleUrls: ["./work-queue-navigation-bar.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class WorkQueueNavigationBarComponent {
    private static readonly navigationItems: MenuItem[] = [
        // {
        //     title: WorkQueuePageName.All,
        //     routerLink: "all",
        // },
        {
            title: WorkQueuePageName.Exceptions,
            routerLink: "all",
        },
        // {
        //     title: WorkQueuePageName.PendingApproval,
        //     routerLink: "pending-approval",
        // },
        // {
        //     title: WorkQueuePageName.OnHold,
        //     routerLink: "on-hold",
        // },
        {
            title: WorkQueuePageName.Archive,
            routerLink: "archive",
        },
    ];

    @Input()
    public counters: number;
    @Input()
    public archivecounter: number;

    public readonly navigationItems: MenuItem[];
    public companyId: any;
    public activeNavigationItem: MenuItem;

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private workQueueService: WorkQueueService,
        private userService: UserService
    ) {
        this.navigationItems = WorkQueueNavigationBarComponent.navigationItems;
        workQueueService.workQueueMap$.subscribe((workQueueMap) => {
            this.counters = workQueueMap.size;
        });
        this.companyId = localStorage.getItem("companyId");
        if (this.companyId > 0) {
            workQueueService
                .getArchiveArray(this.companyId)
                .subscribe((workQueuesArray: any[]) => {
                    this.archivecounter = workQueuesArray.length;
                });
        }
    }

    public onActiveItemChange(event: MenuItem) {
        this.activeNavigationItem = event;
        this.router.navigate([
            `IBP_User/customer/${this.userService.currentCompanyIdValue}/work-queue/${event.routerLink}`,
        ]);
    }
}
