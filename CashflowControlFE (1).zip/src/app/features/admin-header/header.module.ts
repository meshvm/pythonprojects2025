import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { HeaderCartModule } from "../header-cart/header-cart.module";
import { RequestCallDialogModule } from "../request-call-dialog/request-call-dialog.module";
import { SendMessageDialogModule } from "../send-message-dialog/send-message-dialog.module";
import { HeaderAdminComponent } from "./header.component";

@NgModule({
    imports: [
        SharedModule,
        RequestCallDialogModule,
        SendMessageDialogModule,
        HeaderCartModule,
    ],
    declarations: [HeaderAdminComponent],
    exports: [HeaderAdminComponent],
})
export class HeaderAdminModule {}
