import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { DisableServiceConfirmDialogComponent } from "./disable-service-confirm-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [DisableServiceConfirmDialogComponent],
    exports: [DisableServiceConfirmDialogComponent],
})
export class DisableServiceConfirmDialogModule {}
