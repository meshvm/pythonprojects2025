import { Component, Inject, Input } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { getLPAttr } from "src/app/core/utils/leapwork";

@Component({
    selector: "cc-disable-service-confirm-dialog",
    templateUrl: "./disable-service-confirm-dialog.component.html",
    styleUrls: ["./disable-service-confirm-dialog.component.scss"],
})
export class DisableServiceConfirmDialogComponent {
    @Input()
    public title: string;
    @Input()
    public message: string;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        public dialogRef: MatDialogRef<DisableServiceConfirmDialogComponent>
    ) {
        this.title = this.data?.title || "";
        this.message = this.data?.message || "";
    }

    public onClose(): void {
        this.dialogRef.close();
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
