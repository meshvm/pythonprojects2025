import { ComponentFixture, TestBed } from "@angular/core/testing";
import { DisableServiceConfirmDialogComponent } from "./disable-service-confirm-dialog.component";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";

describe("DisableServiceConfirmDialogComponent", () => {
    let component: DisableServiceConfirmDialogComponent;
    let fixture: ComponentFixture<DisableServiceConfirmDialogComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [DisableServiceConfirmDialogComponent],
            providers: [
                { provide: MAT_DIALOG_DATA, useValue: {} },
                { provide: MatDialogRef, useValue: {} },
            ],
        });
        fixture = TestBed.createComponent(DisableServiceConfirmDialogComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
