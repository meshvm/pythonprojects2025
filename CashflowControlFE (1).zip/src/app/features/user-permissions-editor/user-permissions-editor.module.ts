import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { AssignTeamsDialogModule } from "../assign-teams-dialog/assign-teams-dialog.module";
import { ChangeRoleDialogModule } from "../change-role-dialog/change-role-dialog.module";
import { ChangeServiceAccessModule } from "../change-service-access-dialog/change-service-access.module";
import { ExtractTeamNamesPipe } from "./pipes/extract-team-names.pipe";
import { UserPermissionsEditorComponent } from "./user-permissions-editor.component";

@NgModule({
    imports: [
        SharedModule,
        AssignTeamsDialogModule,
        ChangeRoleDialogModule,
        ChangeServiceAccessModule,
    ],
    declarations: [UserPermissionsEditorComponent, ExtractTeamNamesPipe],
    exports: [UserPermissionsEditorComponent],
})
export class UserPermissionsEditorModule {}
