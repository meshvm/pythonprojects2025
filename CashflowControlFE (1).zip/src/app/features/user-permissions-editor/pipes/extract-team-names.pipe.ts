import { Injectable, Pipe, PipeTransform } from "@angular/core";
import { UserTeam } from "../../../core/api-services/user-permission/models/teams/user-team.model";

@Injectable({
    providedIn: "root",
})
@Pipe({
    name: "extractTeamNames",
})
export class ExtractTeamNamesPipe implements PipeTransform {
    public transform(value: UserTeam[]): string[] {
        return value?.map((team) => team?.TeamName || "") || [];
    }
}
