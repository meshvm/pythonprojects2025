import { AfterViewInit, Component, Input, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatPaginatorIntl } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { ActivatedRoute } from "@angular/router";
import { Project } from "src/app/core/models/project.model";
import { PaginatorIntlProvider } from "src/app/core/providers/paginatorIntl.provider";
import { LoaderService } from "src/app/core/services/loader.service";
import { NotificationService } from "src/app/core/services/notification.service";
import { SERVICE_ID } from "src/app/core/utils";
import { GetUserPermissionsDto } from "../../core/api-services/user-permission/models/get-user-permissions-dto.model";
import { UserTeam } from "../../core/api-services/user-permission/models/teams/user-team.model";
import { UserPermissionApiService } from "../../core/api-services/user-permission/user-permission-api.service";
import { FormOption } from "../../core/models/form-option.model";
import { UserDetails } from "../../core/models/user-details.model";
import { PaginatorHelper } from "../../shared/components/paginator-admin/helpers/paginator-helper";
import { PaginationState } from "../../shared/components/paginator-admin/models/pagination-state.model";
import { AssignTeamsDialogComponent } from "../assign-teams-dialog/assign-teams-dialog.component";
import { ChangeRoleDialogComponent } from "../change-role-dialog/change-role-dialog.component";
import { ChangeServiceAccessDialogComponent } from "../change-service-access-dialog/change-service-access.component";
import { FormControl } from "@angular/forms";
import { debounceTime, distinctUntilChanged, filter } from "rxjs/operators";
import { get } from "http";
import { NavigationHelper } from "src/app/core/helpers/navigation-helper";

@Component({
    selector: "cc-user-permissions-editor",
    providers: [{ provide: MatPaginatorIntl, useClass: PaginatorIntlProvider }],
    templateUrl: "./user-permissions-editor.component.html",
    styleUrls: ["./user-permissions-editor.component.scss"],
})
export class UserPermissionsEditorComponent implements AfterViewInit {
    @Input()
    public companyId: number;
    @ViewChild(MatSort)
    public sort: any = MatSort;

    searchControl: FormControl = new FormControl();

    public teamsList: UserTeam[] = [];
    public teamSelect: any[] = [];
    public accessList = [
        {
            label: "All",
            value: 2,
        },
        {
            label: "Active",
            value: 1,
        },
        {
            label: "Inactive",
            value: 0,
        },
    ];
    public userList: UserDetails[] = [];
    public loading = false;
    public filterConfig: any = {
        searchKeyword: "",
        pageData: {},
        sort: {
            field: "FirstName", //access, role
            dir: "ASC",
        },
        advanced: {
            access: 2,
            team: 0,
            role: 0,
        },
    };
    public advancedFilter = false;
    public displayedColumns: string[] = [
        "checkbox",
        "user",
        "access",
        "role",
        "teams",
        "config",
    ];
    public userRoles: any[] = [];
    public ServiceID = SERVICE_ID;
    public services: any[] = [];
    public userRolesFilterOptions: FormOption[];
    public paginationState: PaginationState;
    public totalRecords: number;
    customerDetailUrl: string;

    constructor(
        private matDialog: MatDialog,
        private userPermissionApiService: UserPermissionApiService,
        private activatedRoute: ActivatedRoute,
        private notificationService: NotificationService,
        private loaderService: LoaderService
    ) {
        this.filterConfig.pageData.page = 1;
        this.paginationState = PaginatorHelper.getDefaultState();

        this.companyId = parseInt(
            this.activatedRoute.snapshot.paramMap.get("CustomerID") || "0",
            10
        );

        this.customerDetailUrl = `${NavigationHelper.getBaseUrl()}IBP_Management/CustomerDetail_MS?CompanyId=${
            this.companyId
        }&StartTableIndex=5`;

        this.searchControl.valueChanges
            .pipe(debounceTime(500), distinctUntilChanged())
            .subscribe((value) => {
                this.filterConfig.pageData.page = 1;
                this.filterConfig.searchKeyword = value;
                this.loadData();
            });

        this.loadTeams();
        this.loadRoles();
    }

    public ngAfterViewInit(): void {
        this.sort.sortChange.subscribe(() => {
            if (this.sort.active === "user") {
                this.filterConfig.sort.field = `FirstName ${this.sort.direction.toUpperCase()}`;
            } else if (this.sort.active === "access") {
                const reversedDirection =
                    this.sort.direction === "asc" ? "desc" : "asc";
                this.filterConfig.sort.field = `HasAccess  ${reversedDirection.toUpperCase()}`;
            } else if (this.sort.active === "role") {
                this.filterConfig.sort.field = `ServiceRoleName  ${this.sort.direction.toUpperCase()}`;
            } else {
                this.filterConfig.sort.field = this.sort.active || "name";
            }
            this.loadData();
        });

        this.onPageChange();
    }

    public get countOfSelected(): number {
        return this.userList.filter((e) => e.selected === true).length;
    }

    public get selectedAllStatus(): number {
        if (this.countOfSelected === this.userList.length) {
            return 2;
        }
        return this.countOfSelected === 0 ? 0 : 1;
    }

    public searchWithFilter(): void {
        this.notificationService.showErrorMsg(
            "Search with advanced filter is not available at the moment"
        );
    }

    public resetFilter(): void {
        this.filterConfig.advanced = {
            access: 2,
            role: 0,
            team: 0,
        };
    }

    public onPageChange(): void {
        this.filterConfig.pageData.page =
            this.paginationState.skip /
                (this.paginationState.limit - this.paginationState.skip) +
            1;
        this.filterConfig.pageData.limit =
            this.paginationState.limit - this.paginationState.skip;

        this.loadData();
    }

    public toggleSelect(id: any): void {
        const indexToToggle = this.userList.findIndex(
            (e) => e.SystemUserID === id
        );

        if (indexToToggle !== -1) {
            this.userList[indexToToggle].selected =
                !this.userList[indexToToggle].selected;
        }
    }

    public toggleSelectAll(state: number): void {
        if (state === 0) {
            this.userList.forEach((e) => (e.selected = false));
        }
        if (state === 2) {
            this.userList.forEach((e) => (e.selected = true));
        }
    }

    public openChangeMultiRolesDialog(): void {
        if (this.selectedUsers.length === 0) {
            this.notificationService.showErrorMsg(
                "Select users to assign role!"
            );
            return;
        }
        const dialogRef = this.matDialog.open(ChangeRoleDialogComponent, {
            data: {
                selectedUsers: this.selectedUsers,
                roles: this.userRoles,
            },
        });

        dialogRef.afterClosed().subscribe((data) => this.changeRole(data));
    }

    public openSoloChangeRoleDialog(user: UserDetails): void {
        const dialogRef = this.matDialog.open(ChangeRoleDialogComponent, {
            data: { selectedUsers: [user], roles: this.userRoles },
        });
        dialogRef.afterClosed().subscribe((data) => this.changeRole(data));
    }

    public openMultiAssignTeamsDialogComponent(): void {
        if (this.selectedUsers.length === 0) {
            this.notificationService.showErrorMsg(
                "Select users to assign teams!"
            );
            return;
        }
        const dialogRef = this.matDialog.open(AssignTeamsDialogComponent, {
            data: {
                selectedUsers: this.selectedUsers,
                teams: this.teamsList,
            },
        });
        dialogRef.afterClosed().subscribe((data) => this.assignTeams(data));
    }

    public openSoloAssignTeamsDialog(user: UserDetails): void {
        const dialogRef = this.matDialog.open(AssignTeamsDialogComponent, {
            data: {
                selectedUsers: [user],
                teams: this.teamsList,
            },
        });
        dialogRef.afterClosed().subscribe((data) => this.assignTeams(data));
    }

    public openSoloToggleAccessToServiceDialog(user: UserDetails): void {
        const dialogRef = this.matDialog.open(
            ChangeServiceAccessDialogComponent,
            {
                data: {
                    selectedUsers: [user],
                    makeActive: !user.HasAccess,
                    roles: this.userRoles,
                },
            }
        );
        dialogRef.afterClosed().subscribe((data: any) => {
            if (data.selectedRole !== null) {
                this.activateAndAssignRole(data.users[0], data.selectedRole);
            } else {
                this.changeActiveStatus(data.HasAccess, data.users);
            }
        });
    }

    private loadData(): void {
        this.loaderService.setLoading(true);
        this.userPermissionApiService
            .getUserPermissions(
                this.companyId,
                this.filterConfig.pageData.page,
                this.filterConfig.pageData.limit,
                this.filterConfig.sort,
                this.filterConfig.searchKeyword
            )
            .subscribe(
                (data: GetUserPermissionsDto) => {
                    if (data.result.length > 0) {
                        this.userList = data.result;

                        this.totalRecords = data.meta.TotalItems;
                        this.filterConfig.pageData.totalUsers =
                            data.meta.TotalItems;
                        this.filterConfig.pageData.limit =
                            data.meta.PageMaxItem;
                    } else {
                        this.notificationService.showErrorMsg(
                            this.filterConfig?.searchKeyword?.length >= 1
                                ? "This search comes with no results"
                                : "No users have been assigned to this customer yet."
                        );
                    }
                    this.loaderService.setLoading(false);
                },
                () => {
                    this.loaderService.setLoading(false);
                }
            );
    }

    private get selectedUsers(): UserDetails[] {
        return this.userList.filter((e) => e.selected === true);
    }

    private changeRole(data: any): void {
        if (!data) {
            return;
        }
        const companyId = this.companyId;
        const serviceId = this.ServiceID;
        const userIds = data.selectedUsers.map((it: any) => it.SystemUserID);

        const roleID =
            this.userRoles.find(
                (it) => it.label === data.selectedUsers[0].ServiceRoleName
            )?.value || 0;
        if (roleID === 0) {
            this.notificationService.showErrorMsg(
                "Select valid role to assign!"
            );
            return;
        }

        this.loaderService.setLoading(true);
        this.userPermissionApiService
            .assignRoleToUsers(roleID, userIds, companyId, serviceId)
            .subscribe(() => {
                this.notificationService.showSuccessMsg(
                    "Users roles have been successfully saved."
                );

                this.loaderService.setLoading(false);
            });
    }

    private assignTeams(data: any): void {
        if (!data) {
            return;
        }
        this.loaderService.setLoading(true);
        const companyId = this.companyId;
        const serviceId = this.ServiceID;
        const userIds = data.selectedUsers.map((it: any) => it.SystemUserID);

        const teamIds = data.teams.map((t: { teamId: any }) => t.teamId);

        this.userPermissionApiService
            .assignTeamsToUsers(userIds, companyId, serviceId, teamIds)
            .subscribe(() => {
                this.notificationService.showSuccessMsg(
                    "User has been successfully assigned to Teams."
                );
                this.loaderService.setLoading(false);
                this.loadData();
            });
    }

    private changeActiveStatus(value: boolean, users: UserDetails[]): void {
        if (users.length === 0) {
            this.notificationService.showErrorMsg(
                "Select users to activate/deactivate access!"
            );
            return;
        }

        this.loaderService.setLoading(true);
        const action = value ? "activateService" : "deactivateService";
        const userIds = users.map((it) => it.SystemUserID);
        const companyId = this.companyId;
        const serviceId = this.ServiceID;

        this.userPermissionApiService
            .activateDeactivateService(action, userIds, companyId, serviceId)
            .subscribe(() => {
                this.notificationService.showSuccessMsg(
                    value
                        ? "The users now has access to Cashflow CTRL."
                        : "The users has no longer access to the Cashflow CTRL."
                );
                users.forEach((e) => (e.HasAccess = value));
                users.forEach((e) => (e.HasAccess = value));
                this.loaderService.setLoading(false);
            });
    }

    private activateAndAssignRole(user: UserDetails, role: string) {
        this.loaderService.setLoading(true);
        const ProjectIDs = user.Projects
            ? user.Projects.map((project: Project) => project.ProjectID)
            : [];
        const teamIds = user.Teams
            ? user.Teams.map((team: UserTeam) => team.teamId)
            : [];

        this.userPermissionApiService
            .updateUserDetails(
                true,
                parseInt(role, 10),
                ProjectIDs,
                teamIds,
                this.companyId,
                this.ServiceID,
                user.SystemUserID
            )
            .subscribe((data: UserDetails) => {
                this.userList.map((it: any) =>
                    it.userId === user.SystemUserID ? data : it
                );

                this.notificationService.showSuccessMsg(
                    "The user has been successfully assigned to the role."
                );
                this.loaderService.setLoading(false);
            });
    }

    private loadTeams(): void {
        this.userPermissionApiService.getTeamsList(this.companyId).subscribe(
            (data: any) => {
                this.teamsList = data.result;
                this.teamSelect = data.result.map((t: any) => ({
                    label: t.team,
                    value: t.teamId,
                }));
                this.teamSelect.unshift({ label: "All", value: 0 });
            },
            (error: any) => {
                this.notificationService.showErrorMsg(error.error);
            }
        );
    }

    private loadRoles(): void {
        this.userRoles = [];

        this.userPermissionApiService.getRolesList(this.companyId).subscribe(
            (data) => {
                this.userRoles = data.roles?.map((role: any) => ({
                    label: role?.systemRoleName,
                    value: role?.systemRoleId,
                }));

                this.userRolesFilterOptions = [
                    { label: "All", value: 0 },
                    ...this.userRoles,
                ];
            },
            (error: any) => {
                if (error) {
                    this.notificationService.showErrorMsg(error.error);
                }
            }
        );
    }
}
