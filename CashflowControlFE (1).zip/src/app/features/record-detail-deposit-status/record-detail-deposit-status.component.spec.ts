import { ComponentFixture, TestBed } from "@angular/core/testing";
import { DialogService } from "primeng/dynamicdialog";
import { RecordDetailDepositStatusComponent } from "./record-detail-deposit-status.component";
import { RecordDetailNotesHistoryModalService } from "../record-detail-notes-history/services/record-detail-notes-history-modal.service";

describe("RecordDetailDepositStatusComponent", () => {
    let component: RecordDetailDepositStatusComponent;
    let fixture: ComponentFixture<RecordDetailDepositStatusComponent>;
    let notesHistoryService: RecordDetailNotesHistoryModalService;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [RecordDetailDepositStatusComponent],
            providers: [RecordDetailNotesHistoryModalService, DialogService],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(RecordDetailDepositStatusComponent);
        component = fixture.componentInstance;
        notesHistoryService = TestBed.inject(
            RecordDetailNotesHistoryModalService
        );
        spyOn(notesHistoryService, "openNotesHistoryModal").and.callThrough();
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit submitForProcessing event on submit", () => {
        spyOn(component.submitForProcessing, "emit");
        component.onSubmitForProcessing();
        expect(component.submitForProcessing.emit).toHaveBeenCalled();
    });
});
