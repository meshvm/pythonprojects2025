import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Injectable()
export class ApprovalPoConfigurationService {
    constructor(private formBuilder: FormBuilder) {}

    public buildForm(purchaseOrderThreshold: string): FormGroup {
        return this.formBuilder.group({
            purchaseOrderThreshold: [
                purchaseOrderThreshold,
                [
                    Validators.required,
                    Validators.min(0),
                    Validators.max(999999999),
                ],
            ],
        });
    }
}
