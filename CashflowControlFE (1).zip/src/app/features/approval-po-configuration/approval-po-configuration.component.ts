import { Component, Input, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ApprovalsApiService } from "../../core/api-services/approvals/approvals-api.service";
import { LoaderService } from "../../core/services/loader.service";
import { NotificationService } from "../../core/services/notification.service";
import { ApprovalPoConfigurationService } from "./services/approval-po-configuration.service";

@Component({
    selector: "cc-approval-po-configuration",
    templateUrl: "approval-po-configuration.component.html",
    styleUrls: ["approval-po-configuration.component.scss"],
    providers: [ApprovalPoConfigurationService],
})
export class ApprovalPoConfigurationComponent implements OnInit {
    @Input()
    public ProjectID: number;

    public purchaseOrderThreshold: string;
    public form: FormGroup;

    constructor(
        private approvalPoConfigurationService: ApprovalPoConfigurationService,
        private loaderService: LoaderService,
        private notificationService: NotificationService,
        private approvalsApiService: ApprovalsApiService
    ) {}

    public async ngOnInit(): Promise<void> {
        await this.initForm();
    }

    public async onSave(): Promise<void> {
        this.form.markAllAsTouched();

        if (!this.form.valid) {
            return;
        }

        this.loaderService.setLoading(true);

        try {
            await this.updateThreshold();
            await this.initForm();

            this.notificationService.showSuccessMsg(
                "Value successfully updated"
            );
        } catch (error: any) {
            this.notificationService.showErrorMsg(error);
        }

        this.loaderService.setLoading(false);
    }

    private async initForm(): Promise<void> {
        const threshold = await this.getThreshold();
        this.form = this.approvalPoConfigurationService.buildForm(threshold);
    }

    private async updateThreshold(): Promise<void> {
        await this.approvalsApiService.updateProjectApprovalsConfig(
            this.ProjectID,
            {
                purchaseOrderThreshold: parseFloat(
                    this.form.value.purchaseOrderThreshold
                ),
            }
        );
    }

    private async getThreshold(): Promise<string> {
        const config = await this.approvalsApiService.getProjectApprovalsConfig(
            this.ProjectID
        );

        return config.purchaseOrderThreshold?.toString() || "";
    }
}
