import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { NgxDropzoneChangeEvent } from "ngx-dropzone";
import { firstValueFrom } from "rxjs";
import { FileUploadApiService } from "../../core/api-services/file-upload/file-upload-api.service";
import { UploadedFileMeta } from "../../core/api-services/file-upload/models/uploaded-file-meta.model";
import { Base64Helper } from "../../core/helpers/base-64/base-64-helper";
import { RequestInterface } from "../../core/models/request.model";
import { LoaderService } from "../../core/services/loader.service";
import { NotificationService } from "../../core/services/notification.service";
import { PurchaseOrderUploadConfig } from "./models/purchase-order-upload-config.model";

@Component({
    selector: "cc-purchase-order-upload",
    templateUrl: "purchase-order-upload.component.html",
    styleUrls: ["purchase-order-upload.component.scss"],
})
export class PurchaseOrderUploadComponent {
    public requests: RequestInterface[];
    public filesMap: Map<number, File>;
    public filesPathsMap: Map<number, string>;

    constructor(
        private dialogRef: MatDialogRef<PurchaseOrderUploadComponent>,
        @Inject(MAT_DIALOG_DATA) public data: PurchaseOrderUploadConfig,
        private loaderService: LoaderService,
        private fileUploadApiService: FileUploadApiService,
        private notificationService: NotificationService
    ) {
        this.requests = data.requests;

        this.filesMap = new Map<number, File>();
        this.filesPathsMap = new Map<number, string>();
    }

    public async onFileUpload(
        requestId: number,
        event: NgxDropzoneChangeEvent
    ): Promise<void> {
        const uploadMeta = await this.uploadPdf(event.addedFiles[0]);

        if (uploadMeta) {
            this.filesMap.set(requestId, event.addedFiles[0]);
            this.filesPathsMap.set(requestId, uploadMeta.objectKey);
        }
    }

    public removeFile(requestId: number): void {
        this.filesMap.delete(requestId);
        this.filesPathsMap.delete(requestId);
    }

    public onCancel(): void {
        this.data.onCancel();
        this.dialogRef.close();
    }

    public onSubmit(): void {
        const notValidUpload = this.requests.find(
            (request) => !this.filesPathsMap.has(request.requestId)
        );

        if (notValidUpload) {
            this.notificationService.showErrorMsg(
                "Please upload Purchase Orders for every request listed."
            );
            return;
        }

        this.data.onPurchaseOrdersAttached(this.filesPathsMap);
        this.dialogRef.close();
    }

    public async uploadPdf(file: File): Promise<UploadedFileMeta | null> {
        this.loaderService.setLoading(true);
        let uploadMeta = null;

        try {
            uploadMeta = await firstValueFrom(
                this.fileUploadApiService.uploadFile(
                    file.name,
                    await Base64Helper.fileToBase64(file)
                )
            );
        } catch (error: any) {
            this.notificationService.showErrorMsg(error.error);
        }

        this.loaderService.setLoading(false);
        return uploadMeta;
    }
}
