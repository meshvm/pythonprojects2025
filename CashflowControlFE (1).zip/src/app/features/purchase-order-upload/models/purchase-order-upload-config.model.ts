import { RequestInterface } from "../../../core/models/request.model";

export interface PurchaseOrderUploadConfig {
    requests: RequestInterface[];
    onPurchaseOrdersAttached: (map: Map<number, string>) => void;
    onCancel: () => void;
}
