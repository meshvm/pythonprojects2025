export interface NotificationsPopupApi {
    open: () => void;
}
