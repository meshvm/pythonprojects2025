import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { AssignTeamsDialogComponent } from "./assign-teams-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [AssignTeamsDialogComponent],
    exports: [AssignTeamsDialogComponent],
})
export class AssignTeamsDialogModule {}
