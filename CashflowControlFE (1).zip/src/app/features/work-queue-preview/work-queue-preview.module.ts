import { NgModule } from "@angular/core";
import { NgxImageZoomModule } from "ngx-image-zoom";
import { SharedModule } from "primeng/api";
import { GalleriaModule } from "primeng/galleria";
import { OverlayPanelModule } from "primeng/overlaypanel";
import { SharedDirectivesModule } from "../../shared/directives/shared-directives.module";
import { WorkQueuePreviewComponent } from "./work-queue-preview.component";

@NgModule({
    imports: [
        GalleriaModule,
        NgxImageZoomModule,
        OverlayPanelModule,
        SharedModule,
        SharedDirectivesModule,
    ],
    declarations: [WorkQueuePreviewComponent],
    exports: [WorkQueuePreviewComponent],
})
export class WorkQueuePreviewModule {}
