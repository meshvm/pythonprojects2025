import { ComponentFixture, TestBed } from "@angular/core/testing";

import { WorkQueuePreviewComponent } from "./work-queue-preview.component";

describe("WorkQueuePreviewComponent", () => {
    let component: WorkQueuePreviewComponent;
    let fixture: ComponentFixture<WorkQueuePreviewComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [WorkQueuePreviewComponent],
        });
        fixture = TestBed.createComponent(WorkQueuePreviewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
