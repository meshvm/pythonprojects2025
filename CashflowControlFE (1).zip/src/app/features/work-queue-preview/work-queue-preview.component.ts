import {
    Component,
    ElementRef,
    HostListener,
    Input,
    ViewChild,
    ViewEncapsulation,
} from "@angular/core";

@Component({
    selector: "cc-work-queue-preview",
    templateUrl: "./work-queue-preview.component.html",
    styleUrls: ["./work-queue-preview.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class WorkQueuePreviewComponent {
    private static readonly nextArrowControlSelector = ".p-galleria-item-next";
    private static readonly prevArrowControlSelector = ".p-galleria-item-prev";
    private static readonly indicatorControlSelector = ".p-galleria-indicator";

    @ViewChild("galleriaContainer")
    public galleriaContainer: ElementRef<HTMLElement>;

    @Input()
    public images: any[];
    @Input()
    public dependentElementIsFocused: boolean;

    public readonly nextArrowControlSelector: string;
    public readonly prevArrowControlSelector: string;
    public readonly indicatorControlSelector: string;

    @HostListener("window:keydown.arrowleft")
    public onArrowLeft(): void {
        if (!this.containerIsFocused && !this.dependentElementIsFocused) {
            return;
        }

        (
            this.galleriaContainer.nativeElement.querySelector(
                this.prevArrowControlSelector
            ) as HTMLElement
        )?.click();
    }

    @HostListener("window:keydown.arrowright")
    public onArrowRight(): void {
        if (!this.containerIsFocused && !this.dependentElementIsFocused) {
            return;
        }

        (
            this.galleriaContainer.nativeElement.querySelector(
                this.nextArrowControlSelector
            ) as HTMLElement
        )?.click();
    }

    constructor() {
        this.nextArrowControlSelector =
            WorkQueuePreviewComponent.nextArrowControlSelector;
        this.prevArrowControlSelector =
            WorkQueuePreviewComponent.prevArrowControlSelector;
        this.indicatorControlSelector =
            WorkQueuePreviewComponent.indicatorControlSelector;
    }

    private get containerIsFocused(): boolean {
        return this.galleriaContainer.nativeElement === document.activeElement;
    }
}
