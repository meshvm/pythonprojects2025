import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NavigationBarComponent } from "./navigation-bar.component";
import { Router } from "@angular/router";

describe("NavigationBarComponent", () => {
    let component: NavigationBarComponent;
    let fixture: ComponentFixture<NavigationBarComponent>;
    let mockRouter: jasmine.SpyObj<Router>;

    beforeEach(async () => {
        mockRouter = jasmine.createSpyObj("Router", ["navigate"]);

        await TestBed.configureTestingModule({
            declarations: [NavigationBarComponent],
            providers: [{ provide: Router, useValue: mockRouter }],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(NavigationBarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should have navigation items defined", () => {
        expect(component.navigationItems).toEqual(
            NavigationBarComponent.navigationItems
        );
    });

    it("should update active navigation item and navigate on onActiveItemChange", () => {
        const menuItem = { title: "Reports", routerLink: "reports" };
        component.onActiveItemChange(menuItem);
        expect(component.activeNavigationItem).toBe(menuItem);
        expect(mockRouter.navigate).toHaveBeenCalledWith([menuItem.routerLink]);
    });
});
