import { FormOption } from "../../../core/models/form-option.model";
import { UserDetails } from "../../../core/models/user-details.model";

export interface ChangeRoleDialogConfig {
    selectedUsers: UserDetails[];
    roles: FormOption[];
}
