import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ProjectsListComponent } from "./projects-list.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ProjectsListComponent],
    exports: [ProjectsListComponent],
})
export class ProjectsListModule {}
