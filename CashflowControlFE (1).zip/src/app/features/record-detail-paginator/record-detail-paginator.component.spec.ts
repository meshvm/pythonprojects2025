import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PadStringPipe } from "./pipes/pad-string.pipe";
import { RecordDetailPaginatorComponent } from "./record-detail-paginator.component";

describe("RecordDetailPaginatorComponent", () => {
    let component: RecordDetailPaginatorComponent;
    let fixture: ComponentFixture<RecordDetailPaginatorComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [RecordDetailPaginatorComponent, PadStringPipe],
        }).compileComponents();

        fixture = TestBed.createComponent(RecordDetailPaginatorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit nextItem event when next method is called", () => {
        spyOn(component.nextItem, "emit");
        component.next();
        expect(component.nextItem.emit).toHaveBeenCalled();
    });

    it("should emit previousItem event when previous method is called", () => {
        spyOn(component.previousItem, "emit");
        component.previous();
        expect(component.previousItem.emit).toHaveBeenCalled();
    });
});
