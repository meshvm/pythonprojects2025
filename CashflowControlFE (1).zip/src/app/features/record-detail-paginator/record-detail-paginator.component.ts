import {
    Component,
    Input,
    Output,
    EventEmitter,
    ViewEncapsulation,
} from "@angular/core";

@Component({
    selector: "cc-record-detail-paginator",
    templateUrl: "./record-detail-paginator.component.html",
    styleUrls: ["./record-detail-paginator.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class RecordDetailPaginatorComponent {
    @Input()
    public current: number = 0;
    @Input()
    public total: number = 0;

    @Output()
    public nextItem: EventEmitter<void>;
    @Output()
    public previousItem: EventEmitter<void>;

    constructor() {
        this.nextItem = new EventEmitter<void>();
        this.previousItem = new EventEmitter<void>();
    }

    public next(): void {
        this.nextItem.emit();
    }

    public previous(): void {
        this.previousItem.emit();
    }
}
