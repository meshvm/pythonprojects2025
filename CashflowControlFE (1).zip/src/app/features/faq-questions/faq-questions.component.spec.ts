import { CommonModule } from "@angular/common";
import {
    ComponentFixture,
    fakeAsync,
    TestBed,
    tick,
} from "@angular/core/testing";
import {
    AngularSvgIconModule,
    SvgIconRegistryService,
    SvgLoader,
} from "angular-svg-icon";
import { DialogService } from "primeng/dynamicdialog";
import { UnitTestsHelper } from "../../shared/helpers/unit-tests/unit-tests-helper";
import { FaqQuestionsComponent } from "./faq-questions.component";
import { FaqSupportRequestManagerService } from "../faq-support-request/services/faq-support-request-manager.service";
import { SimpleChange } from "@angular/core";

describe("FaqQuestionsComponent", () => {
    let component: FaqQuestionsComponent;
    let fixture: ComponentFixture<FaqQuestionsComponent>;
    let faqSupportRequestManagerService: FaqSupportRequestManagerService;

    beforeEach(() => {
        const mockSvgLoader = UnitTestsHelper.createMockSvgLoader();

        TestBed.configureTestingModule({
            imports: [AngularSvgIconModule.forRoot(), CommonModule],
            declarations: [FaqQuestionsComponent],
            providers: [
                DialogService,
                FaqSupportRequestManagerService,
                SvgIconRegistryService,
                { provide: SvgLoader, useValue: mockSvgLoader },
            ],
        });
        fixture = TestBed.createComponent(FaqQuestionsComponent);
        component = fixture.componentInstance;
        faqSupportRequestManagerService = TestBed.inject(
            FaqSupportRequestManagerService
        );
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    describe("ngOnChanges", () => {
        it("should call onCollapseAll when searchText is cleared", fakeAsync(() => {
            spyOn(component, "onCollapseAll");

            component.ngOnChanges({
                searchText: new SimpleChange("previousValue", "", true),
            });

            tick();
            expect(component.onCollapseAll).toHaveBeenCalled();
        }));

        it("should call onExpandAll when searchText is provided and questions are not empty", () => {
            spyOn(component, "onExpandAll");

            component.questions = [{ name: "Question1", value: "Answer1" }];
            component.searchText = "search query";

            component.ngOnChanges({
                searchText: new SimpleChange(null, component.searchText, false),
            });

            expect(component.onExpandAll).toHaveBeenCalled();
        });
    });

    it("should set nodesExpanded to true when onExpandAll is called", () => {
        component.onExpandAll();
        expect(component.nodesExpanded).toBeTrue();
    });

    it("should set nodesExpanded to false when onCollapseAll is called", () => {
        component.onCollapseAll();
        expect(component.nodesExpanded).toBeFalse();
    });

    it("should call openSupportRequestModal when onSendMessage is called", () => {
        spyOn(faqSupportRequestManagerService, "openSupportRequestModal");
        component.onSendMessage();
        expect(
            faqSupportRequestManagerService.openSupportRequestModal
        ).toHaveBeenCalled();
    });
});
