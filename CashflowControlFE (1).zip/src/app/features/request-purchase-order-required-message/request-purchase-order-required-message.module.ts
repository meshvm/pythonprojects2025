import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RequestPurchaseOrderRequiredMessageComponent } from "./request-purchase-order-required-message.component";

@NgModule({
    imports: [SharedModule],
    declarations: [RequestPurchaseOrderRequiredMessageComponent],
    exports: [RequestPurchaseOrderRequiredMessageComponent],
})
export class RequestPurchaseOrderRequiredMessageModule {}
