import {
    ChangeDetectorRef,
    Component,
    DestroyRef,
    inject,
    Input,
    OnChanges,
    SimpleChanges,
} from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { MenuItem } from "primeng/api";
// import { workQueueImages } from "../../core/constants/work-queue-constants";
import { TableBatchActionsStateService } from "../../shared/components/table-batch-actions/services/table-batch-actions-state.service";
import { WorkQueueStatus } from "../../shared/models/work-queues/work-queue-status.enum";
import { WorkQueueTableService } from "../work-queue-table/services/work-queue-table.service";
import { forkJoin, Subscription } from "rxjs";
import { WorkQueueService } from "src/app/core/api-services/work-queue/work-queue.service";
import { UserService } from "src/app/core/services/users.service";
import { ImageArray } from "src/app/shared/models/work-queues/work-queue.model";
import { LoaderService } from "src/app/core/services/loader.service";
@Component({
    selector: "cc-work-queue-table-grid-element",
    templateUrl: "./work-queue-table-grid-element.component.html",
    styleUrls: ["./work-queue-table-grid-element.component.scss"],
    providers: [WorkQueueTableService],
})
export class WorkQueueTableGridElementComponent implements OnChanges {
    @Input({ required: true })
    public workQueue: any;

    public readonly workQueueStatuses: typeof WorkQueueStatus;

    public images: any[] = [];
    public rowActions: MenuItem[];
    public itemSelected: boolean;
    public imagesLoaded = false;
    public totalImages: number = 0;
    public loadedImages: number = 0;
    public companyId: number;

    private selectedItems: Set<string>;
    private destroyRef: DestroyRef;
    private subscription: Subscription | null = null;
    public BatchID: string;
    public Transaction: number;
    public ReleaseDate: string;
    public CompanyID: number;
    public data: any;

    constructor(
        private workQueueTableService: WorkQueueTableService,
        private workQueueService: WorkQueueService,
        private cdr: ChangeDetectorRef,
        private tableBatchActionsStateService: TableBatchActionsStateService,
        private userService: UserService,
        private loaderService: LoaderService
    ) {
        this.destroyRef = inject(DestroyRef);

        this.subscribeToSelectedItems();

        this.workQueueStatuses = WorkQueueStatus;
        this.unsubscribe();
        this.userService.currentUserRole.subscribe(() => {
            this.initRowActions();
        });
        this.companyId = userService.currentCompanyIdValue;
    }

    public ngOnChanges(changes: SimpleChanges): void {
        // else if(changes["workQueue"] && !(this.workQueue.id)){
        //     this.BatchID = this.workQueue.BatchID;
        //     this.ReleaseDate = this.workQueue.ReleaseDate;
        //     this.CompanyID = this.workQueue.CompanyID;
        //     console.log(this.workQueue)
        //     this.subscription = this.workQueueService
        //         .getArchiveImages(
        //             this.BatchID,
        //             this.ReleaseDate,
        //             this.CompanyID
        //         )
        //         .subscribe((responses: ImageArray) => {
        //             responses.Images.forEach((response: string) => {
        //                 this.loadImages(response, "");
        //             });
        //         });
        // }
        if (changes["workQueue"] && this.workQueue) {
            this.itemSelected = this.selectedItems.has(this.workQueue.id);
            if (
                this.images.length === 0 &&
                this.workQueue.id &&
                this.workQueue.demKey
            ) {
                this.subscription = forkJoin(
                    this.workQueue.AllPageKeys.map((key: number) =>
                        this.workQueueService.getBatchImages(
                            this.workQueue.demKey,
                            key
                        )
                    )
                ).subscribe((responses: any) => {
                    const allImages: any[] = [];
                    responses.forEach((response: any) => {
                        if (
                            response.result.Images &&
                            response.result.Images.length > 0
                        ) {
                            allImages.push(...response.result.Images);
                        }
                    });

                    this.totalImages = allImages.length;
                    allImages.forEach((data: any) => {
                        if (data.Depth === "BITONAL") {
                            this.loadImages(data.ImageData, data.Side);
                        }
                    });
                });
            } else if (changes["workQueue"] && !this.workQueue.id) {
                this.BatchID = this.workQueue.BatchID;
                this.ReleaseDate = this.workQueue.ReleaseDate;
                this.CompanyID = this.workQueue.CompanyID;
                this.Transaction = this.workQueue.Transaction;
                this.subscription = this.workQueueService
                    .getArchiveImages(
                        this.BatchID,
                        this.ReleaseDate,
                        this.CompanyID,
                        this.Transaction
                    )
                    .subscribe((responses: ImageArray) => {
                        responses.Images.forEach((response: string) => {
                            this.loadImages(response, "");
                        });
                    });
            } else {
                this.imagesLoaded = true;
            }
        }
    }

    public onMenuOpen(id: string): void {
        this.workQueueTableService.updateSelectedItemId(id);
    }

    public onMenuClose(): void {
        this.workQueueTableService.updateSelectedItemId(null);
    }

    public onSelectionChanged(value: boolean): void {
        if (value) {
            this.tableBatchActionsStateService.selectItem(
                this.workQueue.demKey
            );
        } else {
            this.tableBatchActionsStateService.unSelectItem(
                this.workQueue.demKey
            );
        }
    }

    private subscribeToSelectedItems(): void {
        this.tableBatchActionsStateService.selectedItems$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((val) => {
                this.selectedItems = val;
                this.itemSelected =
                    this.workQueue?.demKey &&
                    this.selectedItems.has(this.workQueue.demKey);
            });
    }

    private initRowActions(): void {
        this.rowActions = this.workQueueTableService.getRowActions();
    }

    private unsubscribe(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
            this.subscription = null;
        }
    }

    private loadImages(base64ImageData: string, alt: string) {
        const binaryString = window.atob(base64ImageData);
        const binaryLen = binaryString.length;
        const bytes = new Uint8Array(binaryLen);
        for (let i = 0; i < binaryLen; i++) {
            const ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
        }
        const blob = new Blob([bytes], { type: "image/png" });
        const imageUrl = window.URL.createObjectURL(blob);
        this.images.push({
            itemImageSrc: imageUrl,
            alt: alt,
        });
        this.loadedImages++;
        this.cdr.detectChanges();
        if (this.loadedImages === this.totalImages) {
            this.imagesLoaded = true;
        }
    }
}
