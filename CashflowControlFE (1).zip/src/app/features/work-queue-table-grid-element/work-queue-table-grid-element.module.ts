import { NgModule } from "@angular/core";
import { SvgIconComponent } from "angular-svg-icon";
import { CheckboxModule } from "primeng/checkbox";
import { MenuModule } from "primeng/menu";
import { SharedModule } from "../../shared/shared.module";
import { WorkQueuePreviewModule } from "../work-queue-preview/work-queue-preview.module";
import { WorkQueueTableGridElementComponent } from "./work-queue-table-grid-element.component";

@NgModule({
    imports: [
        SharedModule,
        WorkQueuePreviewModule,
        CheckboxModule,
        MenuModule,
        SvgIconComponent,
    ],
    declarations: [WorkQueueTableGridElementComponent],
    exports: [WorkQueueTableGridElementComponent],
})
export class WorkQueueTableGridElementModule {}
