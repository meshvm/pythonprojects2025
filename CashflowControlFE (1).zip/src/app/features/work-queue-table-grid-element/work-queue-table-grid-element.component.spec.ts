import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MessageService } from "primeng/api";
import { DialogService } from "primeng/dynamicdialog";
import { TableBatchActionsStateService } from "../../shared/components/table-batch-actions/services/table-batch-actions-state.service";
import { WorkQueueTableService } from "../work-queue-table/services/work-queue-table.service";

import { WorkQueueTableGridElementComponent } from "./work-queue-table-grid-element.component";

describe("WorkQueueTableGridElementComponent", () => {
    let component: WorkQueueTableGridElementComponent;
    let fixture: ComponentFixture<WorkQueueTableGridElementComponent>;
    let workQueueTableServiceMock: jasmine.SpyObj<WorkQueueTableService>;

    beforeEach(() => {
        workQueueTableServiceMock = jasmine.createSpyObj(
            "WorkQueueTableService",
            ["updateSelectedItemId"]
        );
        TestBed.configureTestingModule({
            declarations: [WorkQueueTableGridElementComponent],
            providers: [
                DialogService,
                MessageService,
                TableBatchActionsStateService,
                {
                    provide: WorkQueueTableService,
                    useValue: workQueueTableServiceMock,
                },
            ],
        });
        fixture = TestBed.createComponent(WorkQueueTableGridElementComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
