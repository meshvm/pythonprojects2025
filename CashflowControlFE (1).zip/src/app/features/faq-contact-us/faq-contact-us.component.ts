import { Component, ViewEncapsulation } from "@angular/core";
import { DialogService } from "primeng/dynamicdialog";
import { FaqSupportRequestManagerService } from "../faq-support-request/services/faq-support-request-manager.service";
import { MatDialog } from "@angular/material/dialog";
import { SendMessageDialogComponent } from "../send-message-dialog/send-message-dialog.component";

@Component({
    selector: "cc-faq-contact-us",
    templateUrl: "./faq-contact-us.component.html",
    styleUrls: ["./faq-contact-us.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [DialogService],
})
export class FaqContactUsComponent {
    constructor(
        private faqSupportRequestManagerService: FaqSupportRequestManagerService,
        private dialog: MatDialog
    ) {}

    public onSendMessage(): void {
        this.dialog.open(SendMessageDialogComponent, {
            data: {},
        });
    }

    public onRequestCall(): void {
        this.dialog.open(SendMessageDialogComponent, {
            data: {
                requestCall: true,
            },
        });
    }
}
