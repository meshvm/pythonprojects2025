import { ComponentFixture, TestBed } from "@angular/core/testing";
import { DialogService } from "primeng/dynamicdialog";
import { FaqContactUsComponent } from "./faq-contact-us.component";
import { FaqSupportRequestManagerService } from "../faq-support-request/services/faq-support-request-manager.service";

describe("FaqContactUsComponent", () => {
    let component: FaqContactUsComponent;
    let fixture: ComponentFixture<FaqContactUsComponent>;
    let faqSupportRequestManagerService: FaqSupportRequestManagerService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [FaqContactUsComponent],
            providers: [DialogService, FaqSupportRequestManagerService],
        });
        fixture = TestBed.createComponent(FaqContactUsComponent);
        component = fixture.componentInstance;
        faqSupportRequestManagerService = TestBed.inject(
            FaqSupportRequestManagerService
        );
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call openSupportRequestModal when onSendMessage is called", () => {
        spyOn(faqSupportRequestManagerService, "openSupportRequestModal");
        component.onSendMessage();
        expect(
            faqSupportRequestManagerService.openSupportRequestModal
        ).toHaveBeenCalled();
    });

    it("should call openRequestCallModal when onRequestCall is called", () => {
        spyOn(faqSupportRequestManagerService, "openRequestCallModal");
        component.onRequestCall();
        expect(
            faqSupportRequestManagerService.openRequestCallModal
        ).toHaveBeenCalled();
    });
});
