import { Injectable } from "@angular/core";
import { DynamicDialogRef } from "primeng/dynamicdialog";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { WorkQueueActionModalConfig } from "../models/work-queue-action-modal-config.model";
import { WorkQueueReturnCheckActionModalConfig } from "../models/work-queue-return-check-action-modal-config.model";
import { WorkQueueReturnCheckaddressModalConfig } from "../models/work-queue-return-check-address-modal-config.model";
import { WorkQueueReturnCheckValidateaddressModalConfig } from "../models/work-queue-return-check-validate-address-modal-config.model";
import { WorkQueueExportRecordsModalConfig } from "../models/work-queue-export-records-modal-config.model";
import { WorkQueueActionModalComponent } from "../work-queue-action-modal.component";
import { ReturnCheckModalComponent } from "../../work-queue/return-check-modal/return-check-modal.component";
import { ReturnCheckaddressModalComponent } from "../../work-queue/return-check-address-modal/return-check-address-modal.component";
import { ReturnCheckValidateaddressModalComponent } from "../../work-queue/return-check-validate-address-modal/return-check-validate-address-modal.component";
import { ReturnCheckaddressItem } from "../../work-queue/return-check-modal/models/return-check-address-item.model";
import { ExportRecordsModalComponent } from "../../work-queue/export-records-modal/export-records-modal.component";

@Injectable({
    providedIn: "root",
})
export class WorkQueueActionModalManagerService {
    constructor(private modalService: ModalService) {}

    public openSupportRequestModal(config: WorkQueueActionModalConfig): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<WorkQueueActionModalComponent>(
                WorkQueueActionModalComponent,
                undefined,
                {
                    width: "500px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                    onCancelWithCallback: (count: number) => {
                        if (config.closeCallback) {
                            config.closeCallback(count);
                        }
                        ref.close();
                    },
                    onSubmit: (count: number, fileName: string) =>
                        config.submitCallback(count, fileName),
                    submitButtonText: config.submitButtonText,
                    checksSelectedCount: config.checksSelectedCount,
                    title: config.title,
                    text: config.text,
                    buttonType: config.buttonType ?? "submit",
                } as Partial<WorkQueueActionModalComponent>
            );
    }

    public openReturnCheckModal(
        config: WorkQueueReturnCheckActionModalConfig
    ): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<ReturnCheckModalComponent>(
                ReturnCheckModalComponent,
                undefined,
                {
                    width: "710px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                    onSubmit: (address: ReturnCheckaddressItem) =>
                        config.submitCallback(address),
                    onDelete: (
                        address: ReturnCheckaddressItem,
                        count: number
                    ) => config.deleteCallback(address, count),
                    onEnter: (count: number) =>
                        config.enterNewaddressCallback(count),
                    onEdit: (address: ReturnCheckaddressItem, count) =>
                        config.editaddressCallback(address, count),
                    submitButtonText: config.submitButtonText,
                    checksSelectedCount: config.checksSelectedCount,
                    title: config.title,
                    text: config.text,
                } as Partial<ReturnCheckModalComponent>
            );
    }

    public openReturnCheckaddressModal(
        config: WorkQueueReturnCheckaddressModalConfig
    ): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<ReturnCheckaddressModalComponent>(
                ReturnCheckaddressModalComponent,
                undefined,
                {
                    width: "710px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                    onCancelWithCallback: (count: number) => {
                        if (config.closeCallback) {
                            config.closeCallback(count);
                        }
                        ref.close();
                    },
                    isValidated: config.isValidated,
                    isEditing: config.isEditing,
                    onSave: () => config.saveCallback(),
                    onSubmit: (
                        count: number,
                        address: ReturnCheckaddressItem
                    ) => config.submitCallback(count, address),
                    checksSelectedCount: config.checksSelectedCount,
                    address: config.address,
                } as Partial<ReturnCheckaddressModalComponent>
            );
    }

    public openValidateaddressModal(
        config: WorkQueueReturnCheckValidateaddressModalConfig
    ): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<ReturnCheckValidateaddressModalComponent>(
                ReturnCheckValidateaddressModalComponent,
                undefined,
                {
                    width: "500px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                    onCancelWithCallback: (
                        count: number,
                        address: ReturnCheckaddressItem
                    ) => {
                        if (config.closeCallback) {
                            config.closeCallback(count, address);
                        }
                        ref.close();
                    },
                    onSubmit: (count, address) =>
                        config.submitCallback(count, address),
                    checksSelectedCount: config.checksSelectedCount,
                    address: config.address,
                } as Partial<ReturnCheckValidateaddressModalComponent>
            );
    }

    public openExportModal(config: WorkQueueExportRecordsModalConfig): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<ExportRecordsModalComponent>(
                ExportRecordsModalComponent,
                undefined,
                {
                    width: "500px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                    onSubmit: (count: number, fileName: string) =>
                        config.submitCallback(count, fileName),
                    checksSelectedCount: config.checksSelectedCount,
                } as Partial<ExportRecordsModalComponent>
            );
    }
}
