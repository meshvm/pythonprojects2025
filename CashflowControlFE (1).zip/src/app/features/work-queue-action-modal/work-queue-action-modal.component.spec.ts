import { ComponentFixture, TestBed } from "@angular/core/testing";

import { WorkQueueActionModalComponent } from "./work-queue-action-modal.component";
import { WorkQueueActionModalButtonType } from "./models/work-queue-action-modal-button-type.enum";

describe("DepositAndPostComponent", () => {
    let component: WorkQueueActionModalComponent;
    let fixture: ComponentFixture<WorkQueueActionModalComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [WorkQueueActionModalComponent],
        });
        fixture = TestBed.createComponent(WorkQueueActionModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should call onCancelWithCallback upon cancel", () => {
        component.onCancelWithCallback = (count: number) => {
            return count;
        };
        spyOn(component, "onCancelWithCallback");

        component.cancel();

        expect(component.onCancelWithCallback).toHaveBeenCalled();
    });

    it("should call onDelete upon submit based on button type", () => {
        component.onDelete = (address: any) => {
            return address;
        };
        component.onCancel = () => {};
        spyOn(component, "onDelete");
        spyOn(component, "onCancel");

        component.buttonType = WorkQueueActionModalButtonType.Delete;
        component.submit();

        expect(component.onDelete).toHaveBeenCalled();
        expect(component.onCancel).toHaveBeenCalled();
    });

    it("should call onSubmit upon submit based on button type", () => {
        component.onSubmit = (address: any) => {
            return address;
        };
        component.onCancel = () => {};
        spyOn(component, "onSubmit");
        spyOn(component, "onCancel");

        component.buttonType = WorkQueueActionModalButtonType.Submit;
        component.submit();

        expect(component.onSubmit).toHaveBeenCalled();
        expect(component.onCancel).toHaveBeenCalled();
    });
});
