export interface WorkQueueExportRecordsModalConfig {
    checksSelectedCount: number;
    submitCallback: (count: number, fileName: string) => void;
    closeCallback?: () => void;
}
