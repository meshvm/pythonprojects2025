import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { WorkQueueActionModalComponent } from "./work-queue-action-modal.component";

@NgModule({
    imports: [SharedModule],
    declarations: [WorkQueueActionModalComponent],
    exports: [WorkQueueActionModalComponent],
})
export class WorkQueueActionModalModule {}
