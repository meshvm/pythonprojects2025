import { Component } from "@angular/core";
import { ReturnCheckaddress } from "../work-queue/return-check-modal/models/return-check-address.model";
import { WorkQueueActionModalButtonType } from "./models/work-queue-action-modal-button-type.enum";

@Component({
    selector: "cc-work-queue-action-modal",
    templateUrl: "./work-queue-action-modal.component.html",
    styleUrls: ["./work-queue-action-modal.component.scss"],
})
export class WorkQueueActionModalComponent {
    public onCancel: () => void;
    public onCancelWithCallback: (count: number) => void;
    public onSubmit: (count: number, fileName: string) => void;
    public onDelete: (address: ReturnCheckaddress) => void;
    public checksSelectedCount: number;
    public fileName: string;
    public title: string;
    public text: string;
    public submitButtonText: string;
    public buttonType: WorkQueueActionModalButtonType;
    public buttonTypeEnum: typeof WorkQueueActionModalButtonType;
    private address: ReturnCheckaddress;

    constructor() {
        this.buttonTypeEnum = WorkQueueActionModalButtonType;
    }

    public submit(): void {
        if (this.buttonType === WorkQueueActionModalButtonType.Delete) {
            this.onDelete(this.address);
        } else {
            this.onSubmit(this.checksSelectedCount, this.fileName);
        }
        this.onCancel();
    }

    public cancel(): void {
        this.onCancelWithCallback(this.checksSelectedCount);
    }
}
