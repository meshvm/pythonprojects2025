import { CurrencyPipe } from "@angular/common";
import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { BillingTableComponent } from "./billing-table.component";

@NgModule({
    imports: [SharedModule],
    declarations: [BillingTableComponent],
    providers: [CurrencyPipe],
    exports: [BillingTableComponent],
})
export class BillingTableModule {}
