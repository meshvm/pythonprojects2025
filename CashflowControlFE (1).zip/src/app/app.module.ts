import { NgModule } from "@angular/core";
import { HTTP_INTERCEPTORS, HttpClientModule } from "@angular/common/http";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { SvgIconComponent } from "angular-svg-icon";
// import { SharedModule as SharedModuleNG } from "primeng/api";
import { SharedModule } from "./shared/shared.module";
import { MenuModule } from "primeng/menu";
import { TableModule } from "primeng/table";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { LayoutModule } from "./core/layout/layout.module";
import { QuickviewModule } from "./features/work-queue/quickview/quickview.module";
import { PaginatorModule } from "./shared/components/paginator/paginator.module";
import { PaginatorAdminModule } from "./shared/components/paginator-admin/paginator.module";
import { TableBatchActionsHeaderSelectorModule } from "./shared/components/table-batch-actions-header-selector/table-batch-actions-header-selector.module";
import { TableBatchActionsRowSelectorModule } from "./shared/components/table-batch-actions-row-selector/table-batch-actions-row-selector.module";
import { TableBatchActionsModule } from "./shared/components/table-batch-actions/table-batch-actions.module";
import { TableColumnManagerModule } from "./shared/components/table-column-manager/table-column-manager.module";

import { AdminLayoutComponent } from "./pages/admin/layout/admin.component";
import { AuthLayoutComponent } from "./pages/auth/auth-layout/auth-layout.component";
import { UserLayoutComponent } from "./pages/user/layout/layout.component";

import { AuthInterceptor } from "./core/interceptors/auth-interceptor.service";
import { ErrorInterceptor } from "./core/interceptors/error.interceptor";

import { HeaderAdminModule } from "src/app/features/admin-header/header.module";

import { provideEnvironmentNgxMask } from "ngx-mask";
import { NgxPaginationModule } from "ngx-pagination";
import { MatDialogModule } from "@angular/material/dialog";
import { CustomLoadingIndicatorModule } from "./features/custom-loading-indicator/custom-loading-indicator.module";
import { OIDCModule } from "./core/oidc/oidc.module";
import { AdminModule } from "./modules/admin/admin.module";
import { FooterModule } from "./features/footer/footer.module";

@NgModule({
    declarations: [
        AppComponent,
        AdminLayoutComponent,
        AuthLayoutComponent,
        UserLayoutComponent,
    ],
    imports: [
        BrowserAnimationsModule,
        BrowserModule,
        AppRoutingModule,
        LayoutModule,
        MenuModule,
        PaginatorModule,
        PaginatorAdminModule,
        QuickviewModule,
        SharedModule,
        SvgIconComponent,
        TableBatchActionsHeaderSelectorModule,
        TableBatchActionsModule,
        TableBatchActionsRowSelectorModule,
        TableColumnManagerModule,
        TableModule,
        HttpClientModule,
        HeaderAdminModule,
        NgxPaginationModule,
        MatDialogModule,
        CustomLoadingIndicatorModule,
        OIDCModule.forRoot(),
        FooterModule,
        AdminModule,
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        provideEnvironmentNgxMask(),
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}
