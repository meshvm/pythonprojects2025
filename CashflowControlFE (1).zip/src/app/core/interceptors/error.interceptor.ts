import {
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { LoaderService } from "../services/loader.service";
import { NotificationService } from "../services/notification.service";

@Injectable({ providedIn: "root" })
export class ErrorInterceptor implements HttpInterceptor {
    constructor(
        private loaderService: LoaderService,
        private notificationService: NotificationService
    ) {}

    public intercept(
        req: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            catchError((err: any) => {
                this.loaderService.setLoading(false);
                let errorMsg;

                if (req.url.includes("/OIDC/userinfo")) {
                    errorMsg =
                        "Sorry for inconvenience. Your access token has expired. Please sign out and sign in again to get a new access token.";
                } else if (err.error.message !== undefined) {
                    errorMsg = err.error.message;
                } else if (err.error.ErrorMessage !== undefined) {
                    errorMsg = err.error.ErrorMessage;
                } else if (err.error?.error?.message !== undefined) {
                    errorMsg = err.error.error.message;
                } else {
                    switch (err.status) {
                        case 0:
                            errorMsg =
                                "Sorry for inconvenience. An error occurred during communication with the server.";
                            // window.location.href = `${window.location.origin}/IBP/Login?returnUrl=${window.location.pathname}`;
                            break;
                        case 401:
                            errorMsg =
                                "Sorry for inconvenience, but you are not authorized for this.";
                            // window.location.href = `${window.location.origin}/IBP/Login?returnUrl=${window.location.pathname}`;
                            break;
                        case 403:
                            errorMsg =
                                "Sorry for inconvenience, but you do not have permissions to view this.";
                            break;
                        case 404:
                            errorMsg =
                                "Sorry for inconvenience, but the server cannot find the requested resource.";
                            break;
                        case 405:
                            errorMsg =
                                "Sorry for inconvenience, but the request method is known by the server but is not supported by the target resource.";
                            break;
                        case 400:
                            errorMsg =
                                "Could you please check request parameters once again?";
                            break;
                        case 500:
                            errorMsg =
                                "Sorry for inconvenience, but it seems something unexpected has occurred. Please contact your administrator.";
                            break;
                        case 501:
                            errorMsg =
                                "The request method is not supported by the server and cannot be handled.";
                            break;
                        case 502:
                            errorMsg =
                                "Bad gateway error occurred while calling the server. Please contact your administrator.";
                            break;
                        case 503:
                            errorMsg =
                                "The server is not ready to handle the request. Please try again.";
                            break;
                        case 504:
                            errorMsg = "Request timed out.";
                            break;
                        default:
                            errorMsg =
                                "Sorry for inconvenience, but an error occurred during communication with the server. Please contact the administrator.";
                    }
                }

                this.notificationService.showErrorMsg(errorMsg);
                return throwError(errorMsg);
            })
        );
    }
}
