import { UserDetails } from "../../models/user-details.model";

export interface UserDetailsResponse {
    result: UserDetails[];
}
