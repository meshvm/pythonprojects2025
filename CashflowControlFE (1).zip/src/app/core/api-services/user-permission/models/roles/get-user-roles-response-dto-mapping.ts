import { GetUserRolesResponseDto } from "./get-user-roles-response-dto.model";
import { GetUserRolesResponse } from "./get-user-roles-response.model";

export class GetUserRolesResponseDtoMapping {
    public static mapToModel(
        dto: GetUserRolesResponseDto
    ): GetUserRolesResponse {
        return {
            roles: dto.Roles.map((dtoItem) => ({
                systemRoleId: dtoItem.SystemRoleID,
                systemRoleName: dtoItem.SystemRoleName,
            })),
        };
    }
}
