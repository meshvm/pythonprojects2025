import { UserRole } from "./user-role.model";

export interface GetUserRolesResponse {
    roles: UserRole[];
}
