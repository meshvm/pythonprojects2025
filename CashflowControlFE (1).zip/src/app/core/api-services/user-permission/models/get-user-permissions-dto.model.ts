import { UserDetails } from "../../../models/user-details.model";

export interface GetUserPermissionsDto {
    meta: {
        page: number;
        PageMaxItem: number;
        TotalItems: number;
        totalPages: number;
    };
    result: UserDetails[];
}
