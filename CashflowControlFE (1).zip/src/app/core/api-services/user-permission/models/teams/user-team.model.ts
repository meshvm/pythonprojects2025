export interface UserTeam {
    teamId: number;
    team?: string;
    TeamName?: string;
}
