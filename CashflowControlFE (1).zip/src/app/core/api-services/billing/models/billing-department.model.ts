export interface BillingDepartment {
    billingDepartmentId?: string;
    DepartmentName: string;
    departmentBillingCode: string;
    companyId: number;
    ProjectID: number;
    departmentId?: number;
}
