import { BillingItemCost } from "./billing-item-cost.model";

export interface BillingItem {
    id: number;
    name: string;
    companyId: number;
    isDefault: boolean;
    ProjectID: number;
    isRequired: boolean;
    showOption: boolean;
    description: string;
    lowVolumePCode: string;
    billingItemCost: Partial<BillingItemCost>[];
    highVolumePCode: string;
    lowVolumeEDPCode: string;
    highVolumeEDPCode: string;
    serviceRequestTypeId: number;
    lowVolumeOveragePCode: string;
    highVolumeOveragePCode: string;
    servicePackagingTypeId: number;
    lowVolumeOverageEDPCode: string;
    highVolumeOverageEDPCode: string;
}
