import { BillingItem } from "./billing-item.model";

export interface BillingItemsDto {
    billingItems: BillingItem[];
    totalCount: number;
}
