import { BillingDepartment } from "./billing-department.model";

export interface GetBillingDepartmentsResponseDto {
    billingDepartments: BillingDepartment[];
}
