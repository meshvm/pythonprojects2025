export interface BillingAmountDto {
    requestBillingTotal: number;
}
