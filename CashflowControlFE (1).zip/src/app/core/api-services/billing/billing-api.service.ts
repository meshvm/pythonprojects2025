import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "../../../../environments/environment";
import { BillingDepartment } from "./models/billing-department.model";
import { BillingItem } from "./models/billing-item.model";
import { BillingItemsDto } from "./models/billing-items-dto.model";
import { GetBillingAmountRequestDto } from "./models/get-billing-amount-request-dto.model";
import { GetBillingAmountResponseDto } from "./models/get-billing-amount-response-dto.model";
import { GetBillingDepartmentsResponseDto } from "./models/get-billing-departments-response-dto.model";

@Injectable({
    providedIn: "root",
})
export class BillingApiService {
    private readonly baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public getBillingItems(ProjectID: number): Observable<BillingItemsDto> {
        return this.http.get<BillingItemsDto>(`${this.baseUrl}/billing/items`, {
            params: { ProjectID },
        });
    }

    public createBillingItem(data: BillingItem): Observable<BillingItem> {
        return this.http.post<BillingItem>(
            `${this.baseUrl}/billing/items`,
            data
        );
    }

    public updateBillingItem(
        itemId: number,
        data: Partial<BillingItem>
    ): Observable<any> {
        return this.http.put(`${this.baseUrl}/billing/items/` + itemId, data);
    }

    public deleteBillingItem(id: number): Observable<void> {
        return this.http.delete<void>(`${this.baseUrl}/billing/items/` + id);
    }

    public getBillingDepartments(
        ProjectID: number
    ): Observable<GetBillingDepartmentsResponseDto> {
        return this.http.get<GetBillingDepartmentsResponseDto>(
            `${this.baseUrl}/billing/departments`,
            {
                params: { ProjectID: ProjectID },
            }
        );
    }

    public createBillingDepartment(
        data: BillingDepartment
    ): Observable<BillingDepartment> {
        return this.http.post<BillingDepartment>(
            `${this.baseUrl}/billing/departments`,
            data
        );
    }

    public updateBillingDepartment(
        itemId: number,
        model: Partial<BillingDepartment>
    ): Observable<BillingDepartment> {
        return this.http.put<BillingDepartment>(
            `${this.baseUrl}/billing/departments/${itemId}`,
            model
        );
    }

    public deleteBillingDepartment(
        departmentId: number,
        ProjectID: number,
        companyId: number
    ): Observable<void> {
        return this.http.delete<void>(
            `${this.baseUrl}/billing/departments/${departmentId}`,
            {
                params: {
                    billingDepartmentId: departmentId,
                    ProjectID: ProjectID,
                    companyId: companyId,
                },
            }
        );
    }

    public getBillingAmount(
        payload: GetBillingAmountRequestDto
    ): Observable<GetBillingAmountResponseDto> {
        return this.http.put<GetBillingAmountResponseDto>(
            `${this.baseUrl}/billing/items:cost`,
            payload
        );
    }
}
