import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, of } from "rxjs";
import { map, tap } from "rxjs/operators";
import { environment } from "../../../../environments/environment";
import { AuthService } from "../../oidc/auth-oidc.service";
import { addressItemDtoMapping } from "./models/address-items/address-item-dto-mapping";
import { addressItem } from "./models/address-items/address-item.model";
import { GetaddressListResponseDto } from "./models/address-items/get-address-list-response-dto.model";
import { GetUserResponseDtoMapping } from "./models/company-id/get-user-response-dto-mapping";
import { GetUserResponseDto } from "./models/company-id/get-user-response-dto.model";
import { GetUserResponse } from "./models/company-id/get-user-response.model";
import { GetMenuItemsResponseDtoMapping } from "./models/menu-items/get-menu-items-response-dto-mapping";
import { GetMenuItemsResponseDto } from "./models/menu-items/get-menu-items-response-dto.model";
import { GetMenuItemsResponse } from "./models/menu-items/get-menu-items-response.model";
import { GetPackagingTypeItemsResponseDtoMapping } from "./models/packaging-types/get-packaging-type-items-response-dto-mapping";
import { GetPackagingTypeItemsResponseDto } from "./models/packaging-types/get-packaging-type-items-response-dto.model";
import { GetPackagingTypeItemsResponse } from "./models/packaging-types/get-packaging-type-items-response.model";
import { GetServiceListResponseDtoMapping } from "./models/service-list/get-service-list-response-dto-mapping";
import { GetServiceListResponseDto } from "./models/service-list/get-service-list-response-dto.model";
import { GetServiceListResponse } from "./models/service-list/get-service-list-response.model";
import { GetServiceTypeItemsResponseDtoMapping } from "./models/service-types/get-service-type-items-response-dto-mapping";
import { GetServiceTypeItemsResponseDto } from "./models/service-types/get-service-type-items-response-dto.model";
import { GetServiceTypeItemsResponse } from "./models/service-types/get-service-type-items-response.model";

@Injectable({
    providedIn: "root",
})
export class MicroservicesApiService {
    private userSubject: BehaviorSubject<GetUserResponse | null> =
        new BehaviorSubject<GetUserResponse | null>(null);
    public user$: Observable<GetUserResponse | null> =
        this.userSubject.asObservable();
    private checkedUserID: string;
    private readonly baseUrl: string;
    private readonly baseUrl2: string;

    constructor(
        private httpClient: HttpClient,
        private authService: AuthService
    ) {
        this.baseUrl = environment.microServiceURL;
        this.baseUrl2 = environment.CCURL;
    }

    public getServiceList(
        companyId: number
    ): Observable<GetServiceListResponse> {
        return this.httpClient
            .get<GetServiceListResponseDto>(
                `${this.baseUrl}/customers/listcompanyservices`,
                {
                    params: { CompanyID: companyId },
                }
            )
            .pipe(
                map((dto) => GetServiceListResponseDtoMapping.mapToModel(dto))
            );
    }

    public enableDisableService(
        companyId: number,
        serviceId: number,
        IsActive: boolean
    ): Observable<void> {
        return this.httpClient.put<void>(
            `${this.baseUrl}/customers/enableanddisableservicesforcompany`,
            {
                CompanyID: companyId,
                ServiceID: serviceId,
                IsActive: IsActive ? 1 : 0,
                UserID: this.authService.systemUserId,
            }
        );
    }

    public getNavItems(companyId: number): Observable<GetMenuItemsResponse> {
        return this.httpClient
            .get<GetMenuItemsResponseDto>(
                `${this.baseUrl}/customers/menus?CompanyID=${companyId}`
            )
            .pipe(map((dto) => GetMenuItemsResponseDtoMapping.mapToModel(dto)));
    }

    public getaddressList(companyId: number): Observable<addressItem[]> {
        return this.httpClient
            .get<GetaddressListResponseDto>(
                `${this.baseUrl}/customers/address`,
                {
                    params: { CompanyID: companyId },
                }
            )
            .pipe(
                map(
                    (res) =>
                        res?.addresses?.map((dto) =>
                            addressItemDtoMapping.mapToModel(dto)
                        )
                )
            );
    }

    public getServiceTypes(): Observable<GetServiceTypeItemsResponse> {
        return this.httpClient
            .get<GetServiceTypeItemsResponseDto>(
                `${this.baseUrl}/customers/carrierservicetypes`
            )
            .pipe(
                map((dto) =>
                    GetServiceTypeItemsResponseDtoMapping.mapToModel(dto)
                )
            );
    }

    public getPackagingTypes(): Observable<GetPackagingTypeItemsResponse> {
        return this.httpClient
            .get<GetPackagingTypeItemsResponseDto>(
                `${this.baseUrl}/customers/packagingtypes`
            )
            .pipe(
                map((dto) =>
                    GetPackagingTypeItemsResponseDtoMapping.mapToModel(dto)
                )
            );
    }

    public getUser(): Observable<GetUserResponse> {
        return this.httpClient
            .post<GetUserResponseDto>(
                `${this.baseUrl2}/v2/getuserdetails`,
                { method: "getuser" },
                { responseType: "json" }
            )
            .pipe(
                map((dto: any) =>
                    GetUserResponseDtoMapping.mapToModel(dto.result)
                ),
                tap((user) => this.userSubject.next(user))
            );
    }
}
