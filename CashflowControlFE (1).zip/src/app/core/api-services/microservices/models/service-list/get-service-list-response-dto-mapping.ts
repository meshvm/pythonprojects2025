import { GetServiceListResponseDto } from "./get-service-list-response-dto.model";
import { GetServiceListResponse } from "./get-service-list-response.model";
import { ServiceListConfigItem } from "./service-list-config-item.model";

export class GetServiceListResponseDtoMapping {
    public static mapToModel(
        dto: GetServiceListResponseDto
    ): GetServiceListResponse {
        return {
            message: {
                services: dto.message.Services.map(
                    (dtoItem) =>
                        ({
                            serviceCode: dtoItem.ServiceCode,
                            serviceId: dtoItem.ServiceID,
                            serviceName: dtoItem.ServiceName,
                            numberOfProjects: dtoItem.NumberOfProjects,
                            companyServiceId: dtoItem.CompanyServiceID,
                            IsActive: dtoItem.IsActive,
                            imageUrl: dtoItem.ImageUrl,
                            pageUrl: dtoItem.PageUrl,
                        }) as ServiceListConfigItem
                ),
            },
        };
    }
}
