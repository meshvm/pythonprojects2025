import { addressItemDto } from "./address-item-dto.model";
import { addressItem } from "./address-item.model";

export class addressItemDtoMapping {
    public static mapToModel(dto: addressItemDto): addressItem {
        const {
            addressID: addressId,
            address1: address1,
            address2: address2,
            City: city,
            StateProvinceName: stateProvinceName,
            CountryAbbreviation: countryAbbreviation,
        } = dto;

        return {
            addressId,
            address1,
            address2,
            city,
            stateProvinceName,
            countryAbbreviation,
        };
    }
}
