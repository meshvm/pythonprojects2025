export interface addressItem {
    addressId: string;
    address1: string;
    address2: string;
    city: string;
    stateProvinceName: string;
    countryAbbreviation: string;
}
