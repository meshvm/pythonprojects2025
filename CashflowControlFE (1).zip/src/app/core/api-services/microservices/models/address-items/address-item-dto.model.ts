export interface addressItemDto {
    addressID: string;
    address1: string;
    address2: string;
    City: string;
    StateProvinceName: string;
    CountryAbbreviation: string;
}
