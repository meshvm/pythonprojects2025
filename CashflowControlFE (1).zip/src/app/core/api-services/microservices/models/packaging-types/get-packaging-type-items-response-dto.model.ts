import { PackagingTypeItemDto } from "./packaging-type-item-dto.model";

export interface GetPackagingTypeItemsResponseDto {
    PackagingTypes: PackagingTypeItemDto[];
}
