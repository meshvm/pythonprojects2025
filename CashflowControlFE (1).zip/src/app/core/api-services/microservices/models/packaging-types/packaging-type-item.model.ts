export interface PackagingTypeItem {
    packagingTypeId: number;
    packagingTypeName: string;
}
