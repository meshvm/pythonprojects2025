export interface PackagingTypeItemDto {
    PackagingTypeID: number;
    PackagingTypeName: string;
}
