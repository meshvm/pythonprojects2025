export interface MenuItemDto {
    IconFileName: string;
    IconName: string;
    HasAccess: boolean;
    URL: string;
}
