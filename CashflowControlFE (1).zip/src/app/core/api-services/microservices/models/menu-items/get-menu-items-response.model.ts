import { MenuItem } from "./menu-item.model";

export interface GetMenuItemsResponse {
    menus: MenuItem[];
}
