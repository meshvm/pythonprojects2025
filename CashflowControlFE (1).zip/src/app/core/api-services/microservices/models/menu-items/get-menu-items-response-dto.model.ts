import { MenuItemDto } from "./menu-item-dto.model";

export interface GetMenuItemsResponseDto {
    Menus: MenuItemDto[];
}
