import { GetServiceTypeItemsResponseDto } from "./get-service-type-items-response-dto.model";
import { GetServiceTypeItemsResponse } from "./get-service-type-items-response.model";
import { ServiceTypeItem } from "./service-type-item.model";

export class GetServiceTypeItemsResponseDtoMapping {
    public static mapToModel(
        dto: GetServiceTypeItemsResponseDto
    ): GetServiceTypeItemsResponse {
        return {
            serviceTypes: dto.ServiceTypes.map(
                (serviceTypeDto) =>
                    ({
                        carrierServiceName: serviceTypeDto.CarrierServiceName,
                        carrierServiceId: serviceTypeDto.CarrierServiceID,
                    }) as ServiceTypeItem
            ),
        };
    }
}
