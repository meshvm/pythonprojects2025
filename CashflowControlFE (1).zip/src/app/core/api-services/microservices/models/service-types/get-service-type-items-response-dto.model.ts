import { ServiceTypeItemDto } from "./service-type-item-dto.model";

export interface GetServiceTypeItemsResponseDto {
    ServiceTypes: ServiceTypeItemDto[];
}
