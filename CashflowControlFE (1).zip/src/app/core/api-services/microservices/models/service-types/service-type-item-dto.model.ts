export interface ServiceTypeItemDto {
    CarrierServiceID: number;
    CarrierServiceName: string;
}
