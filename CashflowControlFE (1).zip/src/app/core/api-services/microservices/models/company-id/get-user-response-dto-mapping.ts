import { GetUserResponseDto } from "./get-user-response-dto.model";
import { GetUserResponse } from "./get-user-response.model";

export class GetUserResponseDtoMapping {
    public static mapToModel(dto: GetUserResponseDto): GetUserResponse {
        return {
            companyId: dto.CompanyID,
            FirstName: dto.FirstName,
            LastName: dto.LastName,
            email: dto.Emailaddress,
            ServicePermissions: dto.ServicePermissions,
        };
    }
}
