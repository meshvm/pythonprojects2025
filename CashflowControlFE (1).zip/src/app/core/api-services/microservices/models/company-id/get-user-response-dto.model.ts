import { Dictionary } from "../../../../models/dictionary.model";

export interface GetUserResponseDto {
    CompanyID: number;
    Access: string;
    address1: string;
    address2: string;
    City: string;
    CompanyCode: string;
    CountryID: number;
    CountryName: string;
    DepartmentID: number;
    DepartmentName: string;
    Emailaddress: string;
    FirstName: string;
    IsActive: number;
    IsCrossCompany: number;
    JobTitle: string;
    LastName: string;
    ManagerEmailaddress: string;
    ManagerID: number;
    ManagerName: string;
    PhoneNumber: string;
    PlatformRoleCode: number;
    PlatformRoleID: number;
    PlatformRoleName: string;
    PostalCode: string;
    ServicePermissions: Dictionary<any>[];
    StateProvinceID: number;
    StateProvinceName: string;
}
