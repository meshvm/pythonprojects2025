export enum requestTypeId {
    Question = "question",
    Sales = "sales",
    Technical = "technical",
}
