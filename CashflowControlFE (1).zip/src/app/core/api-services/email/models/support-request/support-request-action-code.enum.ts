export enum SupportRequestActionCode {
    Call = "call",
    Message = "message",
}
