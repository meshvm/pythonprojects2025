export interface ValidaddressOption {
    id: number;
    address: string;
}
