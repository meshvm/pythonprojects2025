import { ParsedaddressDto } from "./parsed-address-dto.model";

export interface GetParsedaddressResponseDto {
    message: string;
    code: string;
    errors: string[];
    address: ParsedaddressDto;
}
