import { AnnualRevenue } from "../../../models/annual-revenue.model";
import { EmployeeSize } from "../../../models/employee-size.model";
import { Industry } from "../../../models/industry.model";

export interface Lovs {
    annualRevenue: AnnualRevenue[];
    industry: Industry[];
    salesRepresentatives: any[];
    employeeSize: EmployeeSize[];
}
