export interface CustomerDto {
    [key: string]: any;

    ID: number;
    CompanyID: number;
    Name?: string;
    CompanyCode?: string;
    AnnualRevenue?: string;
    Industry?: string;
    NumberOfEmployees?: string;
    DateAdded?: string;
    CompanyName?: string;
    AnnualRevenueId?: number;
    AnnualRevenueName?: string;
    IndustryId?: number;
    IndustryName?: string;
    EmployeeSizeId?: number;
    EmployeeSizeName?: string;
    OracleCustomerNumber?: number;
    SalesRepresentativeId?: number;
    DisplayName?: string;
    Emailaddress?: string;
    SendWelcomeEmails?: boolean;
    LogoId?: number;
    LogoName?: string;
    LogoImage?: string;
    LogoFileName?: string;
    BusinessUnitId?: number | null;
    SystemUserId?: number;
}
