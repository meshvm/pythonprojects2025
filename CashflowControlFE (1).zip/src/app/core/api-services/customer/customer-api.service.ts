import { HttpClient, HttpParams } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { environment } from "../../../../environments/environment";
import { Customer } from "../../models/customer.model";
import { Dictionary } from "../../models/dictionary.model";
import { CustomerDtoMapping } from "./models/customer-dto-mapping";
import { CustomerDto } from "./models/customer-dto.model";
import { GetCustomersRequestDto } from "./models/get-customers-request-dto.model";
import { GetCustomersResponseDto } from "./models/get-customers-response-dto.model";
import { GetParsedaddressResponseDto } from "./models/get-parsed-address-response-dto.model";
import { GetValidaddressesResponseDto } from "./models/get-valid-addresses-response-dto.model";
import { Lovs } from "./models/lovs.model";

@Injectable({ providedIn: "root" })
export class CustomerApiService {
    private readonly baseUrl: string;
    private readonly addressValidationApiUrl: string;

    constructor(@Inject(HttpClient) private readonly httpClient: HttpClient) {
        this.baseUrl = environment.microServiceURL;
        this.addressValidationApiUrl = environment.addressValidationApiUrl;
    }

    public getCustomers(
        config: GetCustomersRequestDto
    ): Observable<GetCustomersResponseDto> {
        let params = new HttpParams();

        Object.keys(config).forEach((key) => {
            params = params.set(key, (config as Dictionary<any>)[key]);
        });

        return this.httpClient
            .get<GetCustomersResponseDto>(`${this.baseUrl}/customers`, {
                params,
            })
            .pipe(
                map((value) => {
                    value.customers.map((customer: any) =>
                        CustomerDtoMapping.mapToModel(customer as CustomerDto)
                    );
                    return value;
                })
            );
    }

    public get(companyId: number): Observable<Customer> {
        return this.httpClient
            .get<CustomerDto>(`${this.baseUrl}/customers/getcustomer`, {
                params: {
                    CompanyID: companyId,
                    BusinessUnitID: "",
                },
            })
            .pipe(map((customer) => CustomerDtoMapping.mapToModel(customer)));
    }

    public edit(customer: Partial<Customer>): Observable<CustomerDto> {
        return this.httpClient.put<CustomerDto>(
            `${this.baseUrl}/customers`,
            CustomerDtoMapping.mapToDto(customer as Customer)
        );
    }

    public getLovs(): Observable<Lovs> {
        return this.httpClient.get<Lovs>(`${this.baseUrl}/customers/lovs`);
    }

    public getValidaddresses(
        customerId: string,
        address: string
    ): Observable<GetValidaddressesResponseDto> {
        return this.httpClient.post<GetValidaddressesResponseDto>(
            `${this.addressValidationApiUrl}/${customerId}/addresses/autocomplete`,
            {
                address,
            }
        );
    }

    public parseaddress(
        customerId: string,
        address: string
    ): Observable<GetParsedaddressResponseDto> {
        return this.httpClient.post<GetParsedaddressResponseDto>(
            `${this.addressValidationApiUrl}/${customerId}/addresses/parse`,
            {
                address,
            }
        );
    }
}
