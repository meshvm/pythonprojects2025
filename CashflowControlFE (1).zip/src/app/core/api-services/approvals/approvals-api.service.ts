import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { environment } from "../../../../environments/environment";
import { GetApprovalRuleConfigsResponse } from "./models/get-approval-rule-configs-response.model";
import { ProjectApprovalConfiguration } from "./models/project-approval-configuration.model";
import { ProjectApprovalRuleConfiguration } from "./models/project-approval-rule-configuration.model";

@Injectable({ providedIn: "root" })
export class ApprovalsApiService {
    private readonly baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.CCURL}/approvals`;
    }

    public getProjectApprovalsConfig(
        ProjectID: number
    ): Promise<ProjectApprovalConfiguration> {
        return firstValueFrom(
            this.httpClient.get<ProjectApprovalConfiguration>(
                `${this.baseUrl}?ProjectID=${ProjectID}`
            )
        );
    }

    public updateProjectApprovalsConfig(
        ProjectID: number,
        config: Partial<ProjectApprovalConfiguration>
    ): Promise<void> {
        return firstValueFrom(
            this.httpClient.put<void>(
                `${this.baseUrl}?ProjectID=${ProjectID}`,
                config
            )
        );
    }

    public async getApprovalRuleConfigs(
        companyId: number,
        ProjectID: number
    ): Promise<ProjectApprovalRuleConfiguration[]> {
        const res = await firstValueFrom(
            this.httpClient.get<GetApprovalRuleConfigsResponse>(
                `${environment.CCURL}/approval-rules?companyServiceId=${companyId}&ProjectID=${ProjectID}`
            )
        );

        return res?.rules;
    }
}
