export interface ProjectApprovalConfiguration {
    ProjectID: number;
    purchaseOrderThreshold: number;
    usePurchaseOrders: boolean;
}
