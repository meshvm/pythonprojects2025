export enum ProjectApprovalTypeCode {
    All = "All",
    Auto = "Auto",
    One = "One",
}
