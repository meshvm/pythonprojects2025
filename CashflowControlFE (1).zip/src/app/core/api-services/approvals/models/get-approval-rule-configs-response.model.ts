import { ProjectApprovalRuleConfiguration } from "./project-approval-rule-configuration.model";

export interface GetApprovalRuleConfigsResponse {
    rules: ProjectApprovalRuleConfiguration[];
}
