import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { firstValueFrom, Observable } from "rxjs";
import { environment } from "../../../../environments/environment";
import { Dictionary } from "../../models/dictionary.model";
import { RequestInterface } from "../../models/request.model";
import { GetRequestStatusesResponseDto } from "./models/get-request-statuses-response-dto.model";
import { GetRequestTypesResponseDto } from "./models/get-request-types-response-dto.model";
import { GetRequestsResponseDto } from "./models/get-requests-response-dto.model";
import { RequestsQueryDto } from "./models/requests-query-dto.model";

@Injectable({
    providedIn: "root",
})
export class RequestApiService {
    private readonly baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public createRequest(
        requestPayload: RequestInterface
    ): Observable<RequestInterface> {
        return this.httpClient.post<RequestInterface>(
            `${this.baseUrl}/requests`,
            requestPayload
        );
    }

    public updateRequest(
        requestPayload: Partial<RequestInterface>,
        id: number
    ): Observable<RequestInterface> {
        return this.httpClient.put<RequestInterface>(
            `${this.baseUrl}/requests/${id}`,
            requestPayload
        );
    }

    public deleteRequest(id: number): Observable<void> {
        return this.httpClient.delete<void>(`${this.baseUrl}/requests/${id}`);
    }

    public getRequestsForUser(
        queries: RequestsQueryDto
    ): Promise<GetRequestsResponseDto> {
        return firstValueFrom(
            this.httpClient.get<GetRequestsResponseDto>(
                `${this.baseUrl}/requests/user`,
                {
                    params: queries as Dictionary<any>,
                }
            )
        );
    }

    public getRequestsForTeam(
        queries: RequestsQueryDto
    ): Promise<GetRequestsResponseDto> {
        return firstValueFrom(
            this.httpClient.get<GetRequestsResponseDto>(
                `${this.baseUrl}/requests/team`,
                {
                    params: queries as Dictionary<any>,
                }
            )
        );
    }

    public getRequest(id: number): Observable<RequestInterface> {
        return this.httpClient.get<RequestInterface>(
            `${this.baseUrl}/requests/${id}`
        );
    }

    public getStatusList(
        stageName: string
    ): Observable<GetRequestStatusesResponseDto> {
        return this.httpClient.get<GetRequestStatusesResponseDto>(
            `${this.baseUrl}/requests/statuses`,
            {
                params: {
                    stageName,
                },
            }
        );
    }

    public getTypes(): Observable<GetRequestTypesResponseDto> {
        return this.httpClient.get<GetRequestTypesResponseDto>(
            `${this.baseUrl}/requests/types`
        );
    }

    public exportSelectedRequests(payload: any): Observable<string> {
        return this.httpClient.post<string>(
            `${this.baseUrl}/files/export`,
            payload,
            {
                responseType: "text" as any,
            }
        );
    }
}
