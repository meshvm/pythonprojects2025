import { TestBed } from "@angular/core/testing";

import { RequestApiService } from "./request-api.service";
import { HttpClientModule } from "@angular/common/http";

describe("RequestApiService", () => {
    let service: RequestApiService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientModule],
        });
        service = TestBed.inject(RequestApiService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });
});
