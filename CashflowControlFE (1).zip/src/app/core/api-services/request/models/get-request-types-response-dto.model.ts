export interface GetRequestTypesResponseDto {
    requestTypes: {
        requestTypeName: string;
    }[];
}
