export interface GetRequestStatusesResponseDto {
    requestStatuses: {
        statusName: string;
    }[];
}
