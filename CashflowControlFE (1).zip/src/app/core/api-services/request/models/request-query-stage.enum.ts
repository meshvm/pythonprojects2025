export enum RequestQueryStage {
    Ongoing = "ongoing",
    Saved = "saved",
    Approval = "approval",
    Archive = "archive",
}
