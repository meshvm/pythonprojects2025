import { Dictionary } from "../../../models/dictionary.model";
import { RequestInterface } from "../../../models/request.model";

export interface GetRequestsResponseDto {
    results: RequestInterface[];
    metadata: {
        numberOfRequests: Dictionary<number>;
    };
}
