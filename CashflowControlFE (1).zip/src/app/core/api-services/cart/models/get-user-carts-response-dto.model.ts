import { CartItem } from "./cart-item.model";

export interface GetUserCartsResponseDto {
    shoppingCarts: CartItem[];
    totalCount: number;
}
