export interface CartItem {
    totalItems: number;
    totalPrice: number;
    shoppingCartId: number;
    correspondenceRequests: Request[];
}
