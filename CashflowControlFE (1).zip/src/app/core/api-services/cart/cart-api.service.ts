import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "../../../../environments/environment";
import { CartItem } from "./models/cart-item.model";

@Injectable({
    providedIn: "root",
})
export class CartApiService {
    private readonly baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public getUserCarts(): Observable<CartItem> {
        return this.http.get<CartItem>(`${this.baseUrl}/carts`);
    }

    public createCart(requestId: number): Observable<any> {
        return this.http.post(`${this.baseUrl}/carts`, {
            requestId,
        });
    }

    public addToCart(requestId: number): Observable<any> {
        return this.http.post(`${this.baseUrl}/carts/request`, {
            requestId,
        });
    }

    public clearCart(): Observable<any> {
        return this.http.delete(`${this.baseUrl}/carts`);
    }

    public removeCartItem(requestId: number): Observable<any> {
        return this.http.delete(`${this.baseUrl}/carts/request/${requestId}`);
    }
}
