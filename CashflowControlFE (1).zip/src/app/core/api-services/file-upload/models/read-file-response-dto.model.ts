export interface ReadFileResponseDto {
    requestID: number;
    fileName: string;
    fileContent: string;
}
