export interface EmployeeSize {
    employeeSizeId: number;
    employeeSizeName: string;
}
