export interface LabeledValue {
    label: string;
    value: string | number | boolean;
}
