import { UserTeam } from "../api-services/user-permission/models/teams/user-team.model";
import { Project } from "./project.model";

export interface UserDetails {
    SystemUserID: number;
    FirstName: string;
    LastName: string;
    EmailAddress: string;
    DepartmentName?: string;
    PhoneNumber?: string;
    Address?: string;
    ServiceRoleID?: number;
    ServiceRoleName?: string;
    Projects?: Project[];
    IsActive?: boolean | number;
    HasAccess?: boolean;
    Teams?: UserTeam[];
    service?: string;
    selected?: boolean;
}
