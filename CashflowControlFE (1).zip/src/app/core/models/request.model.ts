import { RequestTypeName } from "./request-type-name.enum";

export interface RequestInterface {
    orderNumber: string;
    orderLineNumber: string;
    requestId: number;
    companyId: number;
    serviceStatusId: number;
    ProjectID: number;
    serviceRequestTypeId: number;
    requestTypeName: RequestTypeName;
    requestDescription: string;
    requestStatus: string;
    returnaddressId: number;
    purchaseOrderFileName: string;
    requester: {
        userId: number;
        FirstName: string;
        LastName: string;
        email: string;
        city: string;
        state: string;
        userName?: string;
    };
    approver: {
        userId: number;
        FirstName: string;
        LastName: string;
    };
    deliverTo: {
        addressBookName: string;
        addresses: [
            {
                FirstName: string;
                LastName: string;
                addressLine1: string;
                addressLine2: string;
                city: string;
                state: string;
                postalCode: string;
                stateProvinceAbbreviation: string;
                addressFromApiOverride?: boolean;
            },
        ];
    };
    correspondenceOptions: {
        packagingTypeId: number;
        packagingTypeName: string;
        carrierServiceId: number;
        carrierServiceName: string;
    };
    correspondenceContent: {
        previewFileName: string;
        sessionId: number;
        uId: number;
        preliminaryQuantity: number;
        documents: [
            {
                sequenceId: number;
                fileName: string;
                fileUrl: string;
            },
        ];
    };
    billing: {
        billingDepartmentId: number;
        billingDepartmentName: string;
        totalBillingAmount: number;
        billingItems: any[];
        purchaseOrderNumber: number;
    };
    isAcceptanceAcknowledged: boolean;
    createdById: number;
    createdDateTimeUTC: string;
    createdDateTimeLocal: string;
    updatedById: number;
    updatedDateTimeUTC: string;
    updatedDateTimeLocal: string;
    orderAcknowledged: boolean;
    status?: string;
}
