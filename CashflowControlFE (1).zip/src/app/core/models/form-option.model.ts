export interface FormOption {
    id: number;
    label: string;
    value: string;
}
