export enum SortOrder {
    Asc = "ASC",
    Desc = "DESC",
}
