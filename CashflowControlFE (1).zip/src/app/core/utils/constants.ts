import { getDateByRule } from "./date";

export const RECAPTCHA_KEY = "6LeHRDsfAAAAAOkNj6VcGBU8jcX1qjiMqV_jhXMf";

export const OBSERVED_HOLIDAYS = [
    {
        day: "New Year's Day",
        date: `01-01-${new Date().getFullYear()}`,
        off: false,
    },
    {
        day: "Memorial Day",
        date: getDateByRule(new Date().getFullYear(), 4, 5, 1),
        off: false,
    },
    {
        day: "Independence Day",
        date: `07-04-${new Date().getFullYear()}`,
        off: false,
    },
    {
        day: "Labor Day",
        date: getDateByRule(new Date().getFullYear(), 8, 1, 1),
        off: false,
    },
    {
        day: "Thanksgiving Day",
        date: getDateByRule(new Date().getFullYear(), 10, 4, 4),
        off: false,
    },
    {
        day: "Christmas Day",
        date: `12-25-${new Date().getFullYear()}`,
        off: false,
    },
];

export const WEEKLY_SCHEDULE = [
    {
        day: "Monday",
        startTime: "08:00",
        endTime: "15:00",
        off: false,
    },
    {
        day: "Tuesday",
        startTime: "08:00",
        endTime: "15:00",
        off: false,
    },
    {
        day: "Wednesday",
        startTime: "08:00",
        endTime: "15:00",
        off: false,
    },
    {
        day: "Thursday",
        startTime: "08:00",
        endTime: "15:00",
        off: false,
    },
    {
        day: "Friday",
        startTime: "08:00",
        endTime: "15:00",
        off: false,
    },
    {
        day: "Saturday",
        off: true,
    },
    {
        day: "Sunday",
        off: true,
    },
];

export const SERVICE_ID = 5;
export const FILE_UPLOAD_LIMIT = 100 * 1024 * 1024; //100MB;
export const PDF_PAGE_LIMIT = 16;
export const TEAMID_FOR_REQUESTS = 1; //Set for MVP, will be removed when
export const BILLING_BASE_PRICE = 0.4108;
export const REQUEST_STAGES = ["ongoing", "saved", "approval", "archive"];
export const REQUEST_DATE_FILTERS = [
    {
        label: "Custom",
        value: "custom",
    },
    {
        label: "Last 7 days",
        value: "last_7_days",
    },
    {
        label: "Last 30 days",
        value: "last_30_days",
    },
    {
        label: "Last 90 days",
        value: "last_90_days",
    },
    {
        label: "Last Year",
        value: "last_year",
    },
];
