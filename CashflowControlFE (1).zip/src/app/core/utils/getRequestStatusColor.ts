export default function getRequestStatusColor(status: string) {
    let color = "#DEDEDE";
    switch (status) {
        case "In Transit":
            color = "#276863";
            break;
        case "Draft":
            color = "#DEDEDE";
            break;
        case "Pending Approval":
            color = "#8C1D1D";
            break;
        case "Processing":
            color = "#455A3F";
            break;
        case "Printed":
            color = "#366677";
            break;
        case "Saved":
            color = "#274956";
            break;
        case "Shipped":
            color = "#29716C";
            break;
        case "Out for Delivery":
            color = "#215B56";
            break;
        case "Delivered":
            color = "#1C4B47";
            break;
        case "Denied":
            color = "#764D50";
            break;
        case "Cancelled":
            color = "#4B4D4E";
            break;
        case "Canceled":
            color = "#4B4D4E";
            break;
        default:
            color = "#DEDEDE";
            break;
    }
    return color;
}
