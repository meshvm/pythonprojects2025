import { formatDate } from "@angular/common";

export function getDateByRule(
    year: number,
    month: number,
    week: number,
    day: number
) {
    const date = new Date(year, month, 1);
    let add = ((day - date.getDay() + 7) % 7) + (week - 1) * 7;

    do {
        date.setMonth(month);
        date.setDate(1 + add);
        add -= 7;
    } while (date.getMonth() !== month);

    return formatDate(date, "MM-dd-YYYY", "en-US");
}
