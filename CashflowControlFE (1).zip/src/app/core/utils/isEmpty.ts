export function isEmpty(value: string | any): boolean {
    if (value === undefined || value === null) {
        return true;
    }

    if (typeof value === "string") {
        return value.trim().length === 0;
    }

    if (Array.isArray(value)) {
        return value.length === 0;
    }

    if (typeof value === "object") {
        return Object.keys(value).length === 0;
    }

    return false;
}

function isEmptyDeliveryaddress(obj: any) {
    return (
        isEmpty(obj.FirstName) ||
        isEmpty(obj.LastName) ||
        isEmpty(obj.addressLine1) ||
        isEmpty(obj.city) ||
        isEmpty(obj.postalCode)
    );
}

export function isEmptyDeliveryaddressCollection(arr: any[]) {
    return (
        !Array.isArray(arr) ||
        !arr.length ||
        arr.some((item) => isEmptyDeliveryaddress(item))
    );
}
