import { AuthService } from "./auth-oidc.service";

export function authAppInitializerFactory(
    authService: AuthService
): () => Promise<void> {
    return () => authService.runInitialLoginSequence();
}
