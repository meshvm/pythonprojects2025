import { AbstractControl, ValidatorFn } from "@angular/forms";
import { Dictionary } from "../models/dictionary.model";
import { DateTimeHelper } from "./date-time-helper";

export class ReactiveFormsValidationHelper {
    private static readonly dateEarlierThanFieldErrorCode =
        "dateEarlierThanField";
    private static readonly numberLengthValidatorErrorCode = "maxNumberLength";
    private static readonly decimalLengthValidatorErrorCode =
        "maxDecimalLength";

    public static getDateEarlierThanFieldValidatorFn(
        startDateField: string,
        endDateField: string
    ): ValidatorFn {
        return (formGroup: AbstractControl): Dictionary<any> | null => {
            const startDate = formGroup.get(startDateField)?.value;
            const endDate = formGroup.get(endDateField)?.value;

            if (
                DateTimeHelper.getStartDateIsEarlierThenEndDate(
                    startDate,
                    endDate
                )
            ) {
                return {
                    [this.dateEarlierThanFieldErrorCode]: true,
                };
            }
            return null;
        };
    }

    public static numberLengthValidator(max: number): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const value = control.value;

            if (value && value.toString().length > max) {
                return {
                    [ReactiveFormsValidationHelper.numberLengthValidatorErrorCode]:
                        { value: control.value },
                };
            }
            return null;
        };
    }

    public static decimalLengthValidator(
        maxIntegerLength: number,
        maxFractionLength: number
    ): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const value: string = control.value?.toString();

            if (!value) {
                return null;
            }

            const [integerPart, fractionalPart] = value.includes(".")
                ? value.split(".")
                : [value, ""];

            if (
                (integerPart && integerPart.length > maxIntegerLength) ||
                (fractionalPart && fractionalPart.length > maxFractionLength)
            ) {
                return {
                    [ReactiveFormsValidationHelper.decimalLengthValidatorErrorCode]:
                        {
                            requiredIntegerLength: maxIntegerLength,
                            requiredFractionLength: maxFractionLength,
                            actualIntegerLength: integerPart.length,
                            actualFractionLength: fractionalPart.length,
                        },
                };
            }

            return null;
        };
    }
}
