export class BlobHelper {
    public static base64ToBlob(base64String: string, type?: string): Blob {
        const byteCharacters = atob(base64String);
        const byteArrays = [];

        for (let i = 0; i < byteCharacters.length; i++) {
            byteArrays.push(byteCharacters.charCodeAt(i));
        }

        const byteArray = new Uint8Array(byteArrays);

        if (type) {
            return new Blob([byteArray]);
        }

        return new Blob([byteArray], { type });
    }

    public static base64ToBlobUrl(base64: string): string {
        const binaryString = window.atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; ++i) {
            bytes[i] = binaryString.charCodeAt(i);
        }

        const blob = new Blob([bytes], { type: "application/pdf" });
        return URL.createObjectURL(blob);
    }
}
