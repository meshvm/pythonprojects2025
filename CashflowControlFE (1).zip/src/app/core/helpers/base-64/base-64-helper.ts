export class Base64Helper {
    public static fileToBase64(file: File): Promise<any> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () =>
                resolve(
                    reader.result
                        ?.toString()
                        .replace(/^data:application\/pdf;base64,/, "")
                );
            reader.onerror = reject;
        });
    }
}
