import { Injectable } from "@angular/core";
import {
    ActivatedRouteSnapshot,
    CanActivate,
    CanActivateChild,
    RouterStateSnapshot,
} from "@angular/router";
import { Observable } from "rxjs";
import { filter, switchMap, tap } from "rxjs/operators";
import { AuthService as OAuthService } from "src/app/core/oidc/auth-oidc.service";

@Injectable({
    providedIn: "root",
})
export class AuthGuard implements CanActivate, CanActivateChild {
    constructor(private oauthService: OAuthService) {}

    public canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<boolean> {
        return this.oauthService.isDoneLoading$.pipe(
            filter((isDone) => isDone),
            switchMap(() => this.oauthService.isAuthenticated$),
            tap(
                (isAuthenticated) =>
                    isAuthenticated || this.oauthService.login(state.url)
            )
        );
    }

    public canActivateChild(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): boolean | Observable<boolean> | Promise<boolean> {
        return this.canActivate(route, state);
    }
}
