import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

@Injectable({
    providedIn: "root",
})
export class LoaderService {
    public readonly loading$: Observable<boolean>;

    private readonly loadingSubject: BehaviorSubject<boolean>;

    constructor() {
        this.loadingSubject = new BehaviorSubject<boolean>(false);
        this.loading$ = this.loadingSubject.asObservable();
    }

    public setLoading(isLoading: boolean): void {
        this.loadingSubject.next(isLoading);
    }
}
