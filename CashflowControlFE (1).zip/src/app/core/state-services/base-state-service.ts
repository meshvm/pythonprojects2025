import { BehaviorSubject, Observable } from "rxjs";
import { filter, map, take } from "rxjs/operators";
import { Dictionary } from "../models/dictionary.model";
import { StateServiceInterface } from "./models/state-service.interface";

export abstract class BaseStateService<T> implements StateServiceInterface<T> {
    public stateSubject: BehaviorSubject<T>;
    public state$: Observable<T>;

    protected loadFn: (key: any) => Promise<any>;

    private keysEnum: { [key: string]: string };
    private loadingStatus: BehaviorSubject<{ [key: string]: boolean }>;

    protected constructor(keysEnum: { [key: string]: string }) {
        this.loadingStatus = new BehaviorSubject<{ [key: string]: boolean }>(
            {}
        );

        this.keysEnum = keysEnum;
        this.initStateSubject(keysEnum);

        this.state$ = this.stateSubject.asObservable();
    }

    public get state(): T {
        return this.stateSubject.value;
    }

    public async getStateValue<V>(key: string): Promise<V> {
        await this.loadOptionIfNeeded(key);

        return (this.stateSubject.value as Dictionary<V>)[key];
    }

    public getStateValue$<V>(key: string): Observable<V> {
        this.loadOptionIfNeeded(key);

        return this.state$.pipe(
            map((state) => (state as Dictionary<V>)[key] as any)
        ) as Observable<V>;
    }

    public async updateStateValue(key?: string): Promise<void> {
        if (key) {
            this.updateStateSubject(key, await this.loadFn(key));
            return;
        }

        await Promise.all(
            Object.values(this.keysEnum).map(async (enumKey) =>
                this.updateStateSubject(enumKey, await this.loadFn(enumKey))
            )
        );
    }

    public clearState(): void {
        this.stateSubject.next({} as T);
    }

    protected initStateSubject(keysEnum: { [key: string]: string }): void {
        const initialState = {} as T;
        Object.values(keysEnum).forEach(
            (key) => ((initialState as Dictionary<any>)[key] = null)
        );

        this.stateSubject = new BehaviorSubject<T>(initialState);
    }

    protected updateStateSubject(key: string, value: any): void {
        this.stateSubject.next({
            ...this.stateSubject.value,
            [key]: value,
        });
    }

    private getLoadingFinished$(key: string): Promise<any> {
        return this.loadingStatus
            .asObservable()
            .pipe(
                filter((val) => !val[key]),
                take(1)
            )
            .toPromise();
    }

    private async loadOptionIfNeeded(key: string): Promise<void> {
        await this.getLoadingFinished$(key);

        if ((this.stateSubject.value as Dictionary<any>)[key]) {
            return;
        }

        this.loadingStatus.next({
            ...this.loadingStatus.value,
            [key]: true,
        });

        this.updateStateSubject(key, await this.loadFn(key));

        this.loadingStatus.next({
            ...this.loadingStatus.value,
            [key]: false,
        });
    }
}
