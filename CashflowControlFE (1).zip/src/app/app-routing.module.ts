import { NgModule } from "@angular/core";
import { mapToCanActivate, RouterModule, Routes } from "@angular/router";
import { Role } from "./core/models/role.model";
import { ADMIN_ROUTES } from "./modules/admin/admin.routes";
import { AdminLayoutComponent } from "src/app/pages/admin/layout/admin.component";
import { UserLayoutComponent } from "src/app/pages/user/layout/layout.component";
import { USER_ROUTES } from "./modules/user/user.routing";
import { AuthGuard } from "./core/guards/auth-guard.service";

export const routes: Routes = [
    {
        path: "IBP_Management",
        component: AdminLayoutComponent,
        canActivate: mapToCanActivate([AuthGuard]),
        children: ADMIN_ROUTES,
        data: {
            roles: [Role.Admin],
        },
    },
    {
        path: "IBP_User",
        component: UserLayoutComponent,
        canActivate: mapToCanActivate([AuthGuard]),
        children: USER_ROUTES,
        data: {
            roles: [Role.User],
        },
    },
    {
        path: "",
        redirectTo: "IBP_User/customer",
        pathMatch: "full",
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {}
