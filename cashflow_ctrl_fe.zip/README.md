# CashflowControlFe

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.2.0-rc.1.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
the app is connected to the Dev backend server

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

## Project Description

the project is divided into 2 main parts:

1. the admin part: where the admin can add, edit, delete, and view projects and users permissions.
2. the user part: where the user can view batches, reports and the faq page.

platform should resolve the url for the user and the admin. in the case it doesn't resolves it properly the app tries to identufy the user assigned service and redirect him to the user part of the app.

there are two types of roles, the serivce role is implemented to only allow the user to view the user part of the app and grey out the access to otther parts of the app. then the platform role that should give access to the admin side of the app. but this in not implemented yet. plaform is responsible for the routing.

the routing resolver needs to be properly implemented to restric access based on platform and service roles.

the admin part of the app was cloned from simple send project, the repos is call corresponceServiceFe. there might be some code that is not needed in this project. some dependencies need to be removed. and the componenets can be then deleted.
