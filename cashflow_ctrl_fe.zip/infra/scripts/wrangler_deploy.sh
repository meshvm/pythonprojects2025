#!/bin/bash

wrangler deploy -e "$ENVIRONMENT"