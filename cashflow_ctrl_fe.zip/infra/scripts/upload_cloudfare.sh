#!/bin/bash

# Set vars from arguments
Workspace=$1
CloudflareR2JurisdictionEndpoint=$2
CloudflareR2FrontendBucketName=$3
Environment=$4

aws s3 sync --region us-east-1 --endpoint-url $CloudflareR2JurisdictionEndpoint --delete $Workspace/dist/$Environment s3://$CloudflareR2FrontendBucketName