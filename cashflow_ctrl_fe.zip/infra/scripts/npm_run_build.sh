#!/bin/bash

npm run build:$Environment -- --base-href=/cashflowctrl/