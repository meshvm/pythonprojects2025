export const defaultSearchDebounceTime = 300;
