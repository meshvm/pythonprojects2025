export const savedaddresses = [
    {
        name: "abbGlobex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
    {
        name: "Globex",
        address: {
            line1: "315 Cathryn Dale Suite 786",
            line2: "Input address Line 2",
            city: "Krischester",
            state: "MO",
            postalCode: "28374",
        },
    },
];
