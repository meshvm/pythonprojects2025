export class NavigationHelper {
    public static getBaseUrl(): string {
        return `${window.location.protocol}//${window.location.host}/`;
    }
}
