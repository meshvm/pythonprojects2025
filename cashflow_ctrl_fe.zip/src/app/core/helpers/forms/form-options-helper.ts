import { LabeledValue } from "../../models/labeled-value.model";

export class FormOptionsHelper {
    public static getYesNoOptions(): LabeledValue[] {
        return [
            {
                label: "Yes",
                value: true,
            },
            {
                label: "No",
                value: false,
            },
        ];
    }
}
