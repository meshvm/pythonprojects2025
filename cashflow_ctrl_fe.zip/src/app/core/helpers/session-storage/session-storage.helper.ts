export class SessionStorageHelper {
    private static clientVersion = "cashflow-ctrl-client-version";

    public static setClientVersion(version: string): void {
        sessionStorage.setItem(this.clientVersion, version);
    }
}
