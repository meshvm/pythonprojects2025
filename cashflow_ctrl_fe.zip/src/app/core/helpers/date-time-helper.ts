import * as moment from "moment/moment";

export class DateTimeHelper {
    // Check if the start date is earlier than the end date
    public static getStartDateIsEarlierThenEndDate(
        startDate: string,
        endDate: string
    ): boolean {
        return (
            !!startDate && !!endDate && new Date(startDate) > new Date(endDate)
        );
    }

    public static formatDateToString(dateTime: Date): string {
        return moment(dateTime).format("YYYY-MM-DD");
    }

    public static formatDateTimeToString(dateTime: Date): string {
        return moment(dateTime).startOf("day").format("YYYY-MM-DD HH:mm:ss");
    }
}
