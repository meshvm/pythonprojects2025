import { BehaviorSubject } from "rxjs";

export interface StateServiceInterface<T> {
    state: T;
    stateSubject: BehaviorSubject<T>;
    getStateValue: (key: string) => Promise<any>;
    updateStateValue: (key: string) => Promise<void>;
}
