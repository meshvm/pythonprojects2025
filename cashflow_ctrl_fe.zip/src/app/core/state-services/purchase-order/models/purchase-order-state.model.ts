import { PurchaseOrderStateProperties } from "./purchase-order-state-properties.enum";

export interface PurchaseOrderState {
    [PurchaseOrderStateProperties.Threshold]: number;
}
