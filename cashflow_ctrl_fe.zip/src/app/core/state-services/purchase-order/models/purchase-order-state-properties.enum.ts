export enum PurchaseOrderStateProperties {
    Threshold = "threshold",
    UsePurchaseOrders = "usePurchaseOrders",
}
