import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { ApprovalsApiService } from "../../api-services/approvals/approvals-api.service";
import { ProjectApprovalConfiguration } from "../../api-services/approvals/models/project-approval-configuration.model";
import { UserInfo } from "../../api-services/user-permission/models/user-info.model";
import { UserPermissionApiService } from "../../api-services/user-permission/user-permission-api.service";
import { BaseStateService } from "../base-state-service";
import { PurchaseOrderStateProperties } from "./models/purchase-order-state-properties.enum";
import { PurchaseOrderState } from "./models/purchase-order-state.model";

@Injectable({
    providedIn: "root",
})
export class PurchaseOrderStateService extends BaseStateService<PurchaseOrderState> {
    protected override loadFn: (
        key: PurchaseOrderStateProperties
    ) => Promise<any>;

    private purchaseOrderConfiguration: ProjectApprovalConfiguration;

    constructor(
        private userPermissionApiService: UserPermissionApiService,
        private approvalsApiService: ApprovalsApiService
    ) {
        super(PurchaseOrderStateProperties);

        this.initLoadFn();
    }

    private initLoadFn(): void {
        this.loadFn = async (key: PurchaseOrderStateProperties) => {
            switch (key) {
                case PurchaseOrderStateProperties.UsePurchaseOrders:
                    return await this.loadUsePurchaseOrders();
                case PurchaseOrderStateProperties.Threshold:
                    return await this.loadThreshold();
                default:
                    return null;
            }
        };
    }

    private async loadThreshold(): Promise<number | null> {
        if (this.purchaseOrderConfiguration) {
            return (
                this.purchaseOrderConfiguration?.purchaseOrderThreshold || null
            );
        }

        const ProjectID = await this.loadUserProjectID();

        if (!ProjectID) {
            return null;
        }

        this.purchaseOrderConfiguration =
            await this.approvalsApiService.getProjectApprovalsConfig(ProjectID);
        return this.purchaseOrderConfiguration?.purchaseOrderThreshold || null;
    }

    private async loadUsePurchaseOrders(): Promise<boolean | null> {
        if (this.purchaseOrderConfiguration) {
            return this.purchaseOrderConfiguration?.usePurchaseOrders || null;
        }

        const ProjectID = await this.loadUserProjectID();

        if (!ProjectID) {
            return null;
        }

        this.purchaseOrderConfiguration =
            await this.approvalsApiService.getProjectApprovalsConfig(ProjectID);

        return this.purchaseOrderConfiguration?.usePurchaseOrders || null;
    }

    private async loadUserProjectID(): Promise<number> {
        const userData: UserInfo = await firstValueFrom(
            this.userPermissionApiService.getUserInfo()
        );

        return (userData?.projects || [])[0]?.ProjectID;
    }
}
