import { Injectable } from "@angular/core";
import { BehaviorSubject, firstValueFrom, Observable } from "rxjs";
import { isEmpty } from "src/app/core/utils/isEmpty";
import { CartApiService } from "../api-services/cart/cart-api.service";
import { CartItem } from "../api-services/cart/models/cart-item.model";

@Injectable({
    providedIn: "root",
})
export class CartService {
    public readonly itemCnt$: Observable<number>;
    public cartId: string;

    private cartItemCount: BehaviorSubject<number>;

    constructor(private cartApiService: CartApiService) {
        this.cartItemCount = new BehaviorSubject<number>(0);
        this.itemCnt$ = this.cartItemCount.asObservable();

        this.updateCount();
    }

    public setCount(cnt: number): void {
        this.cartItemCount.next(cnt);
    }

    public async updateCount(): Promise<void> {
        const cart = await firstValueFrom(this.getCart());
        this.cartId = cart?.shoppingCartId?.toString();

        if (!isEmpty(cart)) {
            this.setCount(cart.totalItems);
        }
    }

    public getCart(): Observable<CartItem> {
        return this.cartApiService.getUserCarts();
    }

    public async createCart(requestId: number): Promise<void> {
        await firstValueFrom(this.cartApiService.createCart(requestId));
        await this.updateCount();
    }

    public async addToCart(requestId: number): Promise<void> {
        if (!this.cartId) {
            await this.createCart(requestId);
            return;
        }

        await firstValueFrom(this.cartApiService.addToCart(requestId));
        await this.updateCount();
    }

    public async clearCart(): Promise<void> {
        await firstValueFrom(this.cartApiService.clearCart());
        await this.updateCount();
    }

    public async removeCartItem(requestId: number): Promise<void> {
        await firstValueFrom(this.cartApiService.removeCartItem(requestId));
        await this.updateCount();
    }
}
