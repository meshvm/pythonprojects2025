import { Injectable } from "@angular/core";
import { MatSnackBar, MatSnackBarConfig } from "@angular/material/snack-bar";

@Injectable({
    providedIn: "root",
})
export class NotificationService {
    private static readonly successPanelClass = "success-snackbar";
    private static readonly errorPanelClass = "error-snackbar";
    private static readonly defaultConfig: MatSnackBarConfig = {
        duration: 3000,
        verticalPosition: "top",
        panelClass: "default-snackbar",
    };

    constructor(private matSnackBar: MatSnackBar) {}

    public showSuccessMsg(message: string): void {
        this.matSnackBar.open(message, "", {
            ...NotificationService.defaultConfig,
            panelClass: NotificationService.successPanelClass,
        });
    }

    public showErrorMsg(message: string): void {
        this.matSnackBar.open(message, "", {
            ...NotificationService.defaultConfig,
            panelClass: NotificationService.errorPanelClass,
        });
    }
}
