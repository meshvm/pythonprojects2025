import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { UserRole } from "src/app/shared/models/users/user-roles.enum";

@Injectable({
    providedIn: "root",
})
export class UserService {
    private userRole = new BehaviorSubject<UserRole>(UserRole.general);
    private comanyId = new BehaviorSubject<number>(0);
    private userName = new BehaviorSubject<string>("");

    set currentUserName(name) {
        this.userName.next(name);
    }

    get currentUserName() {
        return this.userName.getValue();
    }

    get currentUserRole() {
        return this.userRole.asObservable();
    }

    get currentUserRoleId() {
        return this.userRole.getValue();
    }

    setUserRole(role: UserRole) {
        this.userRole.next(role);
    }

    get currentCompanyId() {
        return this.comanyId.asObservable();
    }

    get currentCompanyIdValue(): number {
        return this.comanyId.getValue();
    }

    setCompanyId(id: number) {
        this.comanyId.next(id);
    }
}
