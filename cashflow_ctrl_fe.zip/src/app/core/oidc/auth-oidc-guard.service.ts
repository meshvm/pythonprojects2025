import {
    ActivatedRouteSnapshot,
    Router,
    RouterStateSnapshot,
} from "@angular/router";

import { AuthService } from "./auth-oidc.service";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";

@Injectable()
export class AuthorizationGuard {
    constructor(
        private authService: AuthService,
        private router: Router
    ) {}

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<boolean> {
        return this.authService.canActivateProtectedRoutes$.pipe(
            tap((isAuthenticated) => {
                if (isAuthenticated === false) {
                    window.location.href = `${window.location.origin}/IBP/Login?returnUrl=${state.url}`;
                }
            })
        );
    }
}
