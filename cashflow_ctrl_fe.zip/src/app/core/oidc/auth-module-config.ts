import { OAuthModuleConfig } from "angular-oauth2-oidc";

export const authModuleConfig: OAuthModuleConfig = {
    resourceServer: {
        allowedUrls: ["https://dev.ricohibp.com/IBP_OAuth/rest"],
        sendAccessToken: true,
    },
};
