import { AuthConfig } from "angular-oauth2-oidc";
import { environment } from "src/environments/environment";

export const authConfig: AuthConfig = {
    issuer: environment.oauthConfig.issuer,
    loginUrl: environment.oauthConfig.loginUrl,
    tokenEndpoint: environment.oauthConfig.tokenEndpoint,
    clientId: environment.oauthConfig.clientId,
    dummyClientSecret: environment.oauthConfig.dummyClientSecret,
    logoutUrl: environment.oauthConfig.logoutUrl,
    redirectUri: window.location.origin + environment.oauthConfig.redirectPath,
    silentRefreshRedirectUri:
        window.location.origin +
        environment.oauthConfig.redirectPath +
        "silent-refresh.html",
    scope: "openid profile email api offline_access",
    responseType: "code",
    strictDiscoveryDocumentValidation: false,
    useSilentRefresh: true,
    silentRefreshTimeout: 5000,
    timeoutFactor: 0.25,
    sessionChecksEnabled: true,
    showDebugInformation: true,
    clearHashAfterLogin: false,
    nonceStateSeparator: "semicolon",
};
