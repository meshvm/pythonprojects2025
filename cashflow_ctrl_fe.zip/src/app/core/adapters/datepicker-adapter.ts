import { formatDate } from "@angular/common";
import { NativeDateAdapter } from "@angular/material/core";

export class DatepickerAdapter extends NativeDateAdapter {
    public static datepickerFormats = {
        parse: {
            dateInput: { month: "short", year: "numeric", day: "numeric" },
        },
        display: {
            dateInput: "input",
            monthYearLabel: { year: "numeric", month: "short" },
            dateA11yLabel: { year: "numeric", month: "long", day: "numeric" },
            monthYearA11yLabel: { year: "numeric", month: "long" },
        },
    };

    override format(date: Date, displayFormat: any): string {
        if (displayFormat === "input") {
            return formatDate(date, "MM-dd-YYYY", this.locale);
        }
        return date.toDateString();
    }
}
