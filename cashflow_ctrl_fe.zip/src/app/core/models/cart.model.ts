import { RequestInterface } from "./request.model";

export interface ShoppingCartInterface {
    shoppingCartId: number;
    totalItems: number;
    totalCorrespondenceRequests: number;
    totalPrice: number;
    correspondenceRequests: RequestInterface[];
    createdById: number;
    createdDateTimeUtc: string;
    createdDateTimeLocal: string;
    updatedByID: number;
    updatedDateTimeUTC: string;
    updatedDateTimeLocal: string;
}
