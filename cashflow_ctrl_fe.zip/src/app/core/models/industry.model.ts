export interface Industry {
    industryId: number;
    industryName: string;
}
