export enum RequestTypeName {
    Batch = "Batch",
    Single = "Single",
}
