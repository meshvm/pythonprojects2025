export interface Customer {
    [key: string]: any;
    id: number;
    companyId: number;
    name?: string;
    companyCode?: string;
    annualRevenue?: string;
    industry?: string;
    numberOfEmployees?: string;
    dateAdded?: string;
    companyName?: string;
    annualRevenueId?: number;
    annualRevenueName?: string;
    industryId?: number;
    industryName?: string;
    employeeSizeId?: number;
    employeeSizeName?: string;
    oracleCustomerNumber?: number;
    salesRepresentativeId?: number;
    displayName?: string;
    Emailaddress?: string;
    sendWelcomeEmails?: boolean;
    logoId?: number;
    logoName?: string;
    logoImage?: string;
    logoFileName?: string;
    businessUnitId?: number | null;
    systemUserId?: number;
}
