export interface RequestDetail {
    FirstName: string;
    LastName: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    stateOrProvince: string;
    postalCode: string;
    printFileName?: string;
    addressFromApiOverride?: boolean;
}
