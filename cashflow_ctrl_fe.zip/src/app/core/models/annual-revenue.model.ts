export interface AnnualRevenue {
    annualRevenueId: number;
    annualRevenueName: string;
}
