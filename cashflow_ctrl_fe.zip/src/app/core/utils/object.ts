export function convertKeyName(object: any): any {
    const convertedObject: any = {};

    for (const key in object) {
        if (object.hasOwnProperty(key)) {
            let newKey = key.toLowerCase();
            newKey = newKey.replace(/_./g, (match) =>
                match.charAt(1).toUpperCase()
            );
            newKey = newKey.charAt(0).toUpperCase() + newKey.slice(1);
            convertedObject[newKey] = object[key];
        }
    }

    return convertedObject;
}
