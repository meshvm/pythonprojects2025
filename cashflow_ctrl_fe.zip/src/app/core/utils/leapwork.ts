/**
 * Retrieves the value of the [data-lp] attribute
 * @param title The string value.
 * @returns The value of the [data-lp] attribute.
 */
export function getLPAttr(
    uiElement: string,
    title: string,
    region = ""
): string {
    // Remove whitespace and underscore from UI element and title
    uiElement = uiElement.replace(/\s+|_/g, "");
    title = title?.replace(/\s+|_/g, "");

    // Replace ampersand with "and" in UI element and title
    uiElement = uiElement.replace(/&/g, "and");
    title = title?.replace(/&/g, "and");

    // Remove special symbols from UI element and title
    uiElement = uiElement?.replace(/[^\w\s]|_/g, "");
    title = title?.replace(/[^\w\s]|_/g, "");

    // Convert UI element and title to lowercase
    uiElement = uiElement?.toLowerCase();
    title = title?.toLowerCase();

    // Combine UI element and title
    let lpAttr = uiElement + "_" + title;

    // Add region if provided
    if (region !== "") {
        // Remove whitespace and underscore from region
        region = region?.replace(/\s+|_/g, "");

        // Replace ampersand with "and" in region
        region = region?.replace(/&/g, "and");

        // Remove special symbols from region
        region = region?.replace(/[^\w\s]|_/g, "");

        // Convert region to lowercase
        region = region?.toLowerCase();

        // Append region to lpAttr
        lpAttr += "_" + region;
    }

    // Return the final value of lpAttr
    return lpAttr;
}
