import { NgModule } from "@angular/core";
import { HeaderAdminModule } from "src/app/features/admin-header/header.module";

import { FooterModule } from "../../features/footer/footer.module";
import { NavigationBarModule } from "../../features/navigation-bar/navigation-bar.module";
import { ToastrModule } from "../../shared/components/toastr/toastr.module";
import { SharedModule } from "../../shared/shared.module";
import { LayoutComponent } from "./layout.component";

@NgModule({
    imports: [
        SharedModule,
        HeaderAdminModule,
        FooterModule,
        NavigationBarModule,
        ToastrModule,
    ],
    declarations: [LayoutComponent],
    exports: [LayoutComponent],
})
export class LayoutModule {}
