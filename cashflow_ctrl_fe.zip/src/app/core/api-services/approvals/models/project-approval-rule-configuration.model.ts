import { ProjectApprovalRuleApprover } from "./project-approval-rule-approver.model";
import { ProjectApprovalTypeCode } from "./project-approval-type-code.enum";

export interface ProjectApprovalRuleConfiguration {
    ruleId: number;
    ruleName: string;
    ruleDisplayName: string;
    ruleDescription: string;
    ruleSequence: number;
    comparisonOperatorId: number;
    comparisonOperatorCode: string;
    comparisonOperatorName: string;
    minRequestBillingTotal: number;
    maxRequestBillingTotal: number;
    approvalTypeId: number;
    approvalTypeCode: ProjectApprovalTypeCode;
    approvalTypeName: string;
    criteriaTypeId: number;
    ruleSetId: number;
    ProjectID: number;
    companyServiceId: number;
    companyId: number;
    createdById: number;
    createdDateTime: string;
    updateById: number;
    updatedDateTime: string;
    approvers: ProjectApprovalRuleApprover[];
}
