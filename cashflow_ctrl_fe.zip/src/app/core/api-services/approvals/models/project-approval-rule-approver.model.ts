export interface ProjectApprovalRuleApprover {
    userId: number;
    FirstName: string;
    LastName: string;
    fullName: string;
    approverSequence: number;
}
