import { SupportRequestActionCode } from "./support-request-action-code.enum";
import { requestTypeId } from "./support-request-type.enum";

export interface SupportRequest {
    isToCallSupport: boolean;
    requestTypeId: requestTypeId;
    requestDescription: string;
    additionalDetails: string;
    phoneNumber?: string;
}
