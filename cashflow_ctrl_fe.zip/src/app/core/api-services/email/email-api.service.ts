import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { environment } from "../../../../environments/environment";
import { SupportRequest } from "./models/support-request/support-request.model";
import { AuthService } from "../../oidc/auth-oidc.service";

@Injectable({ providedIn: "root" })
export class EmailApiService {
    private readonly baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.suppportEmail}`;
    }

    public createSupportRequest(request: SupportRequest): Promise<void> {
        return firstValueFrom(
            this.httpClient.post<void>(
                `${this.baseUrl}/send_support_request`,
                request
            )
        );
    }

    public getSupportRequestTypes(): Promise<any> {
        return firstValueFrom(
            this.httpClient.get<any>(`${this.baseUrl}/request_types`)
        );
    }
}
