import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable({ providedIn: "root" })
export class ReportsApiService {
    baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public getReportsBatches(companyId: number) {
        return this.httpClient.post<any>(
            `${this.baseUrl}/v1/exceptions/batchlist`,
            { CompanyID: companyId }
        );
    }

    public getReportsFileNames(batchname: string, companyId: number) {
        return this.httpClient.post<any>(
            `${this.baseUrl}/v1/exceptions/transfer-file`,
            { FileName: batchname, CompanyID: companyId }
        );
    }

    public getReportDetails(reportId: string) {
        return this.httpClient.get<any>(
            `${this.baseUrl}/v1/exceptions/read-file/?file_name=${reportId}`
        );
    }
}
