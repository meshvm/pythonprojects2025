import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { map } from "rxjs/operators";
import { environment } from "../../../../environments/environment";
import { UserDetails } from "../../models/user-details.model";
import { GetUserPermissionsDto } from "./models/get-user-permissions-dto.model";
import { GetUserRolesResponseDtoMapping } from "./models/roles/get-user-roles-response-dto-mapping";
import { GetUserRolesResponseDto } from "./models/roles/get-user-roles-response-dto.model";
import { GetUserRolesResponse } from "./models/roles/get-user-roles-response.model";
import { GetTeamsResponseDtoMapping } from "./models/teams/get-teams-response-dto-mapping";
import { GetTeamsResponseDto } from "./models/teams/get-teams-response-dto.model";
import { GetTeamsResponse } from "./models/teams/get-teams-response.model";
import { UserInfo } from "./models/user-info.model";
import { SortOrder } from "../../models/paging/sort-order.enum";
import { UserDetailsResponse } from "./user-permission-interface";

@Injectable({ providedIn: "root" })
export class UserPermissionApiService {
    private readonly customersBaseUrl: string;
    private readonly teamsBaseUrl: string;
    private readonly baseUrl: string;

    constructor(@Inject(HttpClient) private httpClient: HttpClient) {
        this.customersBaseUrl = environment.microServiceURL;
        this.teamsBaseUrl = environment.CCURL;
        this.baseUrl = environment.CCURL;
    }

    public getUserPermissions(
        companyId: number,
        page: number,
        limit: number,
        sort: { field: string; dir: SortOrder },
        searchKeyword: string
    ): Observable<GetUserPermissionsDto> {
        let params = new HttpParams();
        params = params.set("companyID", companyId);
        params = params.set("sortBy", sort.field);
        params = params.set("order", sort.dir);
        params = params.set("fullTextSearch", searchKeyword);
        params = params.set("startIndex", page * limit - limit || 1);
        params = params.set("maxRecords", limit || 10);

        let headers = new HttpHeaders();
        const token = "";
        headers = headers.set("X-Csrftoken", `${token}`);

        return this.httpClient
            .get<GetUserPermissionsDto>(
                `${this.baseUrl}/v2/company/${companyId}/user/permissions`,
                { params, headers }
            )
            .pipe(
                map((response: GetUserPermissionsDto) => {
                    response.result = response.result.map((item: any) => {
                        if (item.HasAccess === 1) {
                            item.HasAccess = true;
                        } else if (item.HasAccess === 0) {
                            item.HasAccess = false;
                        }
                        if (item.IsActive === "Active") {
                            item.IsActive = true;
                        } else {
                            item.IsActive = false;
                        }
                        return item;
                    });
                    return response;
                })
            );
    }

    public assignRoleToUsers(
        roleId: number,
        userIds: number[],
        companyId: number,
        serviceId: number
    ): Observable<void> {
        return this.httpClient.post<void>(
            `${this.baseUrl}/v1/company/${companyId}/user/assigne-role`,
            {
                userIDs: userIds,
                serviceRoles: [
                    {
                        RoleID: roleId,
                        ServiceID: serviceId,
                        IsActive: true,
                    },
                ],
            }
        );
    }

    public assignTeamsToUsers(
        userIds: number[],
        companyId: number,
        serviceId: number,
        teamIds: number[]
    ): Observable<void> {
        return this.httpClient.post<void>(
            `${this.baseUrl}/v1/company/${companyId}/user/assign-team`,
            {
                UserIDs: userIds,
                ServiceIDs: [serviceId],
                TeamIDs: teamIds,
            }
        );
    }

    public activateDeactivateService(
        action: string,
        userIds: number[],
        companyId: number,
        serviceId: number
    ): Observable<void> {
        return this.httpClient.put<void>(`${this.baseUrl}/user-permissions`, {
            companyId: companyId,
            serviceId: serviceId,
            action: action,
            userIds: userIds,
        });
    }

    //get user details
    public getUserDetails(
        companyId: number,
        serviceId: number,
        userId: number
    ): Observable<UserDetails[]> {
        return this.httpClient
            .get<UserDetailsResponse>(
                `${this.baseUrl}/v2/user/${userId}/permission`,
                {
                    params: { companyID: companyId, serviceID: serviceId },
                }
            )
            .pipe(
                map((item) => {
                    item.result.forEach((user: UserDetails) => {
                        if (user.HasAccess === (1 as any)) {
                            user.HasAccess = true;
                        } else if (user.HasAccess === (0 as any)) {
                            user.HasAccess = false;
                        }
                        if (user.IsActive === 1) {
                            user.IsActive = true;
                        } else {
                            user.IsActive = false;
                        }
                    });
                    return item.result;
                })
            );
    }

    public getUserInfo(): Observable<UserInfo> {
        return this.httpClient.get<UserInfo>(`${this.baseUrl}/v2/whoami`);
    }

    public updateUserDetails(
        HasAccess: boolean,
        roleId: number,
        ProjectIDs: number[],
        teamIds: number[],
        companyId: number,
        serviceId: number,
        userId: number
    ) {
        return this.httpClient.put<UserDetails>(
            `${this.baseUrl}/v2/user/${userId}/permission`,
            {
                hasAccess: HasAccess,
                roleID: roleId,
                projectIDs: ProjectIDs,
                teamIDs: teamIds,
                companyID: companyId,
                serviceID: serviceId,
                userID: userId,
            }
        );
    }

    public getTeamsList(companyId: number): Observable<GetTeamsResponse> {
        return this.httpClient
            .get<GetTeamsResponseDto>(
                `${this.teamsBaseUrl}/v1/customers/teams`,
                {
                    params: { CompanyID: companyId, SortColumn: "Team" },
                }
            )
            .pipe(map((dto) => GetTeamsResponseDtoMapping.mapToModel(dto)));
    }

    public getRolesList(companyId: number): Observable<GetUserRolesResponse> {
        return this.httpClient
            .get<GetUserRolesResponseDto>(
                `${this.customersBaseUrl}/customers/users/lovs`,
                {
                    params: { CompanyID: companyId },
                }
            )
            .pipe(map((dto) => GetUserRolesResponseDtoMapping.mapToModel(dto)));
    }
}
