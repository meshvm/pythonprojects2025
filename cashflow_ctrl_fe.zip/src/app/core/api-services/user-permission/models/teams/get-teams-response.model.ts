import { UserTeam } from "./user-team.model";

export interface GetTeamsResponse {
    result: UserTeam[];
}
