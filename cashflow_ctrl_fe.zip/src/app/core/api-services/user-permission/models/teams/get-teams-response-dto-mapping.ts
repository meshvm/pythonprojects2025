import { GetTeamsResponseDto } from "./get-teams-response-dto.model";
import { GetTeamsResponse } from "./get-teams-response.model";
import { UserTeam } from "./user-team.model";

export class GetTeamsResponseDtoMapping {
    public static mapToModel(dto: GetTeamsResponseDto): GetTeamsResponse {
        return {
            result: dto.result.map(
                (dtoItem) =>
                    ({
                        team: dtoItem.Team,
                        teamId: dtoItem.TeamID,
                        TeamName: dtoItem.TeamName,
                    }) as UserTeam
            ),
        };
    }
}
