import { UserTeamDto } from "./user-team-dto.model";

export interface GetTeamsResponseDto {
    result: UserTeamDto[];
}
