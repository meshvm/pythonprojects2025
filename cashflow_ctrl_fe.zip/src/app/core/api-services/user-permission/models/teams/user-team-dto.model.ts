export interface UserTeamDto {
    TeamID: number;
    Team?: string;
    TeamName?: string;
}
