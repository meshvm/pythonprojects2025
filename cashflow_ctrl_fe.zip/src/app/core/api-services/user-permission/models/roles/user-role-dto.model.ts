export interface UserRoleDto {
    SystemRoleName: string;
    SystemRoleID: string;
}
