export interface UserRole {
    systemRoleName: string;
    systemRoleId: string;
}
