import { UserRoleDto } from "./user-role-dto.model";

export interface GetUserRolesResponseDto {
    Roles: UserRoleDto[];
}
