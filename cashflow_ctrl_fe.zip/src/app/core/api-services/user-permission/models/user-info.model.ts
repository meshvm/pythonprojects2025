export interface UserInfo {
    userId: number;
    projects: {
        ProjectID: number;
        ProjectName: string;
    }[];
    isCashflowCtrlAdmin: boolean;
}
