import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { AuthService } from "../../oidc/auth-oidc.service";
import { UserService } from "../../services/users.service";
import {
    BehaviorSubject,
    forkJoin,
    map,
    Observable,
    of,
    switchMap,
} from "rxjs";
import {
    WorkQueue,
    WorkQueueDetails,
    WorkQueueMap,
    WorkQueueResponse,
    ArchiveQueue,
} from "src/app/shared/models/work-queues/work-queue.model";
import * as exceptionTypes from "../../../core/constants/exception-types-constants.json";
interface ExceptionTypes {
    signatureverification: number;
    amountdiscrepancies: number;
    nonstandardcheckformats: number;
    unreadablemicrline: number;
    checkdateoutofrange: number;
    miscellaneousorinvalid: number;
    unknownaccount: number;
    highdonor: number;
    invalidaccount: number;
}
import { SortOrder } from "../../models/paging/sort-order.enum";

@Injectable({ providedIn: "root" })
export class ArchiveServices {
    public demKeyOrder: string[] = [];
    public archiveOrder: string[] = [];

    private workQueueMapSubject: BehaviorSubject<Map<string, any>> =
        new BehaviorSubject(new Map<string, any>());
    // eslint-disable-next-line @typescript-eslint/member-ordering
    public workQueueMap$: Observable<Map<string, any>> =
        this.workQueueMapSubject.asObservable();
    private readonly baseUrl: string;
    private userService: UserService;

    constructor(
        private httpClient: HttpClient,
        private authService: AuthService
    ) {
        this.baseUrl = environment.apiUrl;
        const initialMap = new Map<string, any>();
        this.workQueueMapSubject.next(initialMap);
    }

    /**
     * Retrieves the list of work queue items from the server.
     *
     * This method sends an HTTP GET request to the server to fetch the available batches
     * for a specific job name. The response is processed to extract the `dem_key` from each
     * item and store it in the `demKeyOrder` array.
     *
     * @returns {Observable<any>} An observable that emits the list of work queue items.
     */

    // page: number,
    //     limit: number,
    //     sort: { field: string; dir: SortOrder },
    //     searchKeyword: string

    public getArchiveList(companyId: number): Observable<any> {
        let params = new HttpParams();
        params = params.set("CompanyID", companyId);
        // params = params.set("sortBy", sort.field);
        // params = params.set("order", sort.dir);
        // params = params.set("fullTextSearch", searchKeyword);
        // params = params.set("startIndex", page * limit - limit || 1);
        // params = params.set("maxRecords", limit || 10);
        // this.archiveOrder = [];
        return this.httpClient
            .get<any>(
                `${this.baseUrl}/archivequeue?CompanyID=${companyId}
                &MaxRecords=100&StartIndex=1&FullTextSearch=&SortColumn=`,
                { params }
            )
            .pipe(
                map((response) => {
                    const result = response.result.map((item: any) => {
                        if (item.dem_key) {
                            this.archiveOrder.push(item);
                        }
                        return item;
                    });
                    return result;
                })
            );
    }

    public getArchiveArray(companyId: number): Observable<any[]> {
        return this.getArchiveList(companyId);
    }
}
