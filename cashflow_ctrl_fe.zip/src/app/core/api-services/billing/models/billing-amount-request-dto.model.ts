export interface BillingAmountRequestDto {
    addressCount: number;
    pageCount: number;
    systemUserId: number;
    isDuplexPrinting: boolean;
    billingItems: { billingItemId: number }[];
    requestId: number;
}
