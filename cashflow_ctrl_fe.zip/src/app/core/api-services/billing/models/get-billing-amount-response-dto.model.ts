export interface GetBillingAmountResponseDto {
    requestBillingTotal: number;
}
