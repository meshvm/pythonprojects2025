export interface GetBillingAmountRequestDto {
    addressCount: number;
    pageCount: number;
    systemUserId: number;
    isDuplexPrinting: boolean;
    billingItems: { billingItemId: number }[];
    requestId?: number;
}
