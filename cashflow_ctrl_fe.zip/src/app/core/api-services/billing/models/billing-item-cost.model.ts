export interface BillingItemCost {
    baseUnitPrice: string;
    isDuplexPrinting: boolean;
    highVolumeUnitPrice: string;
    maximumSheetsPerUnit: string;
    overageThresholdPages: string;
    highVolumeThresholdUnits: string;
    lowVolumeOveragePageUnitPrice: string;
    highVolumeOveragePageUnitPrice: string;
}
