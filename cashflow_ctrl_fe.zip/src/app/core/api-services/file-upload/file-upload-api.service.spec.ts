import { TestBed } from "@angular/core/testing";

import { FileUploadApiService } from "./file-upload-api.service";
import { HttpClientModule } from "@angular/common/http";

describe("FileUploadApiService", () => {
    let service: FileUploadApiService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientModule],
        });
        service = TestBed.inject(FileUploadApiService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });
});
