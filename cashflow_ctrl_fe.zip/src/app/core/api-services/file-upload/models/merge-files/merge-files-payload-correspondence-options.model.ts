export interface MergeFilesPayloadCorrespondenceOptions {
    packagingTypeName: string;
    serviceType: string;
}
