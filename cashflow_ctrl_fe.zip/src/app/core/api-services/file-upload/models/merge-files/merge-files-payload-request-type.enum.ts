export enum MergeFilesPayloadRequestType {
    Single = "single",
    Batch = "batch",
}
