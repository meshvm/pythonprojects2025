import { MergeFilesPayloadaddress } from "./merge-files-payload-recipient.model";

export interface MergeFilesPayloadDeliverTo {
    addressBookName: string;
    addresses: MergeFilesPayloadaddress[];
}
