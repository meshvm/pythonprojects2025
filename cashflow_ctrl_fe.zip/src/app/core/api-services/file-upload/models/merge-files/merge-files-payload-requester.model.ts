export interface MergeFilesPayloadRequester {
    userName: string;
    email: string;
    address: string;
    fullName: string;
    companyName: string;
}
