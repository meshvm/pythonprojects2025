export interface MergeFilesPayloadaddress {
    FirstName: string;
    LastName: string;
    addressLine1: string;
    addressLine2: string;
    city: string;
    state: string;
    postalCode: string;
    companyName: string;
}
