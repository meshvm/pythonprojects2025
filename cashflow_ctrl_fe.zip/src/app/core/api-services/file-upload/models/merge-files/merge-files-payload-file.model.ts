export interface MergeFilesPayloadFile {
    bucketName: string;
    objectKey: string;
    order: number;
}
