import { MergeFilesPayloadCorrespondenceOptions } from "./merge-files-payload-correspondence-options.model";
import { MergeFilesPayloadDeliverTo } from "./merge-files-payload-deliver-to.model";
import { MergeFilesPayloadFile } from "./merge-files-payload-file.model";
import { MergeFilesPayloadaddress } from "./merge-files-payload-recipient.model";
import { MergeFilesPayloadRequestType } from "./merge-files-payload-request-type.enum";
import { MergeFilesPayloadRequester } from "./merge-files-payload-requester.model";

export interface MergeFilesPayload {
    requestType: MergeFilesPayloadRequestType;
    requestDescription: string;
    requester: MergeFilesPayloadRequester;
    recipient: MergeFilesPayloadaddress;
    files: MergeFilesPayloadFile[];
    correspondenceOptions: MergeFilesPayloadCorrespondenceOptions;
    deliverTo?: MergeFilesPayloadDeliverTo;
}
