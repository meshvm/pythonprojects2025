export interface MergeFilesResponseDto {
    previewFile: string;
    previewFilePageNumber: number;
    sessionId: string;
    previewFileName: string;
}
