export interface UploadedFileMeta {
    bucketName: string;
    objectKey: string;
    s3Url: string;
}
