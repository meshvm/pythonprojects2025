import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { firstValueFrom, Observable } from "rxjs";
import { environment } from "../../../../environments/environment";
import { MergeFilesPayload } from "./models/merge-files/merge-files-payload.model";
import { MergeFilesResponseDto } from "./models/merge-files/merge-files-response-dto.model";
import { ReadFileResponseDto } from "./models/read-file-response-dto.model";
import { UploadedFileMeta } from "./models/uploaded-file-meta.model";

@Injectable({
    providedIn: "root",
})
export class FileUploadApiService {
    private readonly baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public uploadFile(
        fileName: string,
        file: string
    ): Observable<UploadedFileMeta> {
        return this.httpClient.post<UploadedFileMeta>(
            `${this.baseUrl}/files/upload`,
            {
                fileName,
                file,
            }
        );
    }

    public downloadFile(fileKey: string): Observable<Blob> {
        return this.httpClient.get<Blob>(
            `${this.baseUrl}/files/download?objectKey=${fileKey}`,
            {
                responseType: "blob" as any,
            }
        );
    }

    public readFile(requestId: number): Observable<ReadFileResponseDto> {
        return this.httpClient.get<ReadFileResponseDto>(
            `${this.baseUrl}/files/read?requestId=${requestId}`
        );
    }

    public mergeFiles(
        mergeFileData: MergeFilesPayload
    ): Promise<MergeFilesResponseDto> {
        return firstValueFrom(
            this.httpClient.post<MergeFilesResponseDto>(
                `${this.baseUrl}/files/merge`,
                mergeFileData
            )
        );
    }

    public deleteFile(objectKey: string): Observable<void> {
        return this.httpClient.delete<void>(`${this.baseUrl}/files/delete`, {
            params: { objectKey },
        });
    }
}
