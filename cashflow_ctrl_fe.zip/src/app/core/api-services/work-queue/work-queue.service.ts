import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { AuthService } from "../../oidc/auth-oidc.service";
import { UserService } from "../../services/users.service";
import { ActivatedRoute } from "@angular/router";
import {
    BehaviorSubject,
    forkJoin,
    map,
    Observable,
    of,
    switchMap,
} from "rxjs";
import {
    WorkQueue,
    WorkQueueDetails,
    WorkQueueMap,
    WorkQueueResponse,
    ArchiveQueue,
    ImageArray,
    GetArchive,
} from "src/app/shared/models/work-queues/work-queue.model";
import * as exceptionTypes from "../../../core/constants/exception-types-constants.json";
interface ExceptionTypes {
    signatureverification: number;
    amountdiscrepancies: number;
    nonstandardcheckformats: number;
    unreadablemicrline: number;
    checkdateoutofrange: number;
    miscellaneousorinvalid: number;
    unknownaccount: number;
    highdonor: number;
    invalidaccount: number;
}

@Injectable({ providedIn: "root" })
export class WorkQueueService {
    public demKeyOrder: string[] = [];
    public batchkeys: number[] = [];
    public archiveOrder: any = [];
    public releaseDate: string[];
    public ReleaseDate: string;
    public maxRecords: number;
    public startIndex: number;
    public fullTextSearch: string;
    public SortColumn: string;

    private workQueueMapSubject: BehaviorSubject<Map<string, any>> =
        new BehaviorSubject(new Map<string, any>());
    // eslint-disable-next-line @typescript-eslint/member-ordering
    public workQueueMap$: Observable<Map<string, any>> =
        this.workQueueMapSubject.asObservable();
    private readonly baseUrl: string;
    public companyId: number;

    constructor(
        private httpClient: HttpClient,
        private authService: AuthService,
        private userService: UserService,
        private activatedRoute: ActivatedRoute
    ) {
        this.baseUrl = environment.apiUrl;
        const initialMap = new Map<string, any>();
        this.workQueueMapSubject.next(initialMap);
    }

    /**
     * Updates the work queue map with a new work queue for a given key.
     *
     * @param demKey - The key associated with the work queue to be updated.
     * @param workQueue - The new work queue data to be set.
     *
     * This method creates a deep copy of the provided work queue and updates the
     * internal work queue map with this copy. It then notifies subscribers of the
     * updated map.
     */
    public updateWorkQueueMap(demKey: string, workQueue: any): void {
        const currentMap = this.workQueueMapSubject.getValue();
        const workQueueCopy = JSON.parse(JSON.stringify(workQueue));
        currentMap.set(demKey, workQueueCopy);
        this.workQueueMapSubject.next(currentMap);
    }

    /**
     * Searches for a work queue map entry by the provided demKey.
     *
     * @param demKey - The key to search for in the work queue map.
     * @returns The WorkQueueMap entry associated with the provided demKey, or undefined if not found.
     */
    public searchByDemKey(demKey: string): WorkQueueMap | undefined {
        const currentMap = this.workQueueMapSubject.getValue();
        return currentMap.get(demKey);
    }

    /**
     * Retrieves the list of work queue items from the server.
     *
     * This method sends an HTTP GET request to the server to fetch the available batches
     * for a specific job name. The response is processed to extract the `dem_key` from each
     * item and store it in the `demKeyOrder` array.
     *
     * @returns {Observable<any>} An observable that emits the list of work queue items.
     */
    public getWorkQueueList(): Observable<any> {
        this.demKeyOrder = [];
        return this.httpClient
            .get<any>(`${this.baseUrl}/exceptions/availableBatches`)
            .pipe(
                map((response) => {
                    const result = response.result.map((item: any) => {
                        if (item.dem_key) {
                            this.demKeyOrder.push(item.dem_key);
                        }
                        return item;
                    });
                    return result;
                })
            );
    }

    /**
     * Retrieves the details of a batch from the work queue based on the provided key.
     *
     * @param {string} key - The key used to identify the batch in the work queue.
     * @returns {Observable<WorkQueueDetails>} An observable containing the details of the batch.
     */
    public getBatchDetails(key: string): Observable<WorkQueueDetails> {
        const api_body = {
            DemKey: key,
        };
        return this.httpClient.post<any>(
            `${this.baseUrl}/exceptions/batchDetail`,
            api_body
        );
    }

    /**
     * Retrieves batch images based on the provided demKey and pageKey.
     *
     * @param {string} demKey - The key representing the specific batch.
     * @param {number} pageKey - The key representing the specific page within the batch.
     * @returns {Observable<any>} An observable containing the response with batch images.
     *
     * The method sends an HTTP GET request to fetch image details for the specified batch and page.
     * It then processes the response to filter images with a depth of "BITONAL" and updates the work queue accordingly.
     */
    public getBatchImages(demKey: string, pageKey: number): Observable<any> {
        let req_body = {
            DemKey: demKey,
            PageKey: pageKey,
        };
        return this.httpClient
            .post(`${this.baseUrl}/exceptions/imageDetail`, req_body)
            .pipe(
                map((response: any) => {
                    const workQueue = this.searchByDemKey(demKey);
                    if (workQueue) {
                        response.result.Images.forEach((image: any) => {
                            if (image.Depth === "BITONAL") {
                                workQueue.images.push(image);
                            }
                        });
                        this.updateWorkQueueMap(demKey, workQueue);
                    }
                    return response;
                })
            );
    }

    /**
     * Retrieves the work queue for a given demand key (demKey).
     *
     * This method first fetches the list of work queues and searches for the work queue
     * that matches the provided demKey. If the work queue is found, it maps the work queue
     * and then fetches the batch details for the given demKey. Finally, it processes the
     * batch details and returns the result.
     *
     * @param {string} demKey - The demand key to search for in the work queue.
     * @returns {Observable<any>} An observable that emits the processed batch details.
     * @throws {Error} If no work queue is found for the provided demKey.
     */
    getWorkQueue(demKey: string): Observable<any> {
        return this.getWorkQueueList().pipe(
            switchMap((workQueues: WorkQueueResponse) => {
                const workQueue = workQueues.Batches.find(
                    (batch: WorkQueue) => batch.dem_key === demKey
                );
                if (!workQueue) {
                    throw new Error(
                        `WorkQueue not found for demKey: ${demKey}`
                    );
                }
                const workQueueMap = this.mapWorkQueue(workQueue);
                return this.getBatchDetails(demKey).pipe(
                    map((batchDetail: WorkQueueDetails) =>
                        this.processBatchDetails(workQueueMap, batchDetail)
                    )
                );
            })
        );
    }

    /**
     * Retrieves an array of work queues with their corresponding batch details.
     *
     * This method first fetches a list of work queues, then maps each work queue
     * to its corresponding details. For each work queue, it fetches the batch details
     * and processes them accordingly. If there are no work queues, it returns an empty array.
     *
     * @returns {Observable<any[]>} An observable that emits an array of processed work queues with batch details.
     */
    public getWorkQueuesArray(): Observable<any[]> {
        return this.getWorkQueueList().pipe(
            switchMap((workQueues: WorkQueue[]) => {
                const workQueueMaps = workQueues.map((workQueue) =>
                    this.mapWorkQueue(workQueue)
                );
                const batchDetailsObservables = workQueueMaps.map(
                    (workQueueMap) =>
                        this.getBatchDetails(workQueueMap.demKey).pipe(
                            map((batchDetail: WorkQueueDetails) =>
                                this.processBatchDetails(
                                    workQueueMap,
                                    batchDetail
                                )
                            )
                        )
                );
                if (batchDetailsObservables.length === 0) {
                    return of([]);
                }
                return forkJoin(batchDetailsObservables);
            })
        );
    }

    /**
     * Updates the details of batches with the given commands.
     *
     * @param demKey - The key identifying the batch to be updated.
     * @param commands - The commands containing the details to update the batch.
     * @returns An Observable that emits the result of the update operation.
     */
    public updateBatchesDetails(demKey: any, commands: any): Observable<any> {
        let pay_load = {
            Commands: commands.Commands,
        };
        const json_commands = JSON.parse(JSON.stringify(pay_load, null, 2));
        return this.httpClient.post<any>(
            `${this.baseUrl}/exceptions/commitBatchChanges?demkey=${demKey}`,
            json_commands
        );
    }

    /**
     * Processes batch details and updates the work queue map with relevant information.
     *
     * @param workQueueMap - The map containing work queue details to be updated.
     * @param batchDetail - The batch details containing tables and transactions to be processed.
     * @returns The updated work queue map.
     * @throws Will throw an error if no transactions are found or if no PERSONAL_CHECK page is found.
     */
    private processBatchDetails(
        workQueueMap: any,
        batchDetail: WorkQueueDetails
    ): any {
        batchDetail.Tables.forEach((table: any) => {
            if (table.Name === "Mavro.Dem.WebException") {
                table.Rows.forEach((row: any) => {
                    workQueueMap.exceptions.push({
                        code: exceptionTypes[
                            row.Category?.replace(
                                /-|\s|\./g,
                                ""
                            ).toLowerCase() as keyof ExceptionTypes
                        ],
                        description: row.Category,
                    });
                });
            }
        });
        let checkPage:
            | { PageKey: number; Type: string; Properties: any[] }
            | undefined;
        if (
            !batchDetail.Transactions ||
            batchDetail.Transactions.length === 0
        ) {
            throw new Error(
                `No transactions found for demKey: ${workQueueMap.demKey}`
            );
        }
        batchDetail.Transactions[0].Pages.forEach((page: any) => {
            workQueueMap.AllPageKeys.push(page.PageKey);
            if (page.Type === "PERSONAL_CHECK") {
                checkPage = page;
            }
        });
        if (!checkPage) {
            throw new Error(
                `No PERSONAL_CHECK page found for demKey: ${workQueueMap.demKey}`
            );
        }
        workQueueMap.PageKey = checkPage.PageKey;
        checkPage.Properties.forEach((property: any) => {
            if (property.Name === "RT") {
                workQueueMap.RT = property.Value;
            }
            if (property.Name === "CheckAccountNumber") {
                workQueueMap.CheckAccountNumber = property.Value;
            }
            if (property.Name === "CheckNumber") {
                workQueueMap.CheckNumber = property.Value;
            }
            if (property.Name === "CheckMemo") {
                workQueueMap.CheckMemo = property.Value;
            }
            if (property.Name === "CheckPayorAddress") {
                workQueueMap.CheckPayorAddress = property.Value;
            }
            if (property.Name === "CheckDate") {
                workQueueMap.CheckDate = property.Value;
            }
            if (property.Name === "CheckPayorName") {
                workQueueMap.CheckPayorName = property.Value;
            }
            if (property.Name === "CheckAmount") {
                workQueueMap.CheckAmount = property.Value;
                workQueueMap.CheckAmount = (
                    workQueueMap.CheckAmount / 100
                ).toFixed(2);
            }
        });
        this.updateWorkQueueMap(workQueueMap.demKey, workQueueMap);

        return workQueueMap;
    }

    /**
     * Maps a WorkQueue object to a WorkQueueMap object.
     *
     * @param workQueue - The WorkQueue object to be mapped.
     * @returns A WorkQueueMap object with the mapped properties.
     */
    private mapWorkQueue(workQueue: WorkQueue): WorkQueueMap {
        return {
            id: workQueue.batch_id,
            status: workQueue.status === "WAITING" ? "New" : workQueue.status,
            exceptions: [],
            dateReceived: workQueue.receive_date,
            CheckPayorName: workQueue.owner,
            CheckAmount: workQueue?.CheckAmount,
            demKey: workQueue.dem_key,
            images: [],
            AllPageKeys: [],
        };
    }

    /**
     * Retrieves the list of work queue items from the server.
     *
     * This method sends an HTTP GET request to the server to fetch the available batches
     * for a specific job name. The response is processed to extract the `dem_key` from each
     * item and store it in the `demKeyOrder` array.
     *
     * @returns {Observable<any>} An observable that emits the list of work queue items.
     */
    public getArchiveList(companyId: number): Observable<any> {
        this.archiveOrder = [];
        return this.httpClient
            .get<any>(
                `${this.baseUrl}/archivequeue?CompanyID=${companyId}&StartIndex=1&FullTextSearch=&SortColumn=&MaxRecords=1000`
            )
            .pipe(
                map((response) => {
                    const result = response.result.map((item: any) => {
                        this.archiveOrder.push(item);
                        return item;
                    });
                    return result;
                })
            );
    }

    public getArchiveArray(companyId: number): Observable<any[]> {
        return this.getArchiveList(companyId);
    }

    /**
     * Retrieves batch images based on the provided demKey and pageKey.
     *
     * @param {string} demKey - The key representing the specific batch.
     * @param {number} pageKey - The key representing the specific page within the batch.
     * @returns {Observable<any>} An observable containing the response with batch images.
     *
     * The method sends an HTTP GET request to fetch image details for the specified batch and page.
     * It then processes the response to filter images with a depth of "BITONAL" and updates the work queue accordingly.
     */
    public getArchiveImages(
        BatchID: string,
        ReleaseDate: string,
        CompanyID: number,
        Transaction: number
    ): Observable<any> {
        let params = new HttpParams()
            .set("BatchID", BatchID)
            .set("ReleaseDate", ReleaseDate)
            .set("Transaction", Transaction)
            .set("CompanyID", CompanyID);

        return this.httpClient
            .get(`${this.baseUrl}/archiveImageView/`, { params })
            .pipe(
                map((response: any) => {
                    return response.result;
                })
            );
    }

    /*
     *
     */
    public getQuickViewImages(
        BatchID: string,
        ReleaseDate: string,
        CompanyID: number,
        Transaction: number
    ): Observable<any> {
        let params = new HttpParams()
            .set("BatchID", BatchID)
            .set("ReleaseDate", ReleaseDate)
            .set("Transaction", Transaction)
            .set("CompanyID", CompanyID);

        return this.httpClient
            .get(`${this.baseUrl}/archiveQuickImageView/`, { params })
            .pipe(
                map((response: any) => {
                    return response.result;
                })
            );
    }

    /*
    

        /*
    *
    */
    public getRecord(CompanyID: number, archiveId: number): Observable<any> {
        let params = new HttpParams()
            .set("archiveId", archiveId)
            .set("CompanyID", CompanyID);

        return this.httpClient
            .get(`${this.baseUrl}/archiveLookup/`, { params })
            .pipe(
                map((response: any) => {
                    return response.result;
                })
            );
    }

    /**/

    public getRecordsArchive(
        companyId: number,
        page: number,
        limit: number,
        searchKeyword: string
    ): Observable<any> {
        let params = new HttpParams();
        params = params.set("CompanyID", companyId);
        params = params.set("SortColumn", "");
        // params = params.set("order", sort.dir);
        params = params.set("FullTextSearch", searchKeyword);
        params = params.set("StartIndex", page * limit - limit || 1);
        params = params.set("MaxRecords", limit || 10);

        return this.httpClient
            .get<any>(`${this.baseUrl}/archivequeue`, { params })
            .pipe(
                map((response: GetArchive) => {
                    response.result = response.result.map(
                        (item: ArchiveQueue) => {
                            return item;
                        }
                    );
                    return response.result;
                })
            );
    }
}
