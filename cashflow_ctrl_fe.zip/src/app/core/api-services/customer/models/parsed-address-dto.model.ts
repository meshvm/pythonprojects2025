export interface ParsedaddressDto {
    id: number;
    countryCode: string;
    stateCode: string;
    formattedaddress: string;
    line1: string;
    line2: string;
    line3: string;
    country: string;
    city: string;
    state: string;
    postalCode: string;
    timezone: string;
    coordinates: {
        latitude: number;
        longitude: number;
    };
}
