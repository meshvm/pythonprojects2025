import { Customer } from "../../../models/customer.model";

export interface GetCustomersResponseDto {
    customers: Customer[];
    totalItems: number;
}
