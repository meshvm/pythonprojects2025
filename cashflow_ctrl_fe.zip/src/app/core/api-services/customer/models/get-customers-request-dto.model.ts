import { SortOrder } from "../../../models/paging/sort-order.enum";

export interface GetCustomersRequestDto {
    fullTextSearch: string;
    sortColumn: string;
    sortOrder: SortOrder;
}
