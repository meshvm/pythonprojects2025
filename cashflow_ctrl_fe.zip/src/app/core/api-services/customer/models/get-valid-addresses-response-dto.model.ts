import { ValidaddressOption } from "./valid-address-option.model";

export interface GetValidaddressesResponseDto {
    message: string;
    code: string;
    errors: string[];
    addresses: ValidaddressOption[];
}
