export enum RequestQueryUserOrTeam {
    User = "user",
    Team = "team",
}
