import { SortOrder } from "../../../models/paging/sort-order.enum";
import { RequestQueryStage } from "./request-query-stage.enum";
import { RequestQueryUserOrTeam } from "./request-query-user-or-team.enum";

export interface RequestsQueryDto {
    companyId: number;
    ProjectID: number;
    scope: number | string;
    userOrTeam: RequestQueryUserOrTeam;
    stage: RequestQueryStage;
    pageSize: number;
    pageNumber: number;
    keyword: string;
    status: string;
    type: string;
    requestFrom: string;
    requestTo: string;
    sort: string;
    order: SortOrder;
}
