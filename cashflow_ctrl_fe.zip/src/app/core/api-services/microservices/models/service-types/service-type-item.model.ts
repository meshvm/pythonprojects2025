export interface ServiceTypeItem {
    carrierServiceId: number;
    carrierServiceName: string;
}
