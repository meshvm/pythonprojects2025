import { ServiceTypeItem } from "./service-type-item.model";

export interface GetServiceTypeItemsResponse {
    serviceTypes: ServiceTypeItem[];
}
