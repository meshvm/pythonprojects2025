import { addressItemDto } from "./address-item-dto.model";

export interface GetaddressListResponseDto {
    addresses: addressItemDto[];
    TotalItems: number;
}
