import { SafeHtml } from "@angular/platform-browser";

export interface MenuItem {
    iconFileName: string;
    iconName: string;
    MenuTitle: string;
    HasAccess: boolean;
    url: string;
    icon?: string | SafeHtml;
    imgLeapwork?: string;
    linkLeapwork?: string;
    name?: string;
}
