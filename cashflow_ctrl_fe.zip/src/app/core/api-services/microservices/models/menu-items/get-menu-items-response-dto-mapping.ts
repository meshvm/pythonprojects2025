import { GetMenuItemsResponseDto } from "./get-menu-items-response-dto.model";
import { GetMenuItemsResponse } from "./get-menu-items-response.model";
import { MenuItem } from "./menu-item.model";

export class GetMenuItemsResponseDtoMapping {
    public static mapToModel(
        dto: GetMenuItemsResponseDto
    ): GetMenuItemsResponse {
        return {
            menus: dto.Menus.map(
                (menuItemDto) =>
                    ({
                        iconFileName: menuItemDto.IconFileName,
                        iconName: menuItemDto.IconName,
                        HasAccess: menuItemDto.HasAccess,
                        url: menuItemDto.URL,
                    }) as MenuItem
            ),
        };
    }
}
