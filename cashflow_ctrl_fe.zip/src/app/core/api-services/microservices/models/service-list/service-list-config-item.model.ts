export interface ServiceListConfigItem {
    serviceName: string;
    numberOfProjects: number;
    serviceId: number;
    companyServiceId: number;
    IsActive: boolean;
    imageUrl: string;
    pageUrl: string;
    serviceCode: string;
}
