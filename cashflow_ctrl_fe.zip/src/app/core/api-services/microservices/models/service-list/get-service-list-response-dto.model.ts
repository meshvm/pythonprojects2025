import { ServiceListConfigItemDto } from "./service-list-config-item-dto.model";

export interface GetServiceListResponseDto {
    message: {
        Services: ServiceListConfigItemDto[];
    };
}
