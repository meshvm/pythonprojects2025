import { ServiceListConfigItem } from "./service-list-config-item.model";

export interface GetServiceListResponse {
    message: {
        services: ServiceListConfigItem[];
    };
}
