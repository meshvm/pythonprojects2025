export interface ServiceListConfigItemDto {
    ServiceName: string;
    NumberOfProjects: number;
    ServiceID: number;
    CompanyServiceID: number;
    IsActive: boolean;
    ImageUrl: string;
    PageUrl: string;
    ServiceCode: string;
}
