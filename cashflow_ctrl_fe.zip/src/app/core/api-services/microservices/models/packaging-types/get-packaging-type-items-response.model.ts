import { PackagingTypeItem } from "./packaging-type-item.model";

export interface GetPackagingTypeItemsResponse {
    packagingTypes: PackagingTypeItem[];
}
