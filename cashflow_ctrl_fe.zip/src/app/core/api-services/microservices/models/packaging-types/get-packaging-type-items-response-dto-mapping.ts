import { GetPackagingTypeItemsResponseDto } from "./get-packaging-type-items-response-dto.model";
import { GetPackagingTypeItemsResponse } from "./get-packaging-type-items-response.model";

export class GetPackagingTypeItemsResponseDtoMapping {
    public static mapToModel(
        dto: GetPackagingTypeItemsResponseDto
    ): GetPackagingTypeItemsResponse {
        return {
            packagingTypes: dto.PackagingTypes.map((dtoItem) => ({
                packagingTypeId: dtoItem.PackagingTypeID,
                packagingTypeName: dtoItem.PackagingTypeName,
            })),
        };
    }
}
