import { Dictionary } from "../../../../models/dictionary.model";

export interface GetUserResponse {
    companyId: number;
    FirstName: string;
    LastName: string;
    email: string;
    ServicePermissions: Dictionary<any>[];
}
