import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { environment } from "../../../../environments/environment";
import { Project } from "../../models/project.model";
import { ProjectsDto } from "./models/projects-dto.model";

@Injectable({ providedIn: "root" })
export class ProjectApiService {
    private readonly baseUrl: string;
    private projectsSubject: BehaviorSubject<ProjectsDto> =
        new BehaviorSubject<ProjectsDto>({ result: [] });
    public projects$: Observable<ProjectsDto> =
        this.projectsSubject.asObservable();

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = environment.CCURL;
    }

    public getCompanyShopServicePoints(): Observable<any> {
        return this.httpClient.get<any>(`${this.baseUrl}/v2/company/shop`);
    }

    public getProjects(companyId: string): Observable<ProjectsDto> {
        return this.httpClient
            .get<ProjectsDto>(
                `${this.baseUrl}/v1/projects?companyId=${companyId}`
            )
            .pipe(
                tap((projects: ProjectsDto) =>
                    this.projectsSubject.next(projects)
                )
            );
    }

    public createProject(project: Project): Observable<Project> {
        return this.httpClient.post<Project>(
            `${this.baseUrl}/v1/project`,
            project
        );
    }

    public getProject(ProjectID: number): Observable<Project> {
        return this.httpClient.get<Project>(
            `${this.baseUrl}/projects/` + ProjectID
        );
    }

    public editProject(
        ProjectID: number,
        project: Partial<Project>
    ): Observable<Project> {
        return this.httpClient.put<Project>(
            `${this.baseUrl}/v1/project/` + ProjectID,
            project
        );
    }

    public deleteProject(
        ProjectName: string,
        projectNumber: string,
        companyId: number
    ): Observable<void> {
        const url = `${this.baseUrl}/v1/company/${companyId}/project`;
        const body = {
            projectNumber: projectNumber,
            ProjectName: ProjectName,
        };

        return this.httpClient.delete<void>(url, { body });
    }
}
