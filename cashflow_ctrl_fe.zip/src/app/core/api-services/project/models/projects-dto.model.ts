import { Project } from "../../../models/project.model";

export interface ProjectsDto {
    result: Project[];
    totalItems?: number;
}
