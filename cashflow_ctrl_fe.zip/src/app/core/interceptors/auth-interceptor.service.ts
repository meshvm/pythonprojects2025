import { UserService } from "src/app/core/services/users.service";
import {
    HttpEvent,
    HttpHandler,
    HttpHeaders,
    HttpInterceptor,
    HttpRequest,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, from } from "rxjs";
import { filter, switchMap } from "rxjs/operators";
import { AuthService } from "../oidc/auth-oidc.service";
import { environment } from "src/environments/environment";
import { HttpClient } from "@angular/common/http";

@Injectable({ providedIn: "root" })
export class AuthInterceptor implements HttpInterceptor {
    private basicAuth: string | null = null;
    private externalClientValue: string | null;
    private CCURL = environment.CCURL;

    constructor(
        private authService: AuthService,
        private userService: UserService,
        private http: HttpClient
    ) {}

    public intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        let updatedRequest = request;

        // Check if the request URL contains placeholders for jobName or client
        // this is a workaround for the external client value
        // this logic should be removed once the external client value is available in the token
        if (
            request.url.includes("{jobName}") ||
            request.url.includes("{clientName}")
        ) {
            // Get the external client value
            // get basic auth token
            // any request to the mavro-experience-api should have the basic auth token and external client value before the request is made
            return this.userService.currentCompanyId.pipe(
                filter((companyId) => companyId !== 0),
                switchMap(() => this.getExternalClientValue()),
                switchMap((clientValue: string | null) => {
                    this.externalClientValue = clientValue;
                    if (request.url.includes("{jobName}")) {
                        updatedRequest = request.clone({
                            url: request.url.replace(
                                "{jobName}",
                                this.externalClientValue || ""
                            ),
                        });
                    }
                    if (request.url.includes("{clientName}")) {
                        // Transform the client value to match the expected format in the URL for reports APIs.
                        const transformedClientValue =
                            this.transformClientValue(
                                this.externalClientValue || ""
                            );
                        updatedRequest = request.clone({
                            url: request.url.replace(
                                "{clientName}",
                                transformedClientValue || ""
                            ),
                        });
                    }

                    // Continue with the rest of the logic
                    return this.handleRequest(updatedRequest, next);
                })
            );
        }

        // If no placeholder, continue with the rest of the logic
        return this.handleRequest(updatedRequest, next);
    }

    private handleRequest(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        // Check if the request is going to the mavro-experience-api and inject the basic auth token
        if (request.url.includes("mavro-experience-api")) {
            return this.getBasicAuthToken().pipe(
                switchMap((token) => {
                    let headers = new HttpHeaders();
                    headers = headers.set("Authorization", token);

                    const updatedRequest = request.clone({
                        url: request.url,
                        headers: headers,
                    });

                    return next.handle(updatedRequest);
                })
            );
        }

        // all other requests should have a valid access token from oauth systems.
        let headers = new HttpHeaders();
        headers = headers.set(
            "Authorization",
            `Bearer ${this.authService.accessToken}`
        );

        const updatedRequest = request.clone({
            url: request.url,
            headers: headers,
        });

        return next.handle(updatedRequest);
    }

    /**
     * Retrieves the Basic Authentication token.
     *
     * If the token is already available, it returns the token as an observable.
     * Otherwise, it makes an HTTP GET request to fetch the token from the server.
     *
     * @returns {Observable<string>} An observable that emits the Basic Authentication token.
     * @throws {Error} If the token retrieval fails.
     */
    private getBasicAuthToken(): Observable<string> {
        if (this.basicAuth) {
            return from(Promise.resolve(this.basicAuth));
        }
        return this.http
            .get<{ token: string }>(`${this.CCURL}/v2/mavro/basic-auth/`)
            .pipe(
                switchMap((response: any) => {
                    this.basicAuth = response.result.BasicAuth;
                    if (this.basicAuth) {
                        return from(Promise.resolve(this.basicAuth));
                    }
                    throw new Error("Failed to retrieve BasicAuth token");
                })
            );
    }

    /**
     * Retrieves the external client value.
     *
     * If the external client value is already available, it returns an observable
     * that resolves to the existing value. Otherwise, it fetches the value from
     * the server using the user ID and company ID, and then returns an observable
     * that resolves to the fetched value.
     *
     * @returns {Observable<string | null>} An observable that emits the external client value.
     */
    private getExternalClientValue(): Observable<string | null> {
        if (this.externalClientValue) {
            return from(Promise.resolve(this.externalClientValue));
        }

        const userID = this.authService.systemUserId;
        const companyId = this.userService.currentCompanyIdValue;
        return this.http
            .get<{ value: string }>(
                `${this.CCURL}/v2/company/${userID}/${companyId}/external-client/`
            )
            .pipe(
                switchMap((response: any) => {
                    this.externalClientValue =
                        response.result[0].ExternalClientID;
                    return from(Promise.resolve(this.externalClientValue));
                })
            );
    }

    /**
     * Transforms a given string by splitting it into words, capitalizing the first letter of each word,
     * and then joining the words back together without spaces.
     *
     * @param value - The input string to be transformed.
     * @returns The transformed string with the first letter of each word capitalized and concatenated.
     */
    private transformClientValue(value: string): string {
        return value
            .split(" ")
            .map((word) => word.charAt(0).toUpperCase())
            .join("");
    }
}
