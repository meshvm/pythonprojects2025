import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ChangeServiceAccessDialogComponent } from "./change-service-access.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ChangeServiceAccessDialogComponent],
    exports: [ChangeServiceAccessDialogComponent],
})
export class ChangeServiceAccessModule {}
