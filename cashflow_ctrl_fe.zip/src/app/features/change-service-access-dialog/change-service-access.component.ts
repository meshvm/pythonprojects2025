import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { ChangeServiceAccessConfig } from "./models/change-service-access-config.model";

@Component({
    selector: "cc-change-service-access",
    templateUrl: "./change-service-access.component.html",
    styleUrls: ["./change-service-access.component.scss"],
})
export class ChangeServiceAccessDialogComponent {
    public selectedRole: string;

    constructor(
        public dialogRef: MatDialogRef<ChangeServiceAccessDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: ChangeServiceAccessConfig
    ) {
        this.selectedRole = "";
    }

    public get usersNames(): string {
        return this.data.selectedUsers
            .map((e) => e?.FirstName + " " + e?.LastName)
            .join(", ");
    }

    public closeDialog(): void {
        this.dialogRef.close();
    }

    public onSave(): void {
        if (this.data.makeActive) {
            if (this.selectedRole !== "") {
                this.dialogRef.close({
                    users: this.data.selectedUsers,
                    HasAccess: true,
                    selectedRole: this.selectedRole,
                });
            } else if (
                this.data.selectedUsers.length === 1 &&
                (this.data.selectedUsers[0].ServiceRoleName === "" ||
                    !this.data.selectedUsers[0].ServiceRoleName)
            ) {
                return;
            } else {
                this.dialogRef.close({
                    users: this.data.selectedUsers,
                    HasAccess: true,
                    selectedRole: null,
                });
            }
        } else {
            this.dialogRef.close({
                users: this.data.selectedUsers,
                HasAccess: false,
                selectedRole: null,
            });
        }
    }
}
