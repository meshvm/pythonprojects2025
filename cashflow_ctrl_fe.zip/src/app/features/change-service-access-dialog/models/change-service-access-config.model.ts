import { LabeledValue } from "../../../core/models/labeled-value.model";
import { UserDetails } from "../../../core/models/user-details.model";

export interface ChangeServiceAccessConfig {
    selectedUsers: UserDetails[];
    makeActive: boolean;
    roles: LabeledValue[];
}
