import { Injectable } from "@angular/core";
import {
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from "@angular/forms";
import { EmailApiService } from "../../../core/api-services/email/email-api.service";
import { SupportRequestActionCode } from "../../../core/api-services/email/models/support-request/support-request-action-code.enum";
import { SupportRequest } from "../../../core/api-services/email/models/support-request/support-request.model";
import { LoaderService } from "../../../core/services/loader.service";
import { NotificationService } from "../../../core/services/notification.service";

@Injectable()
export class SendMessageDialogService {
    constructor(
        private formBuilder: FormBuilder,
        private loaderService: LoaderService,
        private emailApiService: EmailApiService,
        private notificationService: NotificationService
    ) {}

    public buildForm(requestCall?: boolean): FormGroup {
        const form = this.formBuilder.group({
            requestTypeId: [null, Validators.required],
            requestDescription: [
                null,
                [Validators.required, Validators.maxLength(80)],
            ],
            additionalDetails: [null, Validators.maxLength(250)],
        });

        if (requestCall) {
            form.addControl(
                "phoneNumber" as any,
                new FormControl(null, Validators.required)
            );
        }

        return form;
    }

    public mapToModel(form: FormGroup): SupportRequest {
        const {
            additionalDetails,
            requestDescription,
            requestTypeId,
            phoneNumber,
        } = form.value;

        const model = {
            isToCallSupport: !!phoneNumber,
            requestTypeId,
            requestDescription,
            additionalDetails,
        } as SupportRequest;

        if (phoneNumber) {
            model.phoneNumber = phoneNumber;
        }

        return model;
    }

    public async saveSupportRequest(saveModel: SupportRequest): Promise<void> {
        this.loaderService.setLoading(true);

        try {
            await this.emailApiService.createSupportRequest(saveModel);
            this.notificationService.showSuccessMsg(
                "Your message was successfully sent."
            );
        } catch (error: any) {
            this.notificationService.showErrorMsg(error);
        }

        this.loaderService.setLoading(false);
    }
}
