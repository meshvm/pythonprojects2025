import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { SendMessageDialogComponent } from "./send-message-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [SendMessageDialogComponent],
    exports: [SendMessageDialogComponent],
})
export class SendMessageDialogModule {}
