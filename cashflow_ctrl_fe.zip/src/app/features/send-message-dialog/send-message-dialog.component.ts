import { Component, Inject } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { LabeledValue } from "../../core/models/labeled-value.model";
import { SendMessageDialogConfig } from "./models/send-message-dialog-config.model";
import { SendMessageDialogService } from "./services/send-message-dialog.service";
import { EmailApiService } from "../../core/api-services/email/email-api.service";

@Component({
    selector: "cc-send-message-dialog",
    templateUrl: "./send-message-dialog.component.html",
    styleUrls: ["./send-message-dialog.component.scss"],
    providers: [SendMessageDialogService],
})
export class SendMessageDialogComponent implements SendMessageDialogConfig {
    public requestTypeOptions: LabeledValue[];

    public form: FormGroup;
    public requestCall: boolean;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: SendMessageDialogConfig,
        private dialogRef: MatDialogRef<SendMessageDialogComponent>,
        private sendMessageDialogService: SendMessageDialogService,
        private emailApiService: EmailApiService
    ) {
        this.emailApiService.getSupportRequestTypes().then((response) => {
            const requestTypeOptions = response.map((x: any) => ({
                label: x.name,
                value: x.id,
            }));
            this.requestTypeOptions = requestTypeOptions;
        });
        this.requestCall = this.data.requestCall;

        this.initForm();
    }

    public closeDialog(): void {
        this.dialogRef.close();
    }

    public getLength(field: string): number {
        return this.form.get(field)?.value?.length || 0;
    }

    public async submitForm(): Promise<void> {
        this.form.markAllAsTouched();

        if (this.form.invalid) {
            return;
        }

        const saveModel = this.sendMessageDialogService.mapToModel(this.form);

        await this.sendMessageDialogService.saveSupportRequest(saveModel);
        this.closeDialog();
    }

    private initForm(): void {
        this.form = this.sendMessageDialogService.buildForm(this.requestCall);
    }
}
