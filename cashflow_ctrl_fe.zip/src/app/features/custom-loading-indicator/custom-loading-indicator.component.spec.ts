import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CustomLoadingIndicatorComponent } from "./custom-loading-indicator.component";

@NgModule({
    declarations: [CustomLoadingIndicatorComponent],
    imports: [CommonModule],
})
class TestModule {}

describe("CustomLoadingIndicatorComponent", () => {
    let component: CustomLoadingIndicatorComponent;
    let fixture: ComponentFixture<CustomLoadingIndicatorComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [TestModule],
        });
        fixture = TestBed.createComponent(CustomLoadingIndicatorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
