import { TestBed } from "@angular/core/testing";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { WorkQueueActionModalManagerService } from "./work-queue-action-modal-manager.service";
import { WorkQueueActionModalConfig } from "../models/work-queue-action-modal-config.model";
import { WorkQueueReturnCheckActionModalConfig } from "../models/work-queue-return-check-action-modal-config.model";
import { WorkQueueReturnCheckaddressModalConfig } from "../models/work-queue-return-check-address-modal-config.model";
import { WorkQueueReturnCheckValidateaddressModalConfig } from "../models/work-queue-return-check-validate-address-modal-config.model";
import { WorkQueueExportRecordsModalConfig } from "../models/work-queue-export-records-modal-config.model";
import { WorkQueueActionModalComponent } from "../work-queue-action-modal.component";
import { ReturnCheckModalComponent } from "../../work-queue/return-check-modal/return-check-modal.component";
import { ReturnCheckaddressModalComponent } from "../../work-queue/return-check-address-modal/return-check-address-modal.component";
import { ReturnCheckValidateaddressModalComponent } from "../../work-queue/return-check-validate-address-modal/return-check-validate-address-modal.component";
import { ExportRecordsModalComponent } from "../../work-queue/export-records-modal/export-records-modal.component";

describe("WorkQueueActionModalManagerService", () => {
    let service: WorkQueueActionModalManagerService;
    let modalServiceMock: jasmine.SpyObj<ModalService>;

    beforeEach(() => {
        modalServiceMock = jasmine.createSpyObj("ModalService", ["openModal"]);

        TestBed.configureTestingModule({
            providers: [
                WorkQueueActionModalManagerService,
                { provide: ModalService, useValue: modalServiceMock },
            ],
        });

        service = TestBed.inject(WorkQueueActionModalManagerService);
    });

    it("should be created", () => {
        expect(service).toBeTruthy();
    });

    it("should open a support request modal with specific configuration", () => {
        service.openSupportRequestModal({
            submitButtonText: "Submit",
            checksSelectedCount: 1,
            title: "Title",
            text: "Text",
            submitCallback: () => {},
        } as WorkQueueActionModalConfig);

        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            WorkQueueActionModalComponent,
            undefined,
            jasmine.objectContaining({
                width: "500px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });

    it("should open a return check modal with specific configuration", () => {
        service.openReturnCheckModal({
            submitButtonText: "Submit",
            checksSelectedCount: 1,
            title: "Title",
            text: "Text",
            submitCallback: () => {},
            deleteCallback: () => {},
            enterNewaddressCallback: () => {},
            editaddressCallback: () => {},
        } as WorkQueueReturnCheckActionModalConfig);

        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            ReturnCheckModalComponent,
            undefined,
            jasmine.objectContaining({
                width: "710px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });

    it("should open a return check address modal with specific configuration", () => {
        service.openReturnCheckaddressModal({
            isEditing: false,
            isValidated: false,
            checksSelectedCount: 1,
            submitCallback: () => {},
            closeCallback: () => {},
            saveCallback: () => {},
        } as WorkQueueReturnCheckaddressModalConfig);

        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            ReturnCheckaddressModalComponent,
            undefined,
            jasmine.objectContaining({
                width: "710px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });

    it("should open a validate address modal with specific configuration", () => {
        service.openValidateaddressModal({
            checksSelectedCount: 1,
            submitCallback: () => {},
            closeCallback: () => {},
            address: {
                name: "test",
                address: {
                    line1: "test",
                    line2: "test",
                    city: "test",
                    state: "test",
                    postalCode: "test",
                },
            },
        } as WorkQueueReturnCheckValidateaddressModalConfig);

        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            ReturnCheckValidateaddressModalComponent,
            undefined,
            jasmine.objectContaining({
                width: "500px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });

    it("should open a export modal with specific configuration", () => {
        service.openExportModal({
            checksSelectedCount: 1,
            submitCallback: () => {},
            closeCallback: () => {},
        } as WorkQueueExportRecordsModalConfig);

        expect(modalServiceMock.openModal).toHaveBeenCalledWith(
            ExportRecordsModalComponent,
            undefined,
            jasmine.objectContaining({
                width: "500px",
                contentStyle: { overflow: "auto" },
                baseZIndex: 0,
                showHeader: false,
            }),
            jasmine.any(Object)
        );
    });
});
