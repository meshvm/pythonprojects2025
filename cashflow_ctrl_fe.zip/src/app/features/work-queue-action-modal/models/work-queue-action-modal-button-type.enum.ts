export enum WorkQueueActionModalButtonType {
    Submit = "Submit",
    Delete = "Delete",
}
