import { ReturnCheckaddressItem } from "../../work-queue/return-check-modal/models/return-check-address-item.model";
import { WorkQueueActionModalButtonType } from "./work-queue-action-modal-button-type.enum";

export interface WorkQueueActionModalConfig {
    title: string;
    text: string;
    checksSelectedCount: number;
    submitButtonText: string;
    submitCallback: (count: number, filename: string) => void;
    closeCallback?: (count?: number) => void;
    deleteCallback?: (address: ReturnCheckaddressItem) => void;
    buttonType?: WorkQueueActionModalButtonType;
    address?: ReturnCheckaddressItem;
}
