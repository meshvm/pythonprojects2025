import { ReturnCheckaddressItem } from "../../work-queue/return-check-modal/models/return-check-address-item.model";

export interface WorkQueueReturnCheckActionModalConfig {
    title: string;
    text: string;
    checksSelectedCount: number;
    submitButtonText: string;
    submitCallback: (address: ReturnCheckaddressItem) => void;
    deleteCallback: (address: ReturnCheckaddressItem, count: number) => void;
    enterNewaddressCallback: (count: number) => void;
    editaddressCallback: (
        address: ReturnCheckaddressItem,
        count: number
    ) => void;
}
