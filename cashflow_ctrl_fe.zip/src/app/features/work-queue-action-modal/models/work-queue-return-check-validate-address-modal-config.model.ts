import { ReturnCheckaddressItem } from "../../work-queue/return-check-modal/models/return-check-address-item.model";

export interface WorkQueueReturnCheckValidateaddressModalConfig {
    checksSelectedCount: number;
    submitCallback: (count: number, address: ReturnCheckaddressItem) => void;
    closeCallback?: (count: number, address: ReturnCheckaddressItem) => void;
    address: ReturnCheckaddressItem;
}
