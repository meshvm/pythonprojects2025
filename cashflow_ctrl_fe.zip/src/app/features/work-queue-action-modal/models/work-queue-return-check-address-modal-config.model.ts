import { ReturnCheckaddressItem } from "../../work-queue/return-check-modal/models/return-check-address-item.model";

export interface WorkQueueReturnCheckaddressModalConfig {
    isEditing: boolean;
    isValidated: boolean;
    checksSelectedCount: number;
    submitCallback: (count: number, address: ReturnCheckaddressItem) => void;
    closeCallback?: (count?: number) => void;
    saveCallback: () => void;
    address?: ReturnCheckaddressItem;
}
