import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ProjectEditorComponent } from "./project-editor.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ProjectEditorComponent],
    exports: [ProjectEditorComponent],
})
export class ProjectEditorModule {}
