import { Component, Input } from "@angular/core";
import { PurchaseOrderStateProperties } from "../../core/state-services/purchase-order/models/purchase-order-state-properties.enum";
import { PurchaseOrderStateService } from "../../core/state-services/purchase-order/purchase-order-state.service";

@Component({
    selector: "cc-request-purchase-order-required-message",
    templateUrl: "request-purchase-order-required-message.component.html",
    styleUrls: ["request-purchase-order-required-message.component.scss"],
})
export class RequestPurchaseOrderRequiredMessageComponent {
    @Input()
    public billingAmount: number;

    public threshold: number;
    public usePurchaseOrder: boolean;

    constructor(private purchaseOrderStateService: PurchaseOrderStateService) {
        this.loadPurchaseOrderConfigs();
    }

    private async loadPurchaseOrderConfigs(): Promise<void> {
        this.threshold = await this.purchaseOrderStateService.getStateValue(
            PurchaseOrderStateProperties.Threshold
        );
        this.usePurchaseOrder =
            await this.purchaseOrderStateService.getStateValue(
                PurchaseOrderStateProperties.UsePurchaseOrders
            );
    }
}
