import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RecordDetailPaginatorComponent } from "./record-detail-paginator.component";
import { PadStringPipe } from "./pipes/pad-string.pipe";

@NgModule({
    imports: [SharedModule],
    declarations: [RecordDetailPaginatorComponent, PadStringPipe],
    exports: [RecordDetailPaginatorComponent, PadStringPipe],
})
export class RecordDetailPaginatorModule {}
