import { Pipe } from "@angular/core";

@Pipe({
    name: "padString",
})
export class PadStringPipe {
    public transform(str: number, length: number = 2): string {
        return `${str}`.padStart(length, "0");
    }
}
