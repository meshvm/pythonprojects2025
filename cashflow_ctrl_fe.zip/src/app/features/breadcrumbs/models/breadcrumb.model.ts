export class BreadcrumbModel {
    label: string;
    url: string;
    isUrlAbsolute?: boolean;
}
