import { Injectable } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { RequestInterface } from "../../../core/models/request.model";
import { LoaderService } from "../../../core/services/loader.service";
import { PurchaseOrderStateProperties } from "../../../core/state-services/purchase-order/models/purchase-order-state-properties.enum";
import { PurchaseOrderStateService } from "../../../core/state-services/purchase-order/purchase-order-state.service";
import { PurchaseOrderUploadConfig } from "../models/purchase-order-upload-config.model";
import { PurchaseOrderUploadComponent } from "../purchase-order-upload.component";

@Injectable({
    providedIn: "root",
})
export class PurchaseOrderModalService {
    private purchaseOrderThreshold: number;
    private usePurchaseOrder: boolean;

    constructor(
        private matDialog: MatDialog,
        private purchaseOrderStateService: PurchaseOrderStateService,
        private loaderService: LoaderService
    ) {}

    public attachPurchaseOrderIfNeeded(
        requests: RequestInterface[],
        billingAmount?: number
    ): Promise<RequestInterface[] | null> {
        return new Promise(async (res) => {
            await this.loadPurchaseOrderConfigs();

            const requestsOverLimit = requests.filter(
                (request) =>
                    (billingAmount || request?.billing?.totalBillingAmount) >=
                    this.purchaseOrderThreshold
            );

            const requestsUnderLimit = requests.filter(
                (request) =>
                    (billingAmount || request?.billing?.totalBillingAmount) <
                    this.purchaseOrderThreshold
            );

            if (!this.usePurchaseOrder || !requestsOverLimit?.length) {
                res(requests);
                return;
            }

            this.matDialog.open(PurchaseOrderUploadComponent, {
                disableClose: true,
                data: {
                    requests: requestsOverLimit,
                    onPurchaseOrdersAttached: (map) => {
                        res([
                            ...requestsUnderLimit,
                            ...this.getUpdatedRequestsWithPurchaseOrders(
                                map,
                                requestsOverLimit
                            ),
                        ]);
                    },
                    onCancel: () => {
                        res(null);
                    },
                } as PurchaseOrderUploadConfig,
            });
        });
    }

    private async loadPurchaseOrderConfigs(): Promise<void> {
        this.loaderService.setLoading(true);

        this.purchaseOrderThreshold =
            await this.purchaseOrderStateService.getStateValue<number>(
                PurchaseOrderStateProperties.Threshold
            );
        this.usePurchaseOrder =
            await this.purchaseOrderStateService.getStateValue<boolean>(
                PurchaseOrderStateProperties.UsePurchaseOrders
            );

        this.loaderService.setLoading(false);
    }

    private getUpdatedRequestsWithPurchaseOrders(
        map: Map<number, string>,
        requests: RequestInterface[]
    ): RequestInterface[] {
        return requests.map((request) => ({
            ...request,
            purchaseOrderFileName: map.get(request.requestId) as string,
        }));
    }
}
