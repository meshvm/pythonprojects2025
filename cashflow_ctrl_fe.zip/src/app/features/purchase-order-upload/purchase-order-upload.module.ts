import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { PurchaseOrderUploadComponent } from "./purchase-order-upload.component";

@NgModule({
    imports: [SharedModule],
    declarations: [PurchaseOrderUploadComponent],
    exports: [PurchaseOrderUploadComponent],
})
export class PurchaseOrderUploadModule {}
