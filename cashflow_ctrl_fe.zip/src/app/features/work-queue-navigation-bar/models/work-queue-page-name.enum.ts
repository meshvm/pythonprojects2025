export enum WorkQueuePageName {
    All = "All",
    Exceptions = "Exceptions",
    PendingApproval = "Pending Approval",
    OnHold = "On Hold",
    Archive = "Archive",
}
