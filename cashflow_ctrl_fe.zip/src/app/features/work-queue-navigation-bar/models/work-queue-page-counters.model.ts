import { WorkQueuePageName } from "./work-queue-page-name.enum";

export interface WorkQueuePageCounters {
    [WorkQueuePageName.All]: number;
    [WorkQueuePageName.Archive]: number;
    [WorkQueuePageName.OnHold]: number;
    [WorkQueuePageName.PendingApproval]: number;
    [WorkQueuePageName.Exceptions]: number;
}
