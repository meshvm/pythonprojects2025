import { Pipe } from "@angular/core";
import { MenuItem } from "primeng/api";
import { WorkQueuePageCounters } from "../models/work-queue-page-counters.model";
import { WorkQueuePageName } from "../models/work-queue-page-name.enum";

@Pipe({
    name: "workQueueNavigationExtractCounter",
})
export class WorkQueueNavigationExtractCounterPipe {
    public transform(counters: WorkQueuePageCounters, value: MenuItem): number {
        return counters[value.title as WorkQueuePageName];
    }
}
