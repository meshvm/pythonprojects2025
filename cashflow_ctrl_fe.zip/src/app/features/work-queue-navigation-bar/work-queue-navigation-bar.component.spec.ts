import { ComponentFixture, TestBed } from "@angular/core/testing";
import { Router } from "@angular/router";

import { WorkQueueNavigationBarComponent } from "./work-queue-navigation-bar.component";
import { UnitTestsHelper } from "../../shared/helpers/unit-tests/unit-tests-helper";

describe("ReportsNavigationBarComponent", () => {
    let component: WorkQueueNavigationBarComponent;
    let fixture: ComponentFixture<WorkQueueNavigationBarComponent>;
    const routerMock = UnitTestsHelper.createRouterMock();

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [WorkQueueNavigationBarComponent],
            providers: [{ provide: Router, useValue: routerMock }],
        });
        fixture = TestBed.createComponent(WorkQueueNavigationBarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should navigate to work queue routerlink", () => {
        component.onActiveItemChange({
            routerLink: "/work-queue",
        });
        expect(routerMock.navigate).toHaveBeenCalled();
    });
});
