import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { MicroservicesApiService } from "src/app/core/api-services/microservices/microservices-api.service";
import { LoaderService } from "src/app/core/services/loader.service";
import { GetTestDataService } from "src/app/get-test-data.service";
import { GetServiceListResponse } from "../../core/api-services/microservices/models/service-list/get-service-list-response.model";
import { ServiceListConfigItem } from "../../core/api-services/microservices/models/service-list/service-list-config-item.model";
import { DatabaseConfigurationsHelper } from "./helpers/database-configurations-helper";

@Component({
    selector: "cc-database-configurations",
    templateUrl: "./database-configurations.component.html",
    styleUrls: ["./database-configurations.component.scss"],
})
export class DatabaseConfigurationComponent {
    public readonly tabTitles: string[];

    public configurationItems: ServiceListConfigItem[];

    constructor(
        private getTestDataService: GetTestDataService,
        private microservicesApiService: MicroservicesApiService,
        private activatedRoute: ActivatedRoute,
        private loadingService: LoaderService
    ) {
        this.tabTitles = DatabaseConfigurationsHelper.defaultTabTitles;
        this.configurationItems = [];

        this.loadServiceList();
    }

    public onEnabledToggle(item: any, enable: boolean) {
        this.loadingService.setLoading(true);

        const companyId = parseInt(
            this.activatedRoute.snapshot.paramMap.get("CustomerID") || "0",
            10
        );

        this.microservicesApiService
            .enableDisableService(companyId, item.serviceId, enable)
            .subscribe(
                () => {
                    this.loadingService.setLoading(false);
                },
                () => {
                    this.loadingService.setLoading(false);
                },
                () => {
                    this.loadingService.setLoading(false);
                }
            );
    }

    private loadServiceList(): void {
        const companyId = parseInt(
            this.activatedRoute.snapshot.paramMap.get("CustomerID") || "0",
            10
        );
        this.microservicesApiService.getServiceList(companyId).subscribe(
            (data: GetServiceListResponse) => {
                this.configurationItems = data?.message?.services || [];
            },
            () => {
                this.getTestDataService.main().subscribe((data: any) => {
                    this.configurationItems = data.customerDbconfigItems;
                });
            }
        );
    }
}
