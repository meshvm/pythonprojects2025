export class DatabaseConfigurationsHelper {
    public static readonly defaultTabTitles = [
        "Services Library",
        "Customer Admin",
        "address",
        "Users",
        "Departments",
        "Teams",
    ];
}
