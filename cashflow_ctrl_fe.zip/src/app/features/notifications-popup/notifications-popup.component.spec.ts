import { ComponentFixture, TestBed } from "@angular/core/testing";
import { NotificationsPopupComponent } from "./notifications-popup.component";

describe("NotificationsPopupComponent", () => {
    let component: NotificationsPopupComponent;
    let fixture: ComponentFixture<NotificationsPopupComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [NotificationsPopupComponent],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(NotificationsPopupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    it("should emit ready event with NotificationsPopupApi on init", () => {
        spyOn(component.ready, "emit");
        component.ngOnInit();
        expect(component.ready.emit).toHaveBeenCalled();
    });

    it("should close popup on window scroll when visible", () => {
        component.visible = true;
        component.onScroll();
        expect(component.visible).toBeFalsy();
    });

    it("should not close popup on window scroll when not visible", () => {
        component.visible = false;
        component.onScroll();
        expect(component.visible).toBeFalsy();
    });

    it("should stop propagation of mouse events", () => {
        const event = new MouseEvent("click");
        spyOn(event, "stopPropagation");
        component.stopPropagation(event);
        expect(event.stopPropagation).toHaveBeenCalled();
    });
});
