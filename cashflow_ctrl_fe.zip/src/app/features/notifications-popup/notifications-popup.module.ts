import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SvgIconComponent } from "angular-svg-icon";
import { NotificationsPopupComponent } from "./notifications-popup.component";

@NgModule({
    imports: [CommonModule, SvgIconComponent],
    declarations: [NotificationsPopupComponent],
    exports: [NotificationsPopupComponent],
})
export class NotificationsPopupModule {}
