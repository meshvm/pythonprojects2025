import {
    Component,
    EventEmitter,
    HostListener,
    OnInit,
    Output,
} from "@angular/core";
import { NotificationsPopupApi } from "./models/notifications-popup-api.model";

@Component({
    selector: "cc-notifications-popup",
    templateUrl: "./notifications-popup.component.html",
    styleUrls: ["./notifications-popup.component.scss"],
})
export class NotificationsPopupComponent implements OnInit {
    @Output()
    public ready: EventEmitter<NotificationsPopupApi>;

    public visible: boolean;

    @HostListener("window:wheel", ["$event"])
    public onScroll(): void {
        if (this.visible) {
            this.close();
        }
    }

    constructor() {
        this.ready = new EventEmitter<NotificationsPopupApi>();
    }

    public ngOnInit(): void {
        this.ready.emit({
            open: this.open.bind(this),
        });
    }

    public close(): void {
        this.visible = false;
    }

    public stopPropagation(event: MouseEvent): void {
        event.stopPropagation();
    }

    private open(): void {
        this.visible = true;
    }
}
