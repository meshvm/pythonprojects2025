import {
    Component,
    Input,
    Output,
    EventEmitter,
    ViewEncapsulation,
} from "@angular/core";
import { WorkQueueStatus } from "../../shared/models/work-queues/work-queue-status.enum";

@Component({
    selector: "cc-record-detail-deposit-status",
    templateUrl: "./record-detail-deposit-status.component.html",
    styleUrls: ["./record-detail-deposit-status.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class RecordDetailDepositStatusComponent {
    @Input()
    public status: string;
    @Input()
    public exceptions: { code: number; description: string }[];
    @Input()
    public time: string;
    @Input()
    public dispositionCodes: string[] = [
        "Return with Letter",
        "Return without Letter",
    ];

    public selectedDispositionCode: string;
    public workQueueStatuses: typeof WorkQueueStatus;

    constructor() {
        this.workQueueStatuses = WorkQueueStatus;
    }
}
