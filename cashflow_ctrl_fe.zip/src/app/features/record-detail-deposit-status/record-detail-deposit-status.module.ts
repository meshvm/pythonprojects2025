import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RecordDetailNotesHistoryModule } from "../record-detail-notes-history/record-detail-notes-history.module";
import { RecordDetailDepositStatusComponent } from "./record-detail-deposit-status.component";

@NgModule({
    imports: [SharedModule, RecordDetailNotesHistoryModule],
    declarations: [RecordDetailDepositStatusComponent],
    exports: [RecordDetailDepositStatusComponent],
})
export class RecordDetailDepositStatusModule {}
