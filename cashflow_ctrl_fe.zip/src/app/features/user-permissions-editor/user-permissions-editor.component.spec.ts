// import { ComponentFixture, TestBed } from "@angular/core/testing";
// import { UserPermissionsEditorComponent } from "./user-permissions-editor.component";
// import { MatDialogModule } from "@angular/material/dialog";
// import { UserPermissionApiService } from "src/app/core/api-services/user-permission/user-permission-api.service";
// import { HttpClientModule } from "@angular/common/http";
// import { ActivatedRoute } from "@angular/router";
// import { of } from "rxjs";
// import { MatSnackBarModule } from "@angular/material/snack-bar";
// import { Component, Output, EventEmitter } from "@angular/core";

// @Component({
//     selector: "cc-child-component",
//     template: ""
// })
// class MockChildComponent {
//     @Output() sortChange = new EventEmitter<void>();
// }

// describe("UserPermissionsEditorComponent", () => {
//     let component: UserPermissionsEditorComponent;
//     let fixture: ComponentFixture<UserPermissionsEditorComponent>;

//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             declarations: [UserPermissionsEditorComponent, MockChildComponent],
//             imports: [MatDialogModule, HttpClientModule, MatSnackBarModule],
//             providers: [
//                 UserPermissionApiService,
//                 {
//                     provide: ActivatedRoute,
//                     useValue: {
//                         snapshot: {
//                             paramMap: {
//                                 get: () => "mockValue"
//                             }
//                         },
//                         queryParams: of({}),
//                         params: of({})
//                     }
//                 }
//             ]
//         });
//         fixture = TestBed.createComponent(UserPermissionsEditorComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();
//     });

//     it("should create", () => {
//         expect(component).toBeTruthy();
//     });
// });
