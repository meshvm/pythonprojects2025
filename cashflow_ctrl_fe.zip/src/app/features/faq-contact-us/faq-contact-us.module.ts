import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { FaqSupportRequestModule } from "../faq-support-request/faq-support-request.module";
import { FaqContactUsComponent } from "./faq-contact-us.component";

@NgModule({
    imports: [SharedModule, FaqSupportRequestModule],
    declarations: [FaqContactUsComponent],
    exports: [FaqContactUsComponent],
})
export class FaqContactUsModule {}
