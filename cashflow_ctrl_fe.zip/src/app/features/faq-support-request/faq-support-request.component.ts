import { Component, ViewEncapsulation } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ToastrService } from "../../shared/components/toastr/services/toastr.service";
import { NamedValue } from "../../shared/models/base/named-value.model";
import { FaqSupportRequestTypeHelper } from "./helpers/faq-support-request-type-helper";
import { FaqSupportRequestType } from "./models/faq-support-request-type.enum";
import { FaqSupportRequestService } from "./services/faq-support-request.service";

@Component({
    selector: "cc-faq-support-request",
    templateUrl: "./faq-support-request.component.html",
    styleUrls: ["./faq-support-request.component.scss"],
    encapsulation: ViewEncapsulation.None,
    providers: [FaqSupportRequestService],
})
export class FaqSupportRequestComponent {
    public onCancel: () => void;

    public readonly form: FormGroup;
    public readonly requestTypeOptions: NamedValue<FaqSupportRequestType>[];

    public formSubmitted: boolean;

    constructor(
        private faqSupportRequestService: FaqSupportRequestService,
        private toastrService: ToastrService
    ) {
        this.form = this.faqSupportRequestService.buildForm();
        this.requestTypeOptions =
            FaqSupportRequestTypeHelper.getRequestTypeOptions();
    }

    public onSubmit(): void {
        this.form.markAllAsTouched();
        this.formSubmitted = true;

        if (!this.form.valid) {
            return;
        }

        this.toastrService.showSuccessMessage(
            "Request submitted successfully!"
        );

        this.onCancel();
    }
}
