import { Injectable } from "@angular/core";
import { DynamicDialogRef } from "primeng/dynamicdialog";
import { ModalService } from "../../../shared/components/modal/services/modal.service";
import { FaqSupportRequestComponent } from "../faq-support-request.component";

@Injectable({
    providedIn: "root",
})
export class FaqSupportRequestManagerService {
    constructor(private modalService: ModalService) {}

    public openSupportRequestModal(): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<FaqSupportRequestComponent>(
                FaqSupportRequestComponent,
                "Support Request",
                {
                    width: "500px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                } as Partial<FaqSupportRequestComponent>
            );
    }

    public openRequestCallModal(): void {
        const ref: DynamicDialogRef =
            this.modalService.openModal<FaqSupportRequestComponent>(
                FaqSupportRequestComponent,
                "Ask for a Call Back",
                {
                    width: "500px",
                    contentStyle: { overflow: "auto" },
                    baseZIndex: 0,
                    showHeader: false,
                },
                {
                    onCancel: () => ref.close(),
                } as Partial<FaqSupportRequestComponent>
            );
    }
}
