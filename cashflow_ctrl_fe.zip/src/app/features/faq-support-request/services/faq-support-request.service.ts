import { Injectable } from "@angular/core";
import {
    FormBuilder,
    FormControl,
    FormGroup,
    Validators,
} from "@angular/forms";
import { FaqSupportRequestType } from "../models/faq-support-request-type.enum";

@Injectable()
export class FaqSupportRequestService {
    constructor(private formBuilder: FormBuilder) {}

    public buildForm(): FormGroup {
        return this.formBuilder.group({
            requestTypeId: new FormControl<FaqSupportRequestType | null>(
                null,
                Validators.required
            ),
            requestDescription: new FormControl<string | null>(null, [
                Validators.required,
                Validators.maxLength(80),
            ]),
            phoneNumber: new FormControl<string | null>(null, [
                Validators.required,
            ]),
            additionalDetails: new FormControl<string | null>(
                null,
                Validators.maxLength(250)
            ),
        });
    }
}
