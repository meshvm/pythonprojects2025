import { Component, Input } from "@angular/core";
import getRequestStatusColor from "src/app/core/utils/getRequestStatusColor";

@Component({
    selector: "cc-customer-request-status",
    templateUrl: "./customer-request-status.component.html",
    styleUrls: ["./customer-request-status.component.scss"],
})
export class CustomerRequestStatusComponent {
    @Input()
    public status: string;

    public getStatusColor(): string {
        return getRequestStatusColor(this.status);
    }
}
