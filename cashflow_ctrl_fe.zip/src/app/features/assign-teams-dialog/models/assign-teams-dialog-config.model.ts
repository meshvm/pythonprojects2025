import { UserTeam } from "../../../core/api-services/user-permission/models/teams/user-team.model";
import { UserDetails } from "../../../core/models/user-details.model";

export interface AssignTeamsDialogConfig {
    selectedUsers: UserDetails[];
    teams: UserTeam[];
}
