import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { UserTeam } from "../../core/api-services/user-permission/models/teams/user-team.model";
import { AssignTeamsDialogConfig } from "./models/assign-teams-dialog-config.model";

@Component({
    selector: "cc-assign-teams-dialog",
    templateUrl: "./assign-teams-dialog.component.html",
    styleUrls: ["./assign-teams-dialog.component.scss"],
})
export class AssignTeamsDialogComponent {
    public selectedTeams: UserTeam[];
    public teamsOptions: string[];
    public selectedTeamsString: string[];

    constructor(
        public dialogRef: MatDialogRef<AssignTeamsDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: AssignTeamsDialogConfig
    ) {
        this.selectedTeams = [];
        this.teamsOptions = [];
        this.selectedTeamsString = [];

        this.teamsOptions = this.data.teams.map(
            (team: UserTeam) => team.team || team.TeamName || "TeamLabelError"
        );
        this.updateSelectedUsersAndTeams();
    }

    public closeDialog(): void {
        this.dialogRef.close();
    }

    public onSave(): void {
        if (this.selectedTeamsString.length > 0) {
            this.data.teams = this.data.teams.filter((team: any) => {
                return this.selectedTeamsString.includes(team.team);
            });
        }
        this.dialogRef.close(this.data);
    }

    private updateSelectedUsersAndTeams(): void {
        const allTeams: any[] = [];
        const alTeamsSet = new Set();

        this.data.selectedUsers.forEach((selectedUser) => {
            allTeams.push(selectedUser.Teams);
        });

        this.selectedTeams = allTeams.flat()?.filter((item) => {
            const duplicate = alTeamsSet.has(item?.teamId);
            alTeamsSet.add(item?.teamId);
            return !duplicate;
        });

        this.selectedTeamsString = this.selectedTeams.map(
            (team: UserTeam) => team?.team || team?.TeamName || "TeamLabelError"
        );
    }
}
