import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { NavigationBarComponent } from "./navigation-bar.component";
import { TabMenuModule } from "primeng/tabmenu";

@NgModule({
    imports: [SharedModule, TabMenuModule],
    declarations: [NavigationBarComponent],
    exports: [NavigationBarComponent],
})
export class NavigationBarModule {}
