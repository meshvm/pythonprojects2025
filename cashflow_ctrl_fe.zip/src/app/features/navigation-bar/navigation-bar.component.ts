import { ActivatedRoute } from "@angular/router";
/* eslint-disable @typescript-eslint/member-ordering */
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { MenuItem } from "primeng/api";
import { SendMessageDialogComponent } from "../send-message-dialog/send-message-dialog.component";
import { MatDialog } from "@angular/material/dialog";
import { UserService } from "src/app/core/services/users.service";
import { UserRole } from "src/app/shared/models/users/user-roles.enum";

@Component({
    selector: "cc-navigation-bar",
    templateUrl: "./navigation-bar.component.html",
    styleUrls: ["./navigation-bar.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class NavigationBarComponent implements OnInit {
    public items: MenuItem[] | undefined;
    public activeItem: MenuItem;
    public companyId: number;
    public shouldDisable: boolean;

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private dialog: MatDialog,
        private userService: UserService
    ) {
        this.companyId = parseInt(
            this.activatedRoute.snapshot.paramMap.get("CustomerID") || "0",
            10
        );
        if (this.companyId) {
            this.userService.setCompanyId(this.companyId);
        } else {
            this.userService.currentCompanyId.subscribe((companyId: number) => {
                if (!companyId) {
                    return;
                }
                this.companyId = companyId;
                this.loadNavItems();
            });
        }

        this.userService.currentUserRole.subscribe((role) => {
            this.shouldDisable =
                role === UserRole.executive || role === UserRole.manager;
        });
    }

    ngOnInit() {
        if (this.companyId) {
            this.loadNavItems();
        }
    }

    private loadNavItems() {
        this.items = [
            {
                title: "Work Queue",
                routerLink: `/IBP_User/customer/${this.companyId}/work-queue`,
                automationId: "workqueue",
            },
            {
                title: "Reports",
                routerLink: `/IBP_User/customer/${this.companyId}/reports`,
                automationId: "reports",
            },
            {
                title: "Help and FAQ's",
                routerLink: `/IBP_User/customer/${this.companyId}/faq`,
                automationId: "helpandfaq",
            },
        ];

        this.activeItem = this.items[0];
    }

    public onActiveItemChange(event: MenuItem) {
        if (!this.shouldDisable && event.title === "Reports") {
            return;
        }
        this.activeItem = event;
        this.router.navigate([event.routerLink]);
    }

    public openSendMessageDialog() {
        this.dialog.open(SendMessageDialogComponent, {
            data: {},
        });
    }

    public openRequestCallDialog() {
        this.dialog.open(SendMessageDialogComponent, {
            data: {
                requestCall: true,
            },
        });
    }
}
