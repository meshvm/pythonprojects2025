import { Component, ElementRef, ViewChild } from "@angular/core";
import { RecordDetailNote } from "./models/record-detail-note.model";

@Component({
    selector: "cc-record-detail-notes-history",
    templateUrl: "./record-detail-notes-history.component.html",
    styleUrls: ["./record-detail-notes-history.component.scss"],
})
export class RecordDetailNotesHistoryComponent {
    @ViewChild("scrollContainer")
    public scrollContainer: ElementRef<HTMLElement>;

    public notes: RecordDetailNote[];

    constructor() {
        setTimeout(() => this.scrollContainerToBottom());
    }

    private scrollContainerToBottom(): void {
        const childNodes = this.scrollContainer.nativeElement.children;

        childNodes[childNodes.length - 1].scrollIntoView({
            behavior: "instant",
            block: "nearest",
            inline: "start",
        });
    }
}
