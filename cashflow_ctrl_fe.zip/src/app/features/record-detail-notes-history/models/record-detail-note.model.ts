export interface RecordDetailNote {
    authorFirstName: string;
    authorSecondName: string;
    note: string;
    date: string;
    isCurrentUserNote?: boolean;
}
