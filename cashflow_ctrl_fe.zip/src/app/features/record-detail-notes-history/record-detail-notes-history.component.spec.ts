import { ComponentFixture, TestBed } from "@angular/core/testing";

import { RecordDetailNotesHistoryComponent } from "./record-detail-notes-history.component";

describe("RecordDetailNotesHistoryComponent", () => {
    let component: RecordDetailNotesHistoryComponent;
    let fixture: ComponentFixture<RecordDetailNotesHistoryComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [RecordDetailNotesHistoryComponent],
        });
        fixture = TestBed.createComponent(RecordDetailNotesHistoryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
