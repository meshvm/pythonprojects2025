import {
    Component,
    ViewEncapsulation,
    Output,
    EventEmitter,
    ViewChild,
    ElementRef,
} from "@angular/core";

@Component({
    selector: "cc-reports-search-panel",
    templateUrl: "./reports-search-panel.component.html",
    styleUrls: ["./reports-search-panel.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class ReportsSearchPanelComponent {
    @ViewChild("calendarDiv") myDiv: ElementRef;
    @Output()
    public dateChange: EventEmitter<Date>;

    public date: Date | undefined;

    public position = "relative";

    constructor() {
        this.dateChange = new EventEmitter<Date>();
    }

    public onDateChange(): void {
        this.dateChange.emit(this.date);
    }

    public reset(): void {
        this.date = undefined;
    }

    public onDatepickerShow(): void {
        this.myDiv.nativeElement.style.position = "absolute";
    }
    public onDatepickerClose(): void {
        this.myDiv.nativeElement.style.position = "relative";
    }
}
