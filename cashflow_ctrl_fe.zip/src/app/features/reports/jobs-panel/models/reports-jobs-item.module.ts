export interface ReportsJobsItem {
    name: string;
    code: string;
}
