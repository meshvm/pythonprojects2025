import { NgModule } from "@angular/core";
import { SharedModule } from "../../../shared/shared.module";
import { ReportsBatchesPanelComponent } from "./reports-batches-panel.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ReportsBatchesPanelComponent],
    exports: [ReportsBatchesPanelComponent],
})
export class ReportsBatchesPanelModule {}
