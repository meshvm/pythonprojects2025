import { ComponentFixture, TestBed } from "@angular/core/testing";
import { SimpleChange } from "@angular/core";
import { DatePipe } from "@angular/common";

import { ReportsBatchesPanelComponent } from "./reports-batches-panel.component";

describe("ReportsBatchesPanelComponent", () => {
    let component: ReportsBatchesPanelComponent;
    let fixture: ComponentFixture<ReportsBatchesPanelComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ReportsBatchesPanelComponent],
            providers: [DatePipe],
        });
        fixture = TestBed.createComponent(ReportsBatchesPanelComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });

    describe("ngOnChanges", () => {
        it("should set reportsArr and filteredReports", () => {
            component.reports = [];
            component.ngOnChanges({
                reports: new SimpleChange(null, component.reports, false),
            });

            expect(component.reportsArr).toBe(component.reports);
            expect(component.filteredReports).toBe(component.reports);
        });

        it("should set tableLabel based on date and label", () => {
            component.date = new Date(2024, 6, 30);
            component.batch = "Batch 1";
            component.ngOnChanges({
                date: new SimpleChange(null, component.date, false),
                batch: new SimpleChange(null, component.batch, false),
            });
            const pipe = new DatePipe("en-US");

            const expectedLabel = `${pipe.transform(
                component.date,
                "EEEE, LLLL d, yyyy"
            )} - ${component.batch}`;
            expect(component.tableLabel).toBe(expectedLabel);
        });
    });
});
