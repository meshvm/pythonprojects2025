import { ComponentFixture, TestBed } from "@angular/core/testing";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { SetupDataEditingDialogComponent } from "./setup-data-editing-dialog.component";

describe("SetupDataEditingDialogComponent", () => {
    let component: SetupDataEditingDialogComponent;
    let fixture: ComponentFixture<SetupDataEditingDialogComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [SetupDataEditingDialogComponent],
            providers: [
                { provide: MAT_DIALOG_DATA, useValue: {} },
                { provide: MatDialogRef, useValue: {} },
            ],
        });
        fixture = TestBed.createComponent(SetupDataEditingDialogComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
