import { Component } from "@angular/core";
import { LoaderService } from "src/app/core/services/loader.service";

@Component({
    selector: "cc-custom-loading-indicator",
    templateUrl: "./custom-loading-indicator.component.html",
    styleUrls: ["./custom-loading-indicator.component.scss"],
})
export class CustomLoadingIndicatorComponent {
    constructor(public loadingService: LoaderService) {}
}
