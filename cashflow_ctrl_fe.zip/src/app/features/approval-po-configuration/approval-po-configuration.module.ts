import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ApprovalPoConfigurationComponent } from "./approval-po-configuration.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ApprovalPoConfigurationComponent],
    exports: [ApprovalPoConfigurationComponent],
})
export class ApprovalPoConfigurationModule {}
