import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA } from "@angular/material/dialog";
import { firstValueFrom } from "rxjs";
import { CustomerApiService } from "../../core/api-services/customer/customer-api.service";
import { ValidaddressOption } from "../../core/api-services/customer/models/valid-address-option.model";
import { MicroservicesApiService } from "../../core/api-services/microservices/microservices-api.service";
import { RequestDetail } from "../../core/models/request-detail.model";
import { LoaderService } from "../../core/services/loader.service";
import { NotificationService } from "../../core/services/notification.service";
import { SingleaddressValidatorHelper } from "./helpers/single-address-validator-helper";
import { SingleaddressValidatorConfig } from "./models/single-address-validator-config.model";

@Component({
    selector: "cc-single-address-validator",
    templateUrl: "single-address-validator.component.html",
    styleUrls: ["single-address-validator.component.scss"],
})
export class SingleaddressValidatorComponent {
    public address: RequestDetail;
    public infoBlockCollapsed: boolean;
    public options: Partial<RequestDetail>[];
    public isLoading: boolean;

    constructor(
        @Inject(MAT_DIALOG_DATA) private config: SingleaddressValidatorConfig,
        private customerApiService: CustomerApiService,
        private loaderService: LoaderService,
        private notificationService: NotificationService,
        private microservicesApiService: MicroservicesApiService
    ) {
        this.address = this.config?.address;
        this.loadOptions();
    }

    public collapseInfoBlock(): void {
        this.infoBlockCollapsed = true;
    }

    public onApplyaddress(address: Partial<RequestDetail>): void {
        this.config.validationApplied(address);
    }

    public onKeepExistingaddress(): void {
        this.config.validationApplied({
            ...this.address,
            addressFromApiOverride: false,
        });
    }

    private async loadOptions(): Promise<void> {
        this.loaderService.setLoading(true);
        this.isLoading = true;

        this.options = [];

        try {
            const customerId = (
                await firstValueFrom(this.microservicesApiService.getUser())
            ).companyId;

            const options: ValidaddressOption[] = (
                await firstValueFrom(
                    this.customerApiService.getValidaddresses(
                        customerId.toString(),
                        `${this.address.addressLine1 || ""} ${
                            this.address.addressLine2 || ""
                        } ${this.address.city || ""} ${
                            this.address.stateOrProvince || ""
                        } ${this.address.postalCode || ""}`
                    )
                )
            )?.addresses;

            this.options = (
                await Promise.all(
                    options.map(async (option) => {
                        const res = await firstValueFrom(
                            this.customerApiService.parseaddress(
                                customerId.toString(),
                                option.address
                            )
                        );
                        return res?.address
                            ? SingleaddressValidatorHelper.mapParsedaddressDtoToRequestDetail(
                                  res.address
                              )
                            : null;
                    })
                )
            )?.filter((option) => !!option) as RequestDetail[];
        } catch (error: any) {
            this.notificationService.showErrorMsg(error);
        }

        this.loaderService.setLoading(false);
        this.isLoading = false;
    }
}
