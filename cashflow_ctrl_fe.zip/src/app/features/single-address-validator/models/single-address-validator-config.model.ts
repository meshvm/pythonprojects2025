import { RequestDetail } from "../../../core/models/request-detail.model";

export interface SingleaddressValidatorConfig {
    address: RequestDetail;
    validationApplied: (address: Partial<RequestDetail>) => void;
}
