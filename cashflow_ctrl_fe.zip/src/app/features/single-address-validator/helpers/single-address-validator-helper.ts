import { ParsedaddressDto } from "../../../core/api-services/customer/models/parsed-address-dto.model";
import { RequestDetail } from "../../../core/models/request-detail.model";

export class SingleaddressValidatorHelper {
    public static mapParsedaddressDtoToRequestDetail(
        address: ParsedaddressDto
    ): Partial<RequestDetail> {
        const { line1, line2 } = address;

        return {
            addressLine1: line1,
            addressLine2: line2,
            city: address.city,
            stateOrProvince: address.stateCode,
            postalCode: address.postalCode,
            addressFromApiOverride: true,
        };
    }
}
