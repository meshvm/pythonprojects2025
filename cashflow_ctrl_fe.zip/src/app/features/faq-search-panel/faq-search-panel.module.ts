import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { FaqSuggestionsKeyboardNavigationDirective } from "./directives/faq-suggestions-keyboard-navigation.directive";
import { FaqSearchPanelComponent } from "./faq-search-panel.component";

@NgModule({
    imports: [SharedModule],
    declarations: [
        FaqSearchPanelComponent,
        FaqSuggestionsKeyboardNavigationDirective,
    ],
    exports: [FaqSearchPanelComponent],
})
export class FaqSearchPanelModule {}
