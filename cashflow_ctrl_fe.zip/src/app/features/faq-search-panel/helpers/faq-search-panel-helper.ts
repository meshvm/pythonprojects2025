import { NamedValue } from "../../../shared/models/base/named-value.model";

export class FaqSearchPanelHelper {
    public static searchSuggestionItems: NamedValue[] = [
        {
            name: "How are checks prioritized?",
            value: "How are checks prioritized",
        },
        {
            name: "Which checks are presented in the exception portal first?",
            value: "Which checks are presented",
        },
        {
            name: "How do I filter my exception queue?",
            value: "How do I filter my exception",
        },
        {
            name: "How do I search for a specific item?",
            value: "specific item",
        },
        {
            name: "Can I show or hide columns in the exception queue?",
            value: "Can I show or hide columns",
        },
        {
            name: "What actions are allowed on a check in the exception queue?",
            value: "actions are allowed on a check",
        },
        {
            name: "How do I perform an action on a check?",
            value: "perform an action on a check",
        },
        {
            name: "How do I export a check?",
            value: "export a check",
        },
        {
            name: "What reports are available?",
            value: "reports are available",
        },
        {
            name: "How do I search for checks by date received?",
            value: "checks by date received",
        },
    ];
}
