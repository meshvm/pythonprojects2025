import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ChangeRoleDialogComponent } from "./change-role-dialog.component";

@NgModule({
    imports: [SharedModule],
    declarations: [ChangeRoleDialogComponent],
    exports: [ChangeRoleDialogComponent],
})
export class ChangeRoleDialogModule {}
