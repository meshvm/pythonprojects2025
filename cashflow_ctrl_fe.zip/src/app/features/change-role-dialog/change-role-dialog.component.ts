import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { ChangeRoleDialogConfig } from "./models/change-role-dialog-config.model";

@Component({
    selector: "cc-change-role-dialog",
    templateUrl: "./change-role-dialog.component.html",
    styleUrls: ["./change-role-dialog.component.scss"],
})
export class ChangeRoleDialogComponent {
    public selectedRole: string;

    constructor(
        public dialogRef: MatDialogRef<ChangeRoleDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: ChangeRoleDialogConfig
    ) {
        this.setSelectedRoleFromConfig();
    }

    public closeDialog(): void {
        this.dialogRef.close();
    }

    public onSave(): void {
        if (!this.selectedRole) {
            return;
        }

        this.data.selectedUsers.forEach(
            (user) => (user.ServiceRoleName = this.selectedRole)
        );
        this.dialogRef.close(this.data);
    }

    private setSelectedRoleFromConfig(): void {
        if (this.data.selectedUsers.length) {
            this.selectedRole =
                this.data.selectedUsers[0].ServiceRoleName || "";
        }
    }
}
