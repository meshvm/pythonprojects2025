import { BreadcrumbItem } from "../../../shared/components/breadcrumb/models/breadcrumb-item.module";
import { NamedValue } from "../../../shared/models/base/named-value.model";

export class FaqQuestionsHelper {
    public static getBreadcrumbs(
        companyId: number,
        searchString: string,
        questions: NamedValue[]
    ): BreadcrumbItem[] {
        if (!searchString) {
            return [];
        }

        return [
            {
                label: "Help and FAQ’s",
                url: `/IBP_User/customer/${companyId}/faq`,
            },
            {
                label: `${questions.length} result(s) for "${searchString}"`,
                url: `/IBP_User/customer/${companyId}/faq?search=${searchString}`,
            },
        ];
    }
}
