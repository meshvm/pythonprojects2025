import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { FaqQuestionsComponent } from "./faq-questions.component";

@NgModule({
    imports: [SharedModule],
    declarations: [FaqQuestionsComponent],
    exports: [FaqQuestionsComponent],
})
export class FaqQuestionsModule {}
