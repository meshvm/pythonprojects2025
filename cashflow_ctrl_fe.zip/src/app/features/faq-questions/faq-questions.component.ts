import { UserService } from "src/app/core/services/users.service";
import {
    Component,
    Input,
    OnChanges,
    SimpleChanges,
    ViewEncapsulation,
} from "@angular/core";
import { BreadcrumbItem } from "../../shared/components/breadcrumb/models/breadcrumb-item.module";
import { NamedValue } from "../../shared/models/base/named-value.model";
import { FaqSupportRequestManagerService } from "../faq-support-request/services/faq-support-request-manager.service";
import { FaqQuestionsHelper } from "./helpers/faq-questions-helper";

@Component({
    selector: "cc-faq-questions",
    templateUrl: "./faq-questions.component.html",
    styleUrls: ["./faq-questions.component.scss"],
    encapsulation: ViewEncapsulation.None,
})
export class FaqQuestionsComponent implements OnChanges {
    @Input()
    public searchText: string;
    @Input()
    public questions: NamedValue[];

    public breadCrumbs: BreadcrumbItem[];
    public nodesExpanded: boolean;

    constructor(
        private faqSupportRequestManagerService: FaqSupportRequestManagerService,
        private userService: UserService
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["searchText"] && !this.searchText) {
            setTimeout(() => this.onCollapseAll());
        }

        if (changes["searchText"] && this.searchText && this.questions.length) {
            this.onExpandAll();
        }

        if (changes["searchText"] && this.searchText) {
            this.breadCrumbs = FaqQuestionsHelper.getBreadcrumbs(
                this.userService.currentCompanyIdValue,
                this.searchText,
                this.questions
            );
        }
    }

    public onExpandAll(): void {
        this.nodesExpanded = true;
    }

    public onCollapseAll(): void {
        this.nodesExpanded = false;
    }

    public onSendMessage(): void {
        this.faqSupportRequestManagerService.openSupportRequestModal();
    }
}
