import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { MicroservicesApiService } from "../../../core/api-services/microservices/microservices-api.service";
import { PackagingTypeItem } from "../../../core/api-services/microservices/models/packaging-types/packaging-type-item.model";
import { ServiceTypeItem } from "../../../core/api-services/microservices/models/service-types/service-type-item.model";
import { NotificationService } from "../../../core/services/notification.service";

@Injectable()
export class RequestDetailsService {
    constructor(
        private microservicesApiService: MicroservicesApiService,
        private notificationService: NotificationService
    ) {}

    public async getPackagingTypeOptions(): Promise<PackagingTypeItem[]> {
        let options: PackagingTypeItem[] = [];

        try {
            options = (
                await firstValueFrom(
                    this.microservicesApiService.getPackagingTypes()
                )
            )?.packagingTypes;
        } catch (error: any) {
            this.notificationService.showErrorMsg(error);
        }

        return options;
    }

    public async getServiceTypeOptions(): Promise<ServiceTypeItem[]> {
        let options: ServiceTypeItem[] = [];

        try {
            options = (
                await firstValueFrom(
                    this.microservicesApiService.getServiceTypes()
                )
            )?.serviceTypes;
        } catch (error: any) {
            this.notificationService.showErrorMsg(error);
        }

        return options;
    }
}
