import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ConfigurationItemComponent } from "./configuration-item.component";
import { MatDialogModule } from "@angular/material/dialog";

describe("ConfigurationItem", () => {
    let component: ConfigurationItemComponent;
    let fixture: ComponentFixture<ConfigurationItemComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [MatDialogModule],
            declarations: [ConfigurationItemComponent],
        });
        fixture = TestBed.createComponent(ConfigurationItemComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
