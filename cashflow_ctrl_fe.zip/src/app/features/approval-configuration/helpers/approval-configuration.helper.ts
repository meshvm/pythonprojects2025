export class ApprovalConfigurationHelper {
    public static readonly defaultTableColumns: string[] = [
        "level",
        "paymentRangeMin",
        "paymentRangeMax",
        "approvalType",
        "approvers",
        "actions",
    ];
}
