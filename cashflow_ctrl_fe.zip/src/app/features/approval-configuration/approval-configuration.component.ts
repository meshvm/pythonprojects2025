import { Component, Input, OnInit } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { ActivatedRoute } from "@angular/router";
import { ApprovalsApiService } from "../../core/api-services/approvals/approvals-api.service";
import { ProjectApprovalRuleConfiguration } from "../../core/api-services/approvals/models/project-approval-rule-configuration.model";
import { ProjectApprovalTypeCode } from "../../core/api-services/approvals/models/project-approval-type-code.enum";
import { ApprovalConfigurationHelper } from "./helpers/approval-configuration.helper";

@Component({
    selector: "cc-approval-configuration",
    templateUrl: "approval-configuration.component.html",
    styleUrls: ["approval-configuration.component.scss"],
})
export class ApprovalConfigurationComponent implements OnInit {
    @Input()
    public companyServiceId: number;

    public readonly tableColumns: string[];
    public readonly approvalTypeCode: typeof ProjectApprovalTypeCode;

    public tableDataSource: MatTableDataSource<ProjectApprovalRuleConfiguration>;

    private ProjectID: number;

    constructor(
        private approvalsApiService: ApprovalsApiService,
        private activatedRoute: ActivatedRoute
    ) {
        this.tableColumns = ApprovalConfigurationHelper.defaultTableColumns;
        this.approvalTypeCode = ProjectApprovalTypeCode;

        this.initUrlParams();
    }

    public ngOnInit(): void {
        this.loadConfigs();
    }

    public onEditItem(configItem: ProjectApprovalRuleConfiguration): void {}

    private async loadConfigs(): Promise<void> {
        this.tableDataSource =
            new MatTableDataSource<ProjectApprovalRuleConfiguration>(
                await this.approvalsApiService.getApprovalRuleConfigs(
                    this.companyServiceId,
                    this.ProjectID
                )
            );
    }

    private initUrlParams(): void {
        this.ProjectID = parseInt(
            this.activatedRoute.snapshot.paramMap.get("ProjectID") || "0",
            10
        );
    }
}
