export class CarrierServiceTableHelper {
    public static readonly defaultPrimaryField: string = "carrierName";
    public static readonly defaultTableColumns: string[] = [
        "carrierName",
        "serviceName",
        "rateCard",
        "status",
        "actions",
    ];
}
