import { Component, Input, OnInit } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { CarrierServiceTableHelper } from "./helpers/carrier-service-table-helper";

@Component({
    selector: "cc-carrier-service-table",
    templateUrl: "./carrier-service-table.component.html",
    styleUrls: ["./carrier-service-table.component.scss"],
})
export class CarrierServiceTableComponent implements OnInit {
    @Input()
    public itemsData: any[];

    public readonly tableColumns: string[];

    public currentEditingIndex: number;
    public tableDataSource: MatTableDataSource<any>;

    private readonly primaryField: string;

    constructor() {
        this.tableColumns = CarrierServiceTableHelper.defaultTableColumns;
        this.primaryField = CarrierServiceTableHelper.defaultPrimaryField;
        this.itemsData = [];
        this.currentEditingIndex = -1;
    }

    public ngOnInit(): void {
        this.tableDataSource = new MatTableDataSource<any>(
            JSON.parse(JSON.stringify(this.itemsData))
        );
    }

    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public onAddItem(): void {
        if (this.currentEditingIndex === -1) {
            this.currentEditingIndex = this.itemsData.length;
            this.tableDataSource.data = [...this.itemsData, {}];
        }
    }
    public onEditItem(index: number): void {
        if (this.currentEditingIndex === -1) {
            this.currentEditingIndex = index;
        }
    }

    public onRemoveItem(index: number): void {
        this.itemsData.splice(index, 1);
        this.tableDataSource.data = JSON.parse(JSON.stringify(this.itemsData));
    }

    public onSaveItem(): void {
        if (
            !this.tableDataSource.data[this.currentEditingIndex][
                this.primaryField
            ]
        ) {
            return;
        }
        this.currentEditingIndex = -1;
        this.itemsData = JSON.parse(JSON.stringify(this.tableDataSource.data));
    }

    public onCancelItem(): void {
        this.currentEditingIndex = -1;
        this.tableDataSource.data = JSON.parse(JSON.stringify(this.itemsData));
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
