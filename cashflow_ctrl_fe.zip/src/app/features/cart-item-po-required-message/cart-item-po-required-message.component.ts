import { Component, Input } from "@angular/core";

@Component({
    selector: "cc-cart-item-po-required-message",
    templateUrl: "cart-item-po-required-message.component.html",
    styleUrls: ["cart-item-po-required-message.component.scss"],
})
export class CartItemPoRequiredMessageComponent {
    @Input()
    public billingAmount: number;
    @Input()
    public threshold: number;
}
