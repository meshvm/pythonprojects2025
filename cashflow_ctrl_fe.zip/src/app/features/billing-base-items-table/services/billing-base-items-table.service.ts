import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { without } from "lodash";
import { BillingItem } from "../../../core/api-services/billing/models/billing-item.model";
import { BillingBaseItemsTableMode } from "../models/billing-base-items-table-mode.enum";
import { BillingBaseItemsExtractCostItemPipe } from "../pipes/billing-base-items-extract-cost-item.pipe";

@Injectable()
export class BillingBaseItemsTableService {
    constructor(
        private formBuilder: FormBuilder,
        private billingBaseItemsExtractCostItemPipe: BillingBaseItemsExtractCostItemPipe
    ) {}

    public buildForm(
        item: BillingItem,
        mode: BillingBaseItemsTableMode
    ): FormGroup {
        const costItem = this.billingBaseItemsExtractCostItemPipe.transform(
            item,
            mode
        );

        return this.formBuilder.group({
            overageThresholdPages: [
                costItem.overageThresholdPages,
                Validators.required,
            ],
            highVolumeThresholdUnits: [
                costItem.highVolumeThresholdUnits,
                Validators.required,
            ],
            baseUnitPrice: [costItem.baseUnitPrice, Validators.required],
            lowVolumeOveragePageUnitPrice: [
                costItem.lowVolumeOveragePageUnitPrice,
                Validators.required,
            ],
            highVolumeUnitPrice: [
                costItem.highVolumeUnitPrice,
                Validators.required,
            ],
            highVolumeOveragePageUnitPrice: [
                costItem.highVolumeOveragePageUnitPrice,
                Validators.required,
            ],
        });
    }

    public mapToModel(
        item: BillingItem,
        form: FormGroup,
        mode: BillingBaseItemsTableMode
    ): BillingItem {
        const {
            overageThresholdPages,
            highVolumeThresholdUnits,
            baseUnitPrice,
            lowVolumeOveragePageUnitPrice,
            highVolumeUnitPrice,
            highVolumeOveragePageUnitPrice,
        } = form.value;

        const selectedCostItem = item.billingItemCost.find((costItem) =>
            mode === BillingBaseItemsTableMode.Duplex
                ? costItem.isDuplexPrinting
                : !costItem.isDuplexPrinting
        );

        const costItems = without(item.billingItemCost, selectedCostItem);

        return {
            ...item,
            isDefault: true,
            billingItemCost: [
                ...costItems,
                {
                    ...selectedCostItem,
                    overageThresholdPages,
                    highVolumeThresholdUnits,
                    baseUnitPrice,
                    lowVolumeOveragePageUnitPrice,
                    highVolumeUnitPrice,
                    highVolumeOveragePageUnitPrice,
                } as any,
            ],
        };
    }
}
