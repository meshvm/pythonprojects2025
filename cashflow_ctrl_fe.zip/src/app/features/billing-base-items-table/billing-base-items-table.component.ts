import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    Output,
    SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatTableDataSource } from "@angular/material/table";
import { cloneDeep } from "lodash";
import { BillingItem } from "../../core/api-services/billing/models/billing-item.model";
import { BillingBaseItemsTableHelper } from "./helpers/billing-base-items-table-helper";
import { BillingBaseItemsTableMode } from "./models/billing-base-items-table-mode.enum";
import { BillingBaseItemsExtractCostItemPipe } from "./pipes/billing-base-items-extract-cost-item.pipe";
import { BillingBaseItemsTableService } from "./services/billing-base-items-table.service";

@Component({
    selector: "cc-billing-base-items",
    templateUrl: "./billing-base-items-table.component.html",
    styleUrls: ["billing-base-items-table.component.scss"],
    providers: [
        BillingBaseItemsExtractCostItemPipe,
        BillingBaseItemsTableService,
    ],
})
export class BillingBaseItemsTableComponent implements OnChanges {
    @Input()
    public billingItems: BillingItem[];
    @Input()
    public ProjectID: number;
    @Input()
    public selectedMode: BillingBaseItemsTableMode;

    @Output()
    public createItem: EventEmitter<Partial<BillingItem>>;
    @Output()
    public updateItem: EventEmitter<BillingItem>;
    @Output()
    public deleteItem: EventEmitter<BillingItem>;

    public formGroup: FormGroup;
    public currentEditingBillingItem: BillingItem | null;
    public billingTableDataSource: MatTableDataSource<BillingItem>;

    public readonly tableColumns: string[];

    constructor(
        private billingBaseItemsTableService: BillingBaseItemsTableService
    ) {
        this.tableColumns = BillingBaseItemsTableHelper.tableColumns;

        this.formGroup = this.billingBaseItemsTableService.buildForm(
            {} as any,
            this.selectedMode
        );

        this.createItem = new EventEmitter<Partial<BillingItem>>();
        this.updateItem = new EventEmitter<BillingItem>();
        this.deleteItem = new EventEmitter<BillingItem>();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["billingItems"]) {
            this.billingTableDataSource = new MatTableDataSource<BillingItem>(
                cloneDeep(this.billingItems || [])
            );
        }
    }

    public onCancelBillingItemEditing(): void {
        this.currentEditingBillingItem = null;
    }

    public onEditBillingItem(item: BillingItem): void {
        this.currentEditingBillingItem = item;

        this.formGroup = this.billingBaseItemsTableService.buildForm(
            item,
            this.selectedMode
        );
    }

    public onSaveBillingItem(): void {
        if (!this.formGroup.valid) {
            return;
        }

        this.updateItem.emit(
            this.billingBaseItemsTableService.mapToModel(
                this.currentEditingBillingItem as BillingItem,
                this.formGroup,
                this.selectedMode
            )
        );

        this.currentEditingBillingItem = null;
    }
}
