export enum BillingBaseItemsTableMode {
    Simplex = "Simplex",
    Duplex = "Duplex",
}
