import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { HeaderCartComponent } from "./header-cart.component";

@NgModule({
    imports: [SharedModule],
    declarations: [HeaderCartComponent],
    exports: [HeaderCartComponent],
})
export class HeaderCartModule {}
