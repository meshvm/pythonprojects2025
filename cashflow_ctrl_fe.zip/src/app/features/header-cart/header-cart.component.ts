import { Component } from "@angular/core";
import { Observable } from "rxjs";
import { CartService } from "../../core/services/cart.service";

@Component({
    selector: "cc-header-cart",
    templateUrl: "header-cart.component.html",
    styleUrls: ["header-cart.component.scss"],
})
export class HeaderCartComponent {
    constructor(private cartService: CartService) {}

    public get itemCount$(): Observable<number> {
        return this.cartService.itemCnt$;
    }
}
