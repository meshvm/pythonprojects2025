import { Component, EventEmitter, Input, Output } from "@angular/core";
import { LabeledValue } from "../../core/models/labeled-value.model";

@Component({
    selector: "cc-customer-database-configuration",
    templateUrl: "./customer-database-configuration.component.html",
    styleUrls: ["./customer-database-configuration.component.scss"],
})
export class CustomerDatabaseConfigurationComponent {
    @Input()
    public showCustomerDatabaseConfigurations: boolean;
    @Input()
    public dbConfig: any;
    @Input()
    public objectDispositionOptions: LabeledValue[];
    @Input()
    public iAMAccountOptions: LabeledValue[];
    @Input()
    public databaseServerOptions: LabeledValue[];
    @Input()
    public databaseTypeOptions: LabeledValue[];
    @Input()
    public idpSettingsList: any[];

    @Output()
    public toggleContent: EventEmitter<boolean>;

    constructor() {
        this.toggleContent = new EventEmitter<boolean>();
        this.showCustomerDatabaseConfigurations = false;
    }

    public toggleSection(): void {
        this.toggleContent.emit(this.showCustomerDatabaseConfigurations);
    }
}
