import { ComponentFixture, TestBed } from "@angular/core/testing";

import { CustomerDatabaseConfigurationComponent } from "./customer-database-configuration.component";
import { HttpClientModule } from "@angular/common/http";
import { GetTestDataService } from "src/app/get-test-data.service";

describe("CustomerDatabaseConfigurationComponent", () => {
    let component: CustomerDatabaseConfigurationComponent;
    let fixture: ComponentFixture<CustomerDatabaseConfigurationComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerDatabaseConfigurationComponent],
            imports: [HttpClientModule],
            providers: [GetTestDataService],
        });
        fixture = TestBed.createComponent(
            CustomerDatabaseConfigurationComponent
        );
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
