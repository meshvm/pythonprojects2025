import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { CustomerDatabaseConfigurationComponent } from "./customer-database-configuration.component";

@NgModule({
    imports: [SharedModule],
    declarations: [CustomerDatabaseConfigurationComponent],
    exports: [CustomerDatabaseConfigurationComponent],
})
export class CustomerDatabaseConfigurationModule {}
