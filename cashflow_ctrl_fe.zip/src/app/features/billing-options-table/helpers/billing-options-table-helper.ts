export class BillingOptionsTableHelper {
    public static readonly defaultTableColumns: string[] = [
        "DepartmentName",
        "departmentCode",
        "actions",
    ];
}
