import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    Output,
} from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { LabeledValue } from "../../core/models/labeled-value.model";
import { BillingOptionsTableHelper } from "./helpers/billing-options-table-helper";

@Component({
    selector: "cc-billing-options-table",
    templateUrl: "./billing-options-table.component.html",
    styleUrls: ["./billing-options-table.component.scss"],
})
export class BillingOptionsTableComponent implements OnChanges {
    @Input()
    public itemsData: any[];
    @Input()
    public departmentOptions: LabeledValue[];

    @Output()
    public updateItems: EventEmitter<any> = new EventEmitter<any>();

    public readonly tableColumns: string[];

    public currentEditingIndex: number;
    public tableDataSource: MatTableDataSource<any>;

    private adding: boolean;

    constructor() {
        this.tableColumns = BillingOptionsTableHelper.defaultTableColumns;

        this.itemsData = [];
        this.departmentOptions = [];
        this.currentEditingIndex = -1;
        this.adding = false;
    }

    public ngOnChanges(changes: any): void {
        if (changes.itemsData) {
            if (this.itemsData === undefined) {
                this.itemsData = [];
            }
            this.tableDataSource = new MatTableDataSource<any>(
                JSON.parse(JSON.stringify(this.itemsData))
            );
        }
    }
    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public onAddItem(): void {
        if (this.currentEditingIndex === -1) {
            this.currentEditingIndex = this.itemsData.length;
            const newRow = {
                departmentBillingCode: "",
                DepartmentName: "",
            };
            this.tableDataSource.data = [...this.itemsData, newRow];
            this.itemsData.push(newRow);
            this.adding = true;
        }
    }

    public onEditItem(index: number): void {
        if (this.currentEditingIndex === -1) {
            this.currentEditingIndex = index;
        }
    }

    public onRemoveItem(index: number): void {
        this.tableDataSource.data = JSON.parse(JSON.stringify(this.itemsData));
        this.updateItems.emit({
            index: index,
            mode: "delete",
            data: this.itemsData,
        });
    }

    public onSaveItem(): void {
        if (
            !this.tableDataSource.data[this.currentEditingIndex].DepartmentName
        ) {
            return;
        }
        this.itemsData = JSON.parse(JSON.stringify(this.tableDataSource.data));
        this.updateItems.emit({
            index: this.currentEditingIndex,
            mode: this.adding ? "create" : "update",
            data: this.itemsData,
        });
        this.currentEditingIndex = -1;
        this.adding = false;
    }

    public onCancelItem(): void {
        this.currentEditingIndex = -1;
        if (this.adding) {
            this.itemsData.pop();
        }
        this.adding = false;
        this.tableDataSource.data = JSON.parse(JSON.stringify(this.itemsData));
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }
}
