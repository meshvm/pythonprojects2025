import { ComponentFixture, TestBed } from "@angular/core/testing";
import { HeaderAdminComponent } from "./header.component";
import { MatDialogModule } from "@angular/material/dialog";
import { MatMenuModule } from "@angular/material/menu"; // Import MatMenuModule
import { HttpClientModule } from "@angular/common/http";
import { MicroservicesApiService } from "src/app/core/api-services/microservices/microservices-api.service";
import {
    OAuthService,
    UrlHelperService,
    OAuthLogger,
    DateTimeProvider,
} from "angular-oauth2-oidc";
import { AuthService } from "src/app/core/oidc/auth-oidc.service";

describe("HeaderComponent", () => {
    let component: HeaderAdminComponent;
    let fixture: ComponentFixture<HeaderAdminComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [HeaderAdminComponent],
            imports: [MatDialogModule, MatMenuModule, HttpClientModule],
            providers: [
                MicroservicesApiService,
                AuthService,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                DateTimeProvider,
            ],
        });
        fixture = TestBed.createComponent(HeaderAdminComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
