import { Component, OnInit } from "@angular/core";
import { firstValueFrom, map } from "rxjs";
import { MicroservicesApiService } from "src/app/core/api-services/microservices/microservices-api.service";
import { AuthService as OAuthService } from "src/app/core/oidc/auth-oidc.service";
// import { SendMessageDialogComponent } from "src/app/features/send-message-dialog/send-message-dialog.component";
import { GetMenuItemsResponse } from "../../core/api-services/microservices/models/menu-items/get-menu-items-response.model";
import { MenuItem } from "../../core/api-services/microservices/models/menu-items/menu-item.model";
import { UserPermissionApiService } from "../../core/api-services/user-permission/user-permission-api.service";
import { UserService } from "src/app/core/services/users.service";
import { ActivatedRoute, Router } from "@angular/router";
import { LoaderService } from "src/app/core/services/loader.service";

@Component({
    selector: "cc-admin-header",
    templateUrl: "./header.component.html",
    styleUrls: ["./header.component.scss"],
})
export class HeaderAdminComponent implements OnInit {
    public isAdmin: boolean;
    public isLoading: boolean;
    public isMenuOpened: boolean;
    public username: string;
    public headerItems: MenuItem[];
    public companyId: number;

    constructor(
        private microservicesApiService: MicroservicesApiService,
        private oauthService: OAuthService,
        private userPermissionApiService: UserPermissionApiService,
        private userService: UserService,
        private loadingService: LoaderService,
        private router: Router,
        private activatedRoute: ActivatedRoute
    ) {
        this.isMenuOpened = false;
        this.username = "";
        this.headerItems = [];
    }

    public async ngOnInit(): Promise<void> {
        if (!this.oauthService.identityClaims) {
            return;
        }
        this.loadingService.setLoading(true);
        this.userService.currentCompanyId.subscribe(async (companyId) => {
            if (companyId > 0) {
                this.companyId = companyId;
                localStorage.setItem(
                    "companyId",
                    JSON.stringify(this.companyId)
                );
                await this.loadNavItems();
                this.loadingService.setLoading(false);
            }
        });
        await this.loadData();
    }

    public onLogout(): void {
        localStorage.removeItem("companyId");
        this.oauthService.logout();
    }

    public async loadNavItems(): Promise<void> {
        this.isLoading = true;
        await this.microservicesApiService
            .getNavItems(this.companyId)
            .pipe(
                map((data: GetMenuItemsResponse) => {
                    const menuRevised = data.menus.map((obj: MenuItem) => ({
                        ...obj,
                        icon:
                            "data:image/svg+xml;charset=utf-8," +
                            encodeURIComponent(
                                this.ensureSvgNamespace(obj.iconFileName)
                            ),
                        imgLeapwork: "" + obj.iconName,
                        linkLeapwork: "link_" + obj.iconName,
                        name: obj.iconName,
                    }));
                    return { ...data, menus: menuRevised };
                })
            )
            .subscribe((data) => (this.headerItems = data.menus));
    }

    // private async loadIsAdmin(): Promise<void> {
    //     const user = await firstValueFrom(
    //         this.userPermissionApiService.getUserInfo()
    //     );
    //     this.isAdmin = user?.isCashflowCtrlAdmin;
    // }

    private async loadUserMetadata(): Promise<void> {
        this.isLoading = true;
        const user = await firstValueFrom(
            this.microservicesApiService.getUser()
        );
        const urlSplit = window.location.pathname.split("/");
        const customerIndex = urlSplit.indexOf("customer");
        if (customerIndex > -1 && urlSplit[customerIndex + 1]) {
            const companyIDParam = Number(urlSplit[customerIndex + 1]);
            if (!isNaN(companyIDParam) && companyIDParam > 0) {
                this.companyId = companyIDParam;
                this.userService.setCompanyId(this.companyId);
                this.setRoleID(user);
            } else {
                console.error(
                    "Invalid company ID:",
                    urlSplit[customerIndex + 1]
                );
            }
        }

        if (!this.userService.currentCompanyIdValue) {
            const servicePermission = user.ServicePermissions.find(
                (v) => v["ServiceID"] === 5
            );
            const companyId = servicePermission
                ? Number(servicePermission["CompanyID"])
                : null;

            if (companyId && !isNaN(companyId)) {
                this.companyId = companyId;
                this.userService.setCompanyId(this.companyId);
                this.setRoleID(user);
                this.router.navigate([
                    `/IBP_User/customer/${this.companyId}/work-queue/all`,
                ]);
            } else {
                console.error(
                    "Invalid company ID:",
                    servicePermission ? servicePermission["CompanyID"] : "None"
                );
            }
        }
        this.username = user.FirstName + " " + user.LastName;
        this.userService.currentUserName = this.username;
        if (this.companyId) {
            this.setRoleID(user);
        }
    }

    private setRoleID(user: any): void {
        this.userService.setUserRole(
            user.ServicePermissions.find(
                (v: { [x: string]: number }) =>
                    v["CompanyID"] === this.companyId && v["ServiceID"] === 5
            )?.["RoleID"]
        );
    }

    private async loadData(): Promise<void> {
        this.isLoading = true;

        await this.loadUserMetadata();
        // await this.loadIsAdmin();

        this.isLoading = false;
    }

    private ensureSvgNamespace(svgString: string): string {
        const xmlns = 'xmlns="http://www.w3.org/2000/svg"';
        const xmlnsSvg = 'xmlns:svg="http://www.w3.org/2000/svg"';

        if (!svgString.includes(xmlns)) {
            svgString = svgString.replace("<svg", `<svg ${xmlns}`);
        }

        if (!svgString.includes(xmlnsSvg)) {
            svgString = svgString.replace("<svg", `<svg ${xmlnsSvg}`);
        }

        return svgString;
    }
}
