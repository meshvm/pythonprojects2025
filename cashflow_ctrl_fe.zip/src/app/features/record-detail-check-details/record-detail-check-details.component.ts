import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    Renderer2,
    SimpleChanges,
    ViewChild,
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { RecordDetailNotesHistoryModalService } from "../record-detail-notes-history/services/record-detail-notes-history-modal.service";
import { RecordDetailNote } from "../record-detail-notes-history/models/record-detail-note.model";
import { DateTimeHelper } from "src/app/core/helpers/date-time-helper";
import * as moment from "moment/moment";

@Component({
    selector: "cc-record-detail-check-details",
    templateUrl: "./record-detail-check-details.component.html",
    styleUrls: ["./record-detail-check-details.component.scss"],
    providers: [RecordDetailNotesHistoryModalService],
})
export class RecordDetailCheckDetailsComponent implements OnInit, OnChanges {
    @ViewChild("CheckAmountInput") CheckAmountInput: ElementRef;
    @ViewChild("CheckLegalNumberInput") CheckLegalNumberInput: ElementRef;

    @Input()
    public isArchive: boolean;
    @Input()
    public CheckDate: string;
    @Input()
    public CheckNumber: string;
    @Input()
    public CheckAccountNumber: string;
    @Input()
    public CheckAmount: string;
    @Input()
    public RT: string;
    @Input()
    public CheckLegalNumber: string;
    @Input()
    public CheckPayorName: string;
    @Input()
    public CheckPayorAddress: string;
    @Input()
    public CheckMemo: string;
    @Input()
    public noteToValidationOperator: string;

    @Output()
    public submitForProcessing: EventEmitter<any>;

    public checkDetailsForm: FormGroup;

    public static notes: RecordDetailNote[] = [
        {
            authorFirstName: "Helen",
            authorSecondName: "Stafford",
            note: "This check is missing a signature. What should I do with it?",
            date: "Oct 25, 2021 15:32",
        },
        {
            authorFirstName: "John",
            authorSecondName: "Smith",
            note: "We need to reject this one and give it back to the customer.",
            date: "Oct 25, 2021 15:36",
            isCurrentUserNote: true,
        },
        {
            authorFirstName: "Helen",
            authorSecondName: "Stafford",
            note: "Ok, is there anything I need to include when I send it back??",
            date: "Oct 25, 2021 15:36",
        },
        {
            authorFirstName: "John",
            authorSecondName: "Smith",
            note: "Return check to customer address with rejection letter.",
            date: "Oct 25, 2021 15:38",
            isCurrentUserNote: true,
        },
    ];

    public options = [
        { label: "Deposit & Post", command: "Deposit&Post" },
        { label: "Return Check", command: "ReturnCheck" },
        { label: "On Hold", command: "OnHold" },
        { label: "Resubmit", command: "Resubmit" },
        { label: "Export", command: "Export" },
    ];

    public selectedOption: any = this.options[0];

    private inputPropertyNames: string[] = [
        "CheckDate",
        "CheckNumber",
        "CheckAccountNumber",
        "CheckAmount",
        "RT",
        "CheckLegalNumber",
        "CheckPayorName",
        "CheckPayorAddress",
        "CheckMemo",
    ];

    constructor(
        private fb: FormBuilder,
        private recordDetailNotesHistoryModalService: RecordDetailNotesHistoryModalService,
        private renderer: Renderer2
    ) {
        this.submitForProcessing = new EventEmitter<any>();
    }

    ngOnInit(): void {
        this.checkDetailsForm = this.fb.group({
            CheckDate: [this.CheckDate],
            CheckNumber: [this.CheckNumber],
            CheckAccountNumber: [this.CheckAccountNumber],
            CheckAmount: [this.CheckAmount],
            RT: [this.RT],
            CheckLegalNumber: [this.CheckLegalNumber],
            CheckPayorName: [this.CheckPayorName],
            CheckPayorAddress: [this.CheckPayorAddress],
            CheckMemo: [this.CheckMemo],
            noteToValidationOperator: [this.noteToValidationOperator],
        });
        this.triggerBlurEvents();
    }

    ngOnChanges(changes: SimpleChanges): void {
        let shouldReset = false;

        for (const propName in changes) {
            if (
                changes.hasOwnProperty(propName) &&
                this.inputPropertyNames.includes(propName)
            ) {
                shouldReset = true;
                break;
            }
        }

        if (shouldReset) {
            this.resetFormValues();
            this.triggerBlurEvents();
        }
    }

    // public areFieldsDifferent(): boolean {
    //     return (
    //         this.checkDetailsForm.get("CheckAmount")?.value !==
    //         this.checkDetailsForm.get("CheckLegalNumber")?.value
    //     );
    // }

    public toggleDropdown() {
        const dropdownMenu = document.getElementById("dropdownMenu");
        if (dropdownMenu) {
            dropdownMenu.classList.toggle("hidden");
        }
    }

    public selectOption(option: any) {
        this.selectedOption = option;
        this.toggleDropdown();
    }

    public reject(): void {
        this.submitForProcessing.emit({
            command: "Reject",
            form: this.checkDetailsForm.value,
            note: this.noteToValidationOperator,
        });
    }
    public acceptAndProcess(): void {
        const data = {
            command: "Deposit&Post",
            form: this.checkDetailsForm.value,
            note: this.noteToValidationOperator,
        };
        data.form.CheckDate = DateTimeHelper.formatDateToString(
            data.form.CheckDate
        );
        this.submitForProcessing.emit(data);
    }

    public openNotesHistory(): void {
        this.recordDetailNotesHistoryModalService.openNotesHistoryModal(
            RecordDetailCheckDetailsComponent.notes
        );
    }

    public discard() {
        this.resetFormValues();
    }

    private triggerBlurEvents(): void {
        if (!this.isArchive) {
            if (this.CheckAmountInput) {
                this.renderer
                    .selectRootElement(this.CheckAmountInput.nativeElement)
                    .focus();
                this.renderer
                    .selectRootElement(this.CheckAmountInput.nativeElement)
                    .blur();
            }
        } else {
            if (this.CheckAmountInput) {
                this.renderer
                    .selectRootElement(this.CheckAmountInput.nativeElement)
                    .focus();
                this.renderer
                    .selectRootElement(this.CheckAmountInput.nativeElement)
                    .blur();
            }
            if (this.CheckLegalNumberInput) {
                this.renderer
                    .selectRootElement(this.CheckLegalNumberInput.nativeElement)
                    .focus();
                this.renderer
                    .selectRootElement(this.CheckLegalNumberInput.nativeElement)
                    .blur();
            }
        }
    }

    private resetFormValues(): void {
        if (this.isArchive) {
            this.checkDetailsForm?.patchValue({
                CheckDate: this.CheckDate
                    ? new Date(moment(this.CheckDate, "YYYYMMDD").toString())
                    : "",
                CheckNumber: this.CheckNumber,
                CheckAccountNumber: this.CheckAccountNumber,
                CheckAmount: this.CheckAmount,
                RT: this.RT,
                CheckLegalNumber: this.CheckLegalNumber,
                CheckPayorName: this.CheckPayorName,
                CheckPayorAddress: this.CheckPayorAddress,
                CheckMemo: this.CheckMemo,
            });
            this.triggerBlurEvents();
        } else {
            this.checkDetailsForm?.patchValue({
                CheckDate: this.CheckDate
                    ? new Date(moment(this.CheckDate, "YYYYMMDD").toString())
                    : "",
                CheckNumber: this.CheckNumber,
                CheckAccountNumber: this.CheckAccountNumber,
                CheckAmount: this.CheckAmount,
                RT: this.RT,
                CheckLegalNumber: this.CheckLegalNumber,
                CheckPayorName: this.CheckPayorName,
                CheckPayorAddress: this.CheckPayorAddress,
                CheckMemo: this.CheckMemo,
            });
            this.triggerBlurEvents();
        }
    }
}
