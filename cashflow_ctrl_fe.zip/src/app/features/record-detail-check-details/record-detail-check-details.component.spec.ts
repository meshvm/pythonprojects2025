import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RecordDetailCheckDetailsComponent } from "./record-detail-check-details.component";

describe("RecordDetailCheckDetailsComponent", () => {
    let component: RecordDetailCheckDetailsComponent;
    let fixture: ComponentFixture<RecordDetailCheckDetailsComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [RecordDetailCheckDetailsComponent],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(RecordDetailCheckDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
