import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ProjectApiService } from "src/app/core/api-services/project/project-api.service";
import { LoaderService } from "src/app/core/services/loader.service";
import { Project } from "../../core/models/project.model";

@Component({
    selector: "cc-projects-list",
    templateUrl: "./projects-list.component.html",
    styleUrls: ["./projects-list.component.scss"],
})
export class ProjectsListComponent implements OnInit {
    public projectList: Project[];
    public searchKeyword: string;

    constructor(
        private projectService: ProjectApiService,
        private route: ActivatedRoute,
        public loadingService: LoaderService
    ) {
        this.projectList = [];
        this.searchKeyword = "";
    }

    public ngOnInit(): void {
        this.loadData();
    }

    private loadData(): void {
        this.loadingService.setLoading(true);

        const companyId = parseInt(
            this.route.snapshot.paramMap.get("CustomerID") || "0",
            10
        );

        this.projectService
            .getProjects(companyId.toString() || "25")
            .subscribe((data) => {
                this.projectList = data.result;
                this.loadingService.setLoading(false);
            });
    }
}
