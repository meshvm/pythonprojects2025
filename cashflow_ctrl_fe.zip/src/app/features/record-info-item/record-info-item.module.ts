import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { RecordInfoItemComponent } from "./record-info-item.component";

@NgModule({
    imports: [SharedModule],
    declarations: [RecordInfoItemComponent],
    exports: [RecordInfoItemComponent],
})
export class RecordInfoItemModule {}
