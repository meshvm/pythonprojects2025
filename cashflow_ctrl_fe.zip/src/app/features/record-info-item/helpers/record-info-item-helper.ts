export class RecordInfoItemHelper {
    public static readonly defaultFieldTypeOptions = [
        {
            value: "input_varchar_short",
            label: "Varchar Short",
            icon: "assets/images/input-text-short.svg",
        },
        {
            value: "input_varchar_long",
            label: "Varchar Long",
            icon: "assets/images/input-text-long.svg",
        },
        {
            value: "input_integer",
            label: "Integer",
            icon: "assets/images/input-numeric.svg",
        },
        {
            value: "input_decimal",
            label: "Decimal",
            icon: "assets/images/input-decimal.svg",
        },
        {
            value: "input_currency",
            label: "Currency",
            icon: "assets/images/input-currency.svg",
        },
        {
            value: "input_datetime",
            label: "Date/Time",
            icon: "assets/images/input-date-time.svg",
        },
    ];
}
