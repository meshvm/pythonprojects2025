import { ComponentFixture, TestBed } from "@angular/core/testing";

import { ProjectConfigurationsComponent } from "./project-configurations.component";

describe("CSConfigurationsComponent", () => {
    let component: ProjectConfigurationsComponent;
    let fixture: ComponentFixture<ProjectConfigurationsComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ProjectConfigurationsComponent],
        });
        fixture = TestBed.createComponent(ProjectConfigurationsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
