import { NgModule } from "@angular/core";
import { SharedModule } from "../../shared/shared.module";
import { ProjectsListModule } from "../projects-list/projects-list.module";
import { UserPermissionsEditorModule } from "../user-permissions-editor/user-permissions-editor.module";
import { ProjectConfigurationsComponent } from "./project-configurations.component";

@NgModule({
    imports: [SharedModule, ProjectsListModule, UserPermissionsEditorModule],
    declarations: [ProjectConfigurationsComponent],
    exports: [ProjectConfigurationsComponent],
})
export class ProjectConfigurationsModule {}
