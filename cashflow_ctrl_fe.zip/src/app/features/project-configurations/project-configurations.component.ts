import { Component, Input, OnInit } from "@angular/core";
import { TabStateService } from "./service/project-configuration.service";
import { MatTabChangeEvent } from "@angular/material/tabs";

@Component({
    selector: "cc-project-configurations",
    templateUrl: "./project-configurations.component.html",
    styleUrls: ["./project-configurations.component.scss"],
})
export class ProjectConfigurationsComponent implements OnInit {
    @Input()
    public companyId: number;
    @Input()
    public serviceId: number;

    selectedTabIndex: number = 0;

    constructor(private tabStateService: TabStateService) {}

    ngOnInit(): void {
        this.tabStateService.selectedTabIndex$.subscribe((index) => {
            this.selectedTabIndex = index;
        });
    }

    onTabChange(event: MatTabChangeEvent): void {
        this.tabStateService.setSelectedTabIndex(event.index);
    }
}
