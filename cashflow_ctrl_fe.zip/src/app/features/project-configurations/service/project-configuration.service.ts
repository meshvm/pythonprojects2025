import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
    providedIn: "root",
})
export class TabStateService {
    private selectedTabIndexSubject = new BehaviorSubject<number>(0);
    selectedTabIndex$ = this.selectedTabIndexSubject.asObservable();

    setSelectedTabIndex(index: number): void {
        this.selectedTabIndexSubject.next(index);
    }
}
