import { BillingItemCost } from "../../../core/api-services/billing/models/billing-item-cost.model";
import { BillingItem } from "../../../core/api-services/billing/models/billing-item.model";

export class BillingTableHelper {
    public static buildDefaultBillingItem(): Partial<BillingItem> {
        return {
            name: "",
            isDefault: false,
            isRequired: false,
            showOption: true,
            billingItemCost: [
                {
                    baseUnitPrice: "0",
                    isDuplexPrinting: false,
                } as Partial<BillingItemCost>,
                {
                    baseUnitPrice: "0",
                    isDuplexPrinting: true,
                } as Partial<BillingItemCost>,
            ],
        };
    }
}
