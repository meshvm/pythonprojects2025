import { CurrencyPipe } from "@angular/common";
import { Injectable } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BillingItem } from "../../../core/api-services/billing/models/billing-item.model";

@Injectable()
export class BillingTableService {
    constructor(
        private formBuilder: FormBuilder,
        private currencyPipe: CurrencyPipe
    ) {}

    public buildForm(billingItem: Partial<BillingItem> = {}): FormGroup {
        return this.formBuilder.group({
            id: billingItem.id as number,
            name: [billingItem.name as string, Validators.required],
            price: [
                this.formatPrice(
                    (billingItem.billingItemCost &&
                        (billingItem.billingItemCost[0]
                            .baseUnitPrice as string)) ||
                        "0"
                ),
                [Validators.min(0.000001), Validators.required],
            ],
            showOption: billingItem.showOption,
        });
    }

    public mapToModel(
        formGroup: FormGroup,
        billingItem: Partial<BillingItem> = {}
    ): Partial<BillingItem> {
        const formValue = formGroup.value;

        return {
            ...billingItem,
            name: formValue.name,
            billingItemCost: [
                {
                    baseUnitPrice: formValue.price,
                    isDuplexPrinting: false,
                },
                {
                    baseUnitPrice: formValue.price,
                    isDuplexPrinting: true,
                },
            ],
            showOption: formValue.showOption,
        };
    }

    private formatPrice(price: string | undefined): string {
        const transformedValue = this.currencyPipe.transform(
            price || 0,
            "USD",
            "symbol",
            "1.2-6"
        );

        // 1).replace(",", "") is used to remove thousands separator, to show "1000" instead of "1,000". Needed to avoid localization conflicts.
        // 2).slice(1) to remove "$" symbol
        return transformedValue?.replace(",", "")?.slice(1) || "0";
    }
}
