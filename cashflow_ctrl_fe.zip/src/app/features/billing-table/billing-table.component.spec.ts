import { ComponentFixture, TestBed } from "@angular/core/testing";
import { BillingTableComponent } from "./billing-table.component";
import { CurrencyPipe } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import {
    OAuthService,
    UrlHelperService,
    OAuthLogger,
    DateTimeProvider,
} from "angular-oauth2-oidc";
import { AuthService } from "src/app/core/oidc/auth-oidc.service";
import { BillingTableService } from "./services/billing-table.service";

describe("BillingTableComponent", () => {
    let component: BillingTableComponent;
    let fixture: ComponentFixture<BillingTableComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [BillingTableComponent],
            imports: [HttpClientModule],
            providers: [
                CurrencyPipe,
                AuthService,
                OAuthService,
                UrlHelperService,
                OAuthLogger,
                DateTimeProvider,
                BillingTableService,
            ],
        });
        fixture = TestBed.createComponent(BillingTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it("should create", () => {
        expect(component).toBeTruthy();
    });
});
