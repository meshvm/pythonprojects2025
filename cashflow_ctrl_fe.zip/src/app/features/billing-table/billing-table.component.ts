import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnChanges,
    Output,
    SimpleChanges,
    ViewChild,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatTableDataSource } from "@angular/material/table";
import { cloneDeep } from "lodash";
import { getLPAttr } from "src/app/core/utils/leapwork";
import { BillingItem } from "../../core/api-services/billing/models/billing-item.model";
import { UserPermissionApiService } from "../../core/api-services/user-permission/user-permission-api.service";
import { AuthService } from "../../core/oidc/auth-oidc.service";
import { BillingTableHelper } from "./helpers/billing-table-helper";
import { BillingTableService } from "./services/billing-table.service";

@Component({
    selector: "cc-billing-table",
    templateUrl: "./billing-table.component.html",
    styleUrls: ["./billing-table.component.scss"],
    // providers: [BillingTableService],
})
export class BillingTableComponent implements OnChanges {
    private static readonly tableColumns: string[] = [
        "Items",
        "UnitPrice",
        "ShowInOtherOptions",
        "actions",
    ];

    @ViewChild("nameInput")
    public nameInput: ElementRef<HTMLElement>;

    @Input()
    public billingItems: BillingItem[];
    @Input()
    public ProjectID: number;

    @Output()
    public createItem: EventEmitter<Partial<BillingItem>>;
    @Output()
    public updateItem: EventEmitter<BillingItem>;
    @Output()
    public deleteItem: EventEmitter<BillingItem>;

    public readonly tableColumns: string[];

    public currentEditingBillingIndex: number;
    public billingTableDataSource: MatTableDataSource<BillingItem>;
    public formGroup: FormGroup | undefined;

    private adding: boolean;

    constructor(
        private billingTableService: BillingTableService,
        private userPermissionApiService: UserPermissionApiService,
        private authService: AuthService
    ) {
        this.formGroup = this.billingTableService.buildForm();

        this.billingItems = [];
        this.tableColumns = BillingTableComponent.tableColumns;
        this.adding = false;

        this.resetEditItemIndex();

        this.createItem = new EventEmitter<Partial<BillingItem>>();
        this.updateItem = new EventEmitter<BillingItem>();
        this.deleteItem = new EventEmitter<BillingItem>();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes["billingItems"]) {
            if (!this.billingItems) {
                this.billingItems = [];
            }

            this.billingTableDataSource = new MatTableDataSource<BillingItem>(
                cloneDeep(this.billingItems)
            );
        }
    }

    public getDisplayIndex(index: number): number {
        return Number(index + 1);
    }

    public onAddBillingItem(): void {
        if (this.adding || this.currentEditingBillingIndex !== -1) {
            return;
        }

        this.adding = true;
        const defaultBillingItem: Partial<BillingItem> =
            BillingTableHelper.buildDefaultBillingItem();

        this.currentEditingBillingIndex =
            this.billingItems.push(defaultBillingItem as BillingItem) - 1;

        this.syncBillingItemsDataSource();

        this.formGroup = this.billingTableService.buildForm(defaultBillingItem);
        this.focusNameInput();
    }

    public onEditBillingItem(index: number): void {
        if (this.currentEditingBillingIndex !== -1) {
            this.onCancelBillingItemEditing();
        }

        this.currentEditingBillingIndex = index;

        this.formGroup = this.billingTableService.buildForm(
            this.billingItems[index]
        );

        this.focusNameInput();
    }

    public onRemoveBillingItem(index: number): void {
        this.deleteItem.emit(this.billingItems[index]);
    }

    public onSaveBillingItem(): void {
        this.formGroup?.markAllAsTouched();

        if (!this.formGroup?.valid) {
            return;
        }

        const item = this.billingItems[this.currentEditingBillingIndex];
        item.ProjectID = this.ProjectID;

        const saveModel = this.billingTableService.mapToModel(
            this.formGroup,
            item
        );

        this.billingItems[this.currentEditingBillingIndex] =
            saveModel as BillingItem;
        this.syncBillingItemsDataSource();

        if (this.adding) {
            this.createItem.emit(saveModel);
        } else {
            this.updateItem.emit(saveModel as BillingItem);
        }

        this.resetEditItemIndex();
        this.adding = false;
    }

    public onCancelBillingItemEditing(): void {
        if (this.adding) {
            this.billingItems.pop();
            this.syncBillingItemsDataSource();
        }

        this.resetEditItemIndex();
        this.adding = false;
    }

    public getLPAttrValue(
        uiElement: string,
        title: string,
        region?: string
    ): string {
        return getLPAttr(uiElement, title, region);
    }

    private resetEditItemIndex(): void {
        this.currentEditingBillingIndex = -1;
    }

    private syncBillingItemsDataSource(): void {
        this.billingTableDataSource.data = cloneDeep(this.billingItems);
    }

    private focusNameInput(): void {
        setTimeout(() => this.nameInput?.nativeElement?.focus());
    }
}
